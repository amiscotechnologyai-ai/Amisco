# 🎨 AmiFy Logo Integration Guide

## Logo Specifications

**Logo File:** `public/logo-full.png`
- Size: Full resolution (1024x1024 recommended)
- Format: PNG with transparent background
- Colors: Silver, Gold, Navy Blue (#1a2332)
- Style: Premium, corporate, 3D metallic

---

## 📂 Icon Files Needed

### **1. App Icons (Home Screen)**

```
public/
├── icon-192.png          (192×192px) - Android home screen
├── icon-192-maskable.png (192×192px) - Maskable for Android 12+
├── icon-512.png          (512×512px) - Splash screen
└── icon-512-maskable.png (512×512px) - Maskable for Android 12+
```

**How to create:**
1. Open logo in Photoshop/Figma/Canva
2. Crop to just the "A" symbol (no text)
3. Add navy blue background (#1a2332)
4. Export as:
   - 192×192px PNG → `icon-192.png`
   - 512×512px PNG → `icon-512.png`
5. For maskable:
   - Add padding around the "A"
   - Ensure center focus
   - Export as `icon-*-maskable.png`

**Visual:**
```
icon-192.png:
┌──────────────┐
│              │
│      A       │  ← Silver/Gold "A" centered
│   (Silver)   │
│              │
└──────────────┘
192×192 pixels

icon-512.png:
┌────────────────────┐
│                    │
│        A           │  ← Larger version
│     (Silver)       │
│                    │
└────────────────────┘
512×512 pixels

Maskable version:
┌────────────────────┐
│ ░░░░░░░░░░░░░░░░░░│
│ ░░░░░░░░░░░░░░░░░░│  ← Safe zone
│ ░░░░░░   A   ░░░░░░│
│ ░░░░░░ (Silver)░░░░░│
│ ░░░░░░░░░░░░░░░░░░│
│ ░░░░░░░░░░░░░░░░░░│
└────────────────────┘
(Center circle stays visible)
```

---

### **2. Favicon (Browser Tab)**

```
public/
├── favicon.ico          (32×32px) - Browser tab icon
└── favicon-32.png       (32×32px) - PNG version
```

**How to create:**
1. Use the "A" symbol (no text)
2. Resize to 32×32px
3. Add navy blue background
4. Export as both .ico and .png

---

### **3. Apple Touch Icon**

```
public/
└── apple-touch-icon.png (180×180px)
```

**How to create:**
1. Same as icon-192.png but 180×180px
2. Rounded corners (20px radius)
3. Used when iOS users add to home screen

---

## 🔗 Integration Points in Code

### **1. manifest.json**
```json
{
  "name": "AmiFy — Amplify your voice",
  "short_name": "AmiFy",
  "icons": [
    {
      "src": "/icon-192.png",
      "sizes": "192x192",
      "type": "image/png",
      "purpose": "any"
    },
    {
      "src": "/icon-192-maskable.png",
      "sizes": "192x192",
      "type": "image/png",
      "purpose": "maskable"
    },
    {
      "src": "/icon-512.png",
      "sizes": "512x512",
      "type": "image/png",
      "purpose": "any"
    },
    {
      "src": "/icon-512-maskable.png",
      "sizes": "512x512",
      "type": "image/png",
      "purpose": "maskable"
    }
  ]
}
```

### **2. HTML Head (layout.tsx)**
```html
<!-- Favicon -->
<link rel="icon" href="/favicon.ico" sizes="32x32" />
<link rel="icon" href="/favicon-32.png" type="image/png" />

<!-- Apple Touch Icon -->
<link rel="apple-touch-icon" href="/apple-touch-icon.png" />

<!-- Theme color matches logo -->
<meta name="theme-color" content="#1a2332" />
```

### **3. Logo in App (Components)**

**In Header:**
```tsx
import Image from 'next/image';

export function Header() {
  return (
    <header className="flex items-center gap-3">
      <Image
        src="/icon-192.png"
        alt="AmiFy"
        width={40}
        height={40}
        className="rounded-lg"
      />
      <h1 className="text-2xl font-bold">AmiFy</h1>
    </header>
  );
}
```

**In Splash Screen:**
```tsx
<div className="flex flex-col items-center justify-center h-screen bg-[#1a2332]">
  <Image
    src="/icon-512.png"
    alt="AmiFy"
    width={200}
    height={200}
    className="mb-8"
  />
  <h1 className="text-4xl font-bold text-white">AmiFy</h1>
  <p className="text-gray-400 mt-2">Amplify your voice</p>
</div>
```

### **4. Metadata (page.tsx)**
```tsx
export const metadata: Metadata = {
  title: "AmiFy — Amplify your voice",
  description: "Premium audio live streaming",
  icons: {
    icon: "/favicon.ico",
    apple: "/apple-touch-icon.png",
  },
  openGraph: {
    images: ["/icon-512.png"],
  },
};
```

---

## 🎯 Where AmiFy Name/Logo Appears

### **1. Home Screen (After Install)**
```
┌──────────────────┐
│  [AmiFy]         │
│   [Icon]         │ ← Showing icon-192.png
│   (with text)    │
└──────────────────┘
```

### **2. Browser Tab**
```
┌─────────────────────────────────┐
│ [icon] AmiFy — Amplify your voice
│
│ Website content here...
└─────────────────────────────────┘
   ↑
   Shows favicon.ico (32×32)
```

### **3. App Header**
```
┌─────────────────────────────────┐
│ [icon] AmiFy    [Menu]          │
│ ────────────────────────────────│
│ Live Streams | My Library | Go  │
└─────────────────────────────────┘
```

### **4. Splash Screen (When Opening App)**
```
┌─────────────────────────────────┐
│                                 │
│           [Icon]                │ ← icon-512.png
│                                 │
│           AmiFy                 │
│      Amplify your voice         │
│                                 │
│        Loading...               │
└─────────────────────────────────┘
```

### **5. Share Dialog (Social Share)**
```
[Share AmiFy]
┌──────────────────┐
│ [icon] AmiFy     │
│ Premium audio... │ ← Open graph image
│ [Share] [Copy]   │
└──────────────────┘
```

### **6. Notifications**
```
🔔 [icon] AmiFy
   Elara just went live!
   [Open] [Dismiss]
```

### **7. URL/Domain**
```
Browser address bar:
[AmiFy icon] amify.app
     ↑
   favicon
```

---

## 📱 Android Home Screen (After Install)

```
┌────────────────────────────────────┐
│ Home Screen                        │
├────────────────────────────────────┤
│                                    │
│  [AmiFy]     [Maps]                │
│   🔷 A       📍                     │ ← Logo appears here
│   (192px)                          │
│                                    │
│  [Messages]  [Settings]            │
│   💬         ⚙️                     │
│                                    │
│                                    │
│  When user taps [AmiFy] ↓          │
│                                    │
│  App opens fullscreen              │
│  ┌──────────────────────────────┐  │
│  │ [AmiFy Icon] AmiFy           │  │
│  │ ─────────────────────────────  │
│  │ Live Streams                 │  │
│  │ ▶ Elara Blue Live            │  │
│  │ ▶ Tech Talk #42              │  │
│  │                              │  │
│  └──────────────────────────────┘  │
│                                    │
└────────────────────────────────────┘
```

---

## 📱 iOS Home Screen (After Install)

```
┌────────────────────────────────────┐
│ iPhone Home Screen                 │
├────────────────────────────────────┤
│                                    │
│  [AmiFy]     [Safari]              │
│   🔷 A       🧭                     │
│   (192px)    (rounded corners)     │
│                                    │
│  [App Store] [Calendar]            │
│   📦         📅                     │
│                                    │
│                                    │
│  When user taps [AmiFy] ↓          │
│                                    │
│  Web app opens fullscreen          │
│  (no browser UI)                   │
│  Looks like REAL native app ✨     │
│                                    │
└────────────────────────────────────┘
```

---

## 🎨 Color Reference

| Element | Color | Code |
|---------|-------|------|
| **Background** | Navy Blue | #1a2332 |
| **Primary** | Gold | #d4a574 |
| **Secondary** | Silver | #c0c0c0 |
| **Accent** | Brand Purple | #7c3aed |

**In Tailwind:**
```tsx
<div className="bg-[#1a2332]">  {/* Navy blue */}
<div className="text-[#d4a574]"> {/* Gold */}
<div className="bg-brand-600">   {/* Purple accent */}
```

---

## 🚀 Quick Setup (Step by Step)

### **Step 1: Create Icon Files**

Use any of these tools:
- **Photoshop** — Most professional
- **Figma** — Free, cloud-based
- **Canva** — Easy, no experience needed
- **IconKitchen** — AI-powered icons

Create 4 files:
1. `icon-192.png` (192×192px)
2. `icon-192-maskable.png` (192×192px with padding)
3. `icon-512.png` (512×512px)
4. `icon-512-maskable.png` (512×512px with padding)

### **Step 2: Create Favicon**

1. Crop logo to just "A"
2. Resize to 32×32px
3. Save as `favicon.ico` (can convert .png to .ico online)
4. Also save as `favicon-32.png`

### **Step 3: Create Apple Icon**

1. Same as icon-192.png
2. Resize to 180×180px
3. Add 20px rounded corners
4. Save as `apple-touch-icon.png`

### **Step 4: Place in Public Folder**

```bash
cp your-icon-192.png /home/claude/amify/public/icon-192.png
cp your-icon-512.png /home/claude/amify/public/icon-512.png
cp your-favicon.ico /home/claude/amify/public/favicon.ico
cp your-apple-icon.png /home/claude/amify/public/apple-touch-icon.png
```

### **Step 5: Update manifest.json**

Already done! Just upload icons.

### **Step 6: Deploy**

```bash
fly deploy
```

Done! ✅

---

## ✅ Verification Checklist

- [ ] `icon-192.png` exists (192×192)
- [ ] `icon-192-maskable.png` exists (with padding)
- [ ] `icon-512.png` exists (512×512)
- [ ] `icon-512-maskable.png` exists (with padding)
- [ ] `favicon.ico` exists (32×32)
- [ ] `favicon-32.png` exists (32×32)
- [ ] `apple-touch-icon.png` exists (180×180)
- [ ] `manifest.json` references all icons
- [ ] `layout.tsx` has meta tags
- [ ] App deployed to production
- [ ] Test on Android phone (home screen icon)
- [ ] Test on iPhone (home screen icon)
- [ ] Check browser tab (favicon shows)

---

## 🧪 Testing

### **Test on Android**

1. Open AmiFy on Chrome
2. See floating banner "Add AmiFy to Home Screen"
3. Tap [✓ Add]
4. Check home screen
5. Icon should show logo (icon-192.png) ✅
6. App name "AmiFy" below icon ✅

### **Test on iPhone**

1. Open AmiFy on Safari
2. Tap Share → Add to Home Screen
3. Check home screen
4. Icon should show logo (180×180) ✅
5. App name "AmiFy" below icon ✅
6. Rounded corners applied ✅

### **Test Favicon**

1. Open AmiFy in browser
2. Check browser tab
3. Favicon (32×32) should appear ✅

---

## 📊 Icon File Summary

| File | Size | Use |
|------|------|-----|
| `logo-full.png` | Original | Reference |
| `icon-192.png` | 192×192 | Android home screen |
| `icon-192-maskable.png` | 192×192 | Android 12+ adaptive |
| `icon-512.png` | 512×512 | Splash screen |
| `icon-512-maskable.png` | 512×512 | Adaptive splash |
| `favicon.ico` | 32×32 | Browser tab |
| `favicon-32.png` | 32×32 | PNG variant |
| `apple-touch-icon.png` | 180×180 | iOS home screen |

**Total:** 8 files (essential for PWA)

---

## 🎉 Result

Once integrated:

✅ Professional logo on home screen
✅ Favicon in browser tab
✅ Splash screen with logo
✅ Notifications with logo
✅ Share dialogs with logo
✅ Consistent branding everywhere
✅ Premium, polished feel
✅ Better than 99% of web apps

**Your app will look like a REAL native app!** 🚀

---

## 💡 Pro Tips

1. **Keep consistent** — Use the logo everywhere
2. **Rounded corners** — Add 20px radius on iOS
3. **Padding** — Leave space around logo in maskable versions
4. **Color** — Use navy blue (#1a2332) background
5. **Dark mode** — Ensure readable on dark screens
6. **Test early** — Install on actual devices before launch

---

**Questions?** All integration points are documented above!
