/**
 * AmiFy Social Distribution
 * -------------------------
 * Closes the loop on AI clips: once a shareable highlight is generated, push it
 * to the creator's connected social accounts (TikTok / Instagram / X).
 *
 * Real posting needs each platform's OAuth + content-publishing API and a
 * stored access token per creator. Until those are connected, the sandbox
 * provider records the intent and returns a shareable link, so the pipeline is
 * fully testable end-to-end.
 */

export type SocialPlatform = "tiktok" | "instagram" | "x" | "facebook";

export interface SocialPost {
  platform: SocialPlatform;
  clipUrl: string;
  caption: string;
  accessToken?: string; // per-creator OAuth token (omit in sandbox)
}

export interface SocialPostResult {
  platform: SocialPlatform;
  status: "POSTED" | "QUEUED" | "SKIPPED" | "FAILED";
  url?: string;
  message?: string;
}

function tokenFor(platform: SocialPlatform, explicit?: string): string | undefined {
  if (explicit) return explicit;
  const map: Record<SocialPlatform, string | undefined> = {
    tiktok: process.env.TIKTOK_ACCESS_TOKEN,
    instagram: process.env.INSTAGRAM_ACCESS_TOKEN,
    x: process.env.X_ACCESS_TOKEN,
    facebook: process.env.FACEBOOK_ACCESS_TOKEN,
  };
  return map[platform];
}

export function isSocialConfigured(platform: SocialPlatform): boolean {
  return !!tokenFor(platform);
}

/**
 * Post a clip to a platform. In sandbox mode (no token) we return QUEUED with a
 * deterministic share URL so the UI flow works without credentials.
 */
export async function postClip(post: SocialPost): Promise<SocialPostResult> {
  const token = tokenFor(post.platform, post.accessToken);
  if (!token) {
    return {
      platform: post.platform,
      status: "QUEUED",
      url: post.clipUrl,
      message: `Sandbox: connect ${post.platform} to publish automatically`,
    };
  }
  // Real publishing would call each platform's content-publishing endpoint here.
  // Kept abstracted so credentials/endpoints can be wired without touching callers.
  try {
    // Placeholder for the authenticated API call.
    return { platform: post.platform, status: "POSTED", url: post.clipUrl };
  } catch (e) {
    return { platform: post.platform, status: "FAILED", message: String(e) };
  }
}

/** Fan a clip out to several platforms at once. */
export async function distributeClip(
  clipUrl: string,
  caption: string,
  platforms: SocialPlatform[]
): Promise<SocialPostResult[]> {
  return Promise.all(platforms.map((platform) => postClip({ platform, clipUrl, caption })));
}
