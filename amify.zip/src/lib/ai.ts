/**
 * AmiFy AI Layer
 * --------------
 * Provider-agnostic AI features:
 *   - Transcription (audio -> text)        [needs a speech-to-text provider]
 *   - Show notes & summaries               [LLM]
 *   - Chapter detection                    [LLM]
 *   - Highlight / clip suggestions         [LLM]
 *   - Translation / dubbing prep           [LLM]
 *
 * Set AI_PROVIDER + the relevant key to activate. Without keys, functions
 * return clearly-labelled placeholder output so the pipeline is testable
 * end-to-end and the UI works.
 */

export interface TranscriptSegment {
  start: number;
  end: number;
  text: string;
}

export interface TranscriptionResult {
  language: string;
  fullText: string;
  segments: TranscriptSegment[];
}

export interface ShowNotesResult {
  summary: string;
  bullets: string[];
  chapters: { title: string; startSec: number }[];
  clipSuggestions: { title: string; startSec: number; endSec: number }[];
}

const OPENAI_KEY = process.env.OPENAI_API_KEY;
const AI_ENABLED = Boolean(OPENAI_KEY);

/** Transcribe an audio file URL. Uses OpenAI Whisper when configured. */
export async function transcribeAudio(
  audioUrl: string,
  language = "en"
): Promise<TranscriptionResult> {
  if (!AI_ENABLED) {
    return {
      language,
      fullText:
        "[Transcription will appear here once an AI provider key is configured. The full pipeline — storage, status tracking, and display — is already wired.]",
      segments: [],
    };
  }

  // Fetch the audio and send to Whisper
  const audioRes = await fetch(audioUrl);
  const blob = await audioRes.blob();
  const form = new FormData();
  form.append("file", blob, "audio.mp3");
  form.append("model", "whisper-1");
  form.append("response_format", "verbose_json");

  const res = await fetch("https://api.openai.com/v1/audio/transcriptions", {
    method: "POST",
    headers: { Authorization: `Bearer ${OPENAI_KEY}` },
    body: form,
  });
  const data = await res.json();
  return {
    language: data.language || language,
    fullText: data.text || "",
    segments: (data.segments || []).map((s: any) => ({
      start: s.start,
      end: s.end,
      text: s.text,
    })),
  };
}

/** Generate show notes, chapters, and clip suggestions from a transcript. */
export async function generateShowNotes(
  transcript: string,
  title: string
): Promise<ShowNotesResult> {
  if (!AI_ENABLED || !transcript.trim()) {
    return {
      summary:
        "AI show notes will be generated here once a provider key is set.",
      bullets: ["Key point one", "Key point two", "Key point three"],
      chapters: [{ title: "Introduction", startSec: 0 }],
      clipSuggestions: [],
    };
  }

  const prompt = `You are a podcast producer. Given this transcript of "${title}", produce JSON with keys: summary (2-3 sentences), bullets (array of 4-6 key takeaways), chapters (array of {title, startSec}), clipSuggestions (array of {title, startSec, endSec} for the 3 most shareable 30-60s moments). Transcript:\n\n${transcript.slice(0, 12000)}`;

  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${OPENAI_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    }),
  });
  const data = await res.json();
  try {
    const parsed = JSON.parse(data.choices[0].message.content);
    return {
      summary: parsed.summary ?? "",
      bullets: parsed.bullets ?? [],
      chapters: parsed.chapters ?? [],
      clipSuggestions: parsed.clipSuggestions ?? [],
    };
  } catch {
    return {
      summary: data.choices?.[0]?.message?.content ?? "",
      bullets: [],
      chapters: [],
      clipSuggestions: [],
    };
  }
}

/** Translate text to a target language for global reach / dubbing prep. */
export async function translateText(
  text: string,
  targetLang: string
): Promise<string> {
  if (!AI_ENABLED) {
    return `[Translation to ${targetLang} appears here once configured]`;
  }
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${OPENAI_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "user",
          content: `Translate the following to ${targetLang}, preserving tone:\n\n${text.slice(0, 8000)}`,
        },
      ],
    }),
  });
  const data = await res.json();
  return data.choices?.[0]?.message?.content ?? "";
}

export const aiEnabled = AI_ENABLED;
