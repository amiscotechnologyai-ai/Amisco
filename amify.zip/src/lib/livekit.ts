/**
 * AmiFy Live Audio Layer (LiveKit)
 * --------------------------------
 * Generates access tokens so hosts/speakers can publish audio and
 * listeners can subscribe in low-latency WebRTC rooms.
 *
 * Set LIVEKIT_API_KEY, LIVEKIT_API_SECRET and NEXT_PUBLIC_LIVEKIT_URL to
 * activate. Install the official SDK on the server: `npm i livekit-server-sdk`.
 *
 * This module signs a standards-compliant LiveKit JWT manually so the
 * codebase stays dependency-light; swapping in AccessToken from
 * livekit-server-sdk is a drop-in replacement.
 */

import crypto from "crypto";

interface TokenOptions {
  roomName: string;
  identity: string;
  name: string;
  canPublish: boolean; // hosts/speakers true, listeners false
}

function base64url(input: Buffer | string): string {
  return Buffer.from(input)
    .toString("base64")
    .replace(/=/g, "")
    .replace(/\+/g, "-")
    .replace(/\//g, "_");
}

export function isLiveKitConfigured(): boolean {
  return Boolean(
    process.env.LIVEKIT_API_KEY && process.env.LIVEKIT_API_SECRET
  );
}

/** Create a signed LiveKit access token (HS256 JWT with video grants). */
export function createLiveKitToken(opts: TokenOptions): string | null {
  const apiKey = process.env.LIVEKIT_API_KEY;
  const apiSecret = process.env.LIVEKIT_API_SECRET;
  if (!apiKey || !apiSecret) return null;

  const now = Math.floor(Date.now() / 1000);
  const header = { alg: "HS256", typ: "JWT" };
  const payload = {
    iss: apiKey,
    sub: opts.identity,
    name: opts.name,
    nbf: now,
    exp: now + 60 * 60 * 6, // 6 hours
    video: {
      room: opts.roomName,
      roomJoin: true,
      canPublish: opts.canPublish,
      canSubscribe: true,
      canPublishData: true,
    },
  };

  const encHeader = base64url(JSON.stringify(header));
  const encPayload = base64url(JSON.stringify(payload));
  const signature = crypto
    .createHmac("sha256", apiSecret)
    .update(`${encHeader}.${encPayload}`)
    .digest();

  return `${encHeader}.${encPayload}.${base64url(signature)}`;
}

export const liveKitUrl = process.env.NEXT_PUBLIC_LIVEKIT_URL || "";
