// lib/backgroundAudio.ts
// Manages audio playback across app navigation and background

import type { Socket } from 'socket.io-client';

interface AudioContext {
  streamId: string;
  audioElement: HTMLAudioElement | null;
  isPlaying: boolean;
  isMuted: boolean;
  volume: number;
  socket: Socket | null;
}

class BackgroundAudioManager {
  private context: AudioContext = {
    streamId: '',
    audioElement: null,
    isPlaying: false,
    isMuted: false,
    volume: 1,
    socket: null,
  };

  private wakeLock: WakeLockSentinel | null = null;
  private listeners: Map<string, Function[]> = new Map();

  /**
   * Initialize background audio
   * Call this once on app mount
   */
  async init() {
    console.log('[BG Audio] Initializing...');

    // Create persistent audio element (stays in DOM always)
    if (!this.context.audioElement) {
      const audio = document.createElement('audio');
      audio.id = 'amify-background-audio';
      audio.controls = false;
      audio.style.display = 'none';
      
      // Enable background playback on iOS/Android
      audio.setAttribute('playsinline', '');
      
      // Persist across page navigation
      document.body.appendChild(audio);
      this.context.audioElement = audio;

      // Listen for audio events
      audio.addEventListener('play', () => {
        this.context.isPlaying = true;
        this.emit('play');
      });

      audio.addEventListener('pause', () => {
        this.context.isPlaying = false;
        this.emit('pause');
      });

      audio.addEventListener('error', (e) => {
        console.error('[BG Audio] Error:', e);
        this.emit('error', e);
      });

      audio.addEventListener('ended', () => {
        this.context.isPlaying = false;
        this.emit('ended');
      });

      // Auto-play on iOS when user taps play once
      document.addEventListener('click', () => {
        if (this.context.audioElement && this.context.isPlaying) {
          this.context.audioElement.play().catch((err) => {
            console.warn('[BG Audio] Play failed:', err);
          });
        }
      }, { once: true });
    }

    // Request wake lock to keep device awake
    if ('wakeLock' in navigator) {
      try {
        this.wakeLock = await (navigator as any).wakeLock.request('screen');
        console.log('[BG Audio] Wake lock acquired');

        // Re-acquire wake lock if document visibility changes
        document.addEventListener('visibilitychange', async () => {
          if (document.hidden && this.context.isPlaying) {
            // Keep playing in background
            if (this.wakeLock === null) {
              try {
                this.wakeLock = await (navigator as any).wakeLock.request('screen');
              } catch (err) {
                console.warn('[BG Audio] Wake lock re-acquire failed:', err);
              }
            }
          }
        });
      } catch (err) {
        console.warn('[BG Audio] Wake lock not supported:', err);
      }
    }

    // Request microphone permission for better audio handling
    try {
      await navigator.mediaDevices.getUserMedia({ audio: true });
      console.log('[BG Audio] Audio permission granted');
    } catch (err) {
      console.warn('[BG Audio] Audio permission not granted (may be needed for recording)');
    }

    console.log('[BG Audio] Initialized');
  }

  /**
   * Start playing a live stream
   */
  async play(streamId: string, audioUrl: string, socket: Socket) {
    console.log('[BG Audio] Playing stream:', streamId);

    const audio = this.context.audioElement;
    if (!audio) {
      console.error('[BG Audio] Audio element not initialized');
      return;
    }

    this.context.streamId = streamId;
    this.context.socket = socket;

    // Set audio source
    audio.src = audioUrl;
    audio.volume = this.context.volume;

    // Attempt to play
    try {
      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            console.log('[BG Audio] Playback started');
            this.context.isPlaying = true;
            this.emit('play');
          })
          .catch((err) => {
            console.error('[BG Audio] Playback failed:', err);
            // On mobile, user gesture is required
            this.emit('playback-blocked');
          });
      }
    } catch (err) {
      console.error('[BG Audio] Play error:', err);
    }
  }

  /**
   * Pause playback
   */
  pause() {
    if (this.context.audioElement) {
      this.context.audioElement.pause();
      this.context.isPlaying = false;
      this.emit('pause');
    }
  }

  /**
   * Resume playback
   */
  resume() {
    if (this.context.audioElement && !this.context.isPlaying) {
      this.context.audioElement.play().catch((err) => {
        console.warn('[BG Audio] Resume failed:', err);
      });
    }
  }

  /**
   * Stop playback and cleanup
   */
  stop() {
    console.log('[BG Audio] Stopping');
    if (this.context.audioElement) {
      this.context.audioElement.pause();
      this.context.audioElement.src = '';
    }
    this.context.streamId = '';
    this.context.isPlaying = false;
    this.emit('stop');
  }

  /**
   * Mute/unmute
   */
  setMuted(muted: boolean) {
    if (this.context.audioElement) {
      this.context.audioElement.muted = muted;
      this.context.isMuted = muted;
      this.emit('muted', muted);
    }
  }

  /**
   * Set volume (0-1)
   */
  setVolume(volume: number) {
    const clamped = Math.max(0, Math.min(1, volume));
    if (this.context.audioElement) {
      this.context.audioElement.volume = clamped;
    }
    this.context.volume = clamped;
    this.emit('volume', clamped);
  }

  /**
   * Get current playback state
   */
  getState() {
    return {
      streamId: this.context.streamId,
      isPlaying: this.context.isPlaying,
      isMuted: this.context.isMuted,
      volume: this.context.volume,
      currentTime: this.context.audioElement?.currentTime || 0,
    };
  }

  /**
   * Set up mini player controls
   * Call this to keep audio playing when user navigates away
   */
  persistAcrossNavigation() {
    // Audio element is already persistent in DOM
    // Just update UI references when component mounts

    // Listen for page visibility changes
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        console.log('[BG Audio] App backgrounded, audio continues');
        // Audio continues playing automatically
      } else {
        console.log('[BG Audio] App foregrounded');
        // Update UI state if needed
        this.emit('foreground');
      }
    });
  }

  /**
   * Request notification permissions
   */
  async requestNotificationPermission() {
    if ('Notification' in window && Notification.permission === 'default') {
      try {
        const permission = await Notification.requestPermission();
        console.log('[BG Audio] Notification permission:', permission);
        return permission === 'granted';
      } catch (err) {
        console.warn('[BG Audio] Notification request failed:', err);
        return false;
      }
    }
    return Notification.permission === 'granted';
  }

  /**
   * Show now-playing notification (mobile)
   */
  async showNowPlayingNotification(streamTitle: string, creatorName: string) {
    const permitted = await this.requestNotificationPermission();
    if (!permitted) return;

    const notification = new Notification(`${streamTitle} by ${creatorName}`, {
      body: 'Now playing in background',
      icon: '/icon-192.png',
      tag: 'amify-playing',
      requireInteraction: false,
    });

    notification.onclick = () => {
      window.focus();
      notification.close();
    };
  }

  /**
   * Event subscription
   */
  on(event: string, callback: Function) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, []);
    }
    this.listeners.get(event)!.push(callback);

    // Return unsubscribe function
    return () => {
      const callbacks = this.listeners.get(event);
      if (callbacks) {
        const index = callbacks.indexOf(callback);
        if (index > -1) callbacks.splice(index, 1);
      }
    };
  }

  /**
   * Emit events to listeners
   */
  private emit(event: string, ...args: any[]) {
    const callbacks = this.listeners.get(event);
    if (callbacks) {
      callbacks.forEach((cb) => cb(...args));
    }
  }

  /**
   * Cleanup
   */
  destroy() {
    this.stop();
    if (this.wakeLock) {
      this.wakeLock.release();
    }
    this.listeners.clear();
  }
}

// Export singleton
export const bgAudio = new BackgroundAudioManager();
