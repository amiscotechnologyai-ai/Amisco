/**
 * AmiFy i18n
 * ----------
 * Lightweight, dependency-free translations. Ships with English plus local
 * Ghanaian languages (Twi, Ga, Ewe, Hausa) so the app speaks to its audience.
 *
 * Add a language by extending `dictionaries`. Missing keys gracefully fall back
 * to English, so partial translations are safe to ship.
 */

export type Locale = "en" | "tw" | "ga" | "ee" | "ha";

export const LOCALES: { code: Locale; label: string; native: string }[] = [
  { code: "en", label: "English", native: "English" },
  { code: "tw", label: "Twi", native: "Twi" },
  { code: "ga", label: "Ga", native: "Gã" },
  { code: "ee", label: "Ewe", native: "Eʋegbe" },
  { code: "ha", label: "Hausa", native: "Hausa" },
];

export type TranslationKey =
  | "nav.home"
  | "nav.live"
  | "nav.search"
  | "nav.library"
  | "nav.profile"
  | "action.goLive"
  | "action.listen"
  | "action.follow"
  | "action.tip"
  | "action.send"
  | "action.save"
  | "label.liveNow"
  | "label.trending"
  | "label.forYou"
  | "label.listeners"
  | "label.chat"
  | "label.settings"
  | "label.language"
  | "label.dataSaver"
  | "greeting.welcome";

type Dict = Record<TranslationKey, string>;

const en: Dict = {
  "nav.home": "Home",
  "nav.live": "Live",
  "nav.search": "Search",
  "nav.library": "Library",
  "nav.profile": "Profile",
  "action.goLive": "Go Live",
  "action.listen": "Listen",
  "action.follow": "Follow",
  "action.tip": "Tip",
  "action.send": "Send",
  "action.save": "Save",
  "label.liveNow": "Live Now",
  "label.trending": "Trending",
  "label.forYou": "For You",
  "label.listeners": "listeners",
  "label.chat": "Chat",
  "label.settings": "Settings",
  "label.language": "Language",
  "label.dataSaver": "Data Saver",
  "greeting.welcome": "Welcome",
};

const tw: Partial<Dict> = {
  "nav.home": "Fie",
  "nav.live": "Tee",
  "nav.search": "Hwehwɛ",
  "nav.library": "Nhomakorabea",
  "nav.profile": "Wo ho",
  "action.goLive": "Kɔ Tee",
  "action.listen": "Tie",
  "action.follow": "Di akyi",
  "action.tip": "Ma akyɛde",
  "action.send": "Soma",
  "label.liveNow": "Ɛrekɔ so seesei",
  "label.listeners": "atiefoɔ",
  "label.chat": "Nkɔmmɔbɔ",
  "label.settings": "Nhyehyɛeɛ",
  "label.language": "Kasa",
  "greeting.welcome": "Akwaaba",
};

const ga: Partial<Dict> = {
  "nav.home": "Shia",
  "nav.search": "Tao",
  "action.listen": "Bo toi",
  "action.follow": "Nyiɛ sɛɛ",
  "label.liveNow": "Miiya nɔŋŋ",
  "label.chat": "Sane",
  "label.language": "Wiemɔ",
  "greeting.welcome": "Ɔɔŋ aba",
};

const ee: Partial<Dict> = {
  "nav.home": "Aƒe",
  "nav.search": "Di",
  "action.listen": "Ðo to",
  "action.follow": "Dze yome",
  "label.liveNow": "Le edzi fifia",
  "label.chat": "Dzeɖoɖo",
  "label.language": "Gbe",
  "greeting.welcome": "Woezɔ",
};

const ha: Partial<Dict> = {
  "nav.home": "Gida",
  "nav.search": "Nema",
  "action.listen": "Saurara",
  "action.follow": "Bi",
  "label.liveNow": "Kai tsaye yanzu",
  "label.chat": "Hira",
  "label.language": "Harshe",
  "greeting.welcome": "Barka da zuwa",
};

const dictionaries: Record<Locale, Partial<Dict>> = { en, tw, ga, ee, ha };

export function translate(locale: Locale, key: TranslationKey): string {
  const d = dictionaries[locale] || {};
  return d[key] ?? en[key] ?? key;
}

/** Returns a bound `t` function for a locale. */
export function makeT(locale: Locale) {
  return (key: TranslationKey) => translate(locale, key);
}
