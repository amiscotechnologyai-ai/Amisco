/**
 * AmiFy Moderation
 * ----------------
 * Server-side chat safety used by the realtime layer:
 *   - banned-word filtering (per-stream, host-configurable)
 *   - slow mode (min seconds between a user's messages)
 *   - optional AI moderation (OpenAI) gated on a key, with a safe heuristic
 *     fallback so it works without one.
 */

const DEFAULT_BLOCKLIST = [
  // a small built-in baseline; hosts add their own per stream
  "scam", "spam",
];

export function parseBannedWords(csv: string): string[] {
  return (csv || "")
    .split(",")
    .map((w) => w.trim().toLowerCase())
    .filter(Boolean);
}

/** Returns the matched banned word, or null if clean. */
export function findBannedWord(content: string, extra: string[] = []): string | null {
  const text = content.toLowerCase();
  const list = [...DEFAULT_BLOCKLIST, ...extra];
  for (const w of list) {
    if (!w) continue;
    // word-ish boundary match
    const re = new RegExp(`(^|[^a-z0-9])${escapeRegex(w)}([^a-z0-9]|$)`, "i");
    if (re.test(text)) return w;
  }
  return null;
}

/** Masks a banned word with asterisks instead of dropping the message. */
export function maskBannedWords(content: string, extra: string[] = []): string {
  let out = content;
  for (const w of [...DEFAULT_BLOCKLIST, ...extra]) {
    if (!w) continue;
    const re = new RegExp(escapeRegex(w), "ig");
    out = out.replace(re, (m) => m[0] + "*".repeat(Math.max(1, m.length - 1)));
  }
  return out;
}

function escapeRegex(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

// Simple in-memory slow-mode tracker: streamId -> userId -> last ms.
const lastMessageAt = new Map<string, Map<string, number>>();

/** Returns remaining cooldown seconds (0 = allowed) and records the send if allowed. */
export function checkSlowMode(streamId: string, userId: string, slowModeSec: number): number {
  if (!slowModeSec || slowModeSec <= 0) return 0;
  const now = Date.now();
  let perUser = lastMessageAt.get(streamId);
  if (!perUser) {
    perUser = new Map();
    lastMessageAt.set(streamId, perUser);
  }
  const last = perUser.get(userId) || 0;
  const elapsed = (now - last) / 1000;
  if (elapsed < slowModeSec) return Math.ceil(slowModeSec - elapsed);
  perUser.set(userId, now);
  return 0;
}

export function clearSlowMode(streamId: string): void {
  lastMessageAt.delete(streamId);
}

/** Optional AI toxicity check. Returns true if the message should be blocked. */
export async function aiFlagsMessage(content: string): Promise<boolean> {
  const key = process.env.OPENAI_API_KEY;
  if (!key) return false; // no AI configured -> rely on word filter only
  try {
    const res = await fetch("https://api.openai.com/v1/moderations", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model: "omni-moderation-latest", input: content }),
    });
    if (!res.ok) return false;
    const data = (await res.json()) as { results?: { flagged?: boolean }[] };
    return !!data.results?.[0]?.flagged;
  } catch {
    return false;
  }
}
