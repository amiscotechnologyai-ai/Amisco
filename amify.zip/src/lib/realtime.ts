import type { Server as SocketIOServer } from "socket.io";
import type {
  ServerToClientEvents,
  ClientToServerEvents,
  TipDTO,
  TipGoalDTO,
} from "@/types";

type IO = SocketIOServer<ClientToServerEvents, ServerToClientEvents>;

/**
 * Holds a reference to the live Socket.IO server instance so that
 * REST API routes (e.g. tipping after a payment confirms) can push
 * real-time events into stream rooms.
 */
const g = globalThis as unknown as { __amifyIO?: IO };

export function setIO(io: IO) {
  g.__amifyIO = io;
}

export function getIO(): IO | null {
  return g.__amifyIO ?? null;
}

export function emitTip(streamId: string | null | undefined, tip: TipDTO) {
  const io = getIO();
  if (!io) return;
  if (streamId) io.to(streamId).emit("tip:received", tip);
}

export function emitTipGoal(streamId: string | null | undefined, goal: TipGoalDTO) {
  const io = getIO();
  if (!io) return;
  if (streamId) io.to(streamId).emit("tipGoal:update", goal);
}
