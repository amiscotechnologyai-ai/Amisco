/**
 * AmiFy SMS Layer
 * ---------------
 * Provider-agnostic SMS so AmiFy can send "creator is live" alerts and stream
 * reminders even to users who keep mobile data off — important for reach in
 * Ghana / across Africa.
 *
 * Implementations:
 *   - SandboxSms (default): logs to server, always "sent" — fully testable.
 *   - ArkeselSms / HubtelSms: Ghana-focused providers (set SMS_PROVIDER + keys).
 *   - TwilioSms: international fallback.
 *
 * Until keys are supplied, sandbox mode keeps the whole flow working.
 */

export interface SmsMessage {
  to: string; // E.164, e.g. +233546542046
  body: string;
}

export interface SmsResult {
  to: string;
  status: "SENT" | "QUEUED" | "FAILED";
  providerId?: string;
  message?: string;
}

export interface SmsProvider {
  send(msg: SmsMessage): Promise<SmsResult>;
}

class SandboxSms implements SmsProvider {
  async send(msg: SmsMessage): Promise<SmsResult> {
    // eslint-disable-next-line no-console
    console.log(`[SMS:sandbox] -> ${msg.to}: ${msg.body}`);
    return { to: msg.to, status: "SENT", providerId: "sandbox", message: "Sandbox SMS (no real send)" };
  }
}

class ArkeselSms implements SmsProvider {
  constructor(private apiKey: string, private sender: string) {}
  async send(msg: SmsMessage): Promise<SmsResult> {
    try {
      const res = await fetch("https://sms.arkesel.com/api/v2/sms/send", {
        method: "POST",
        headers: { "api-key": this.apiKey, "Content-Type": "application/json" },
        body: JSON.stringify({ sender: this.sender, message: msg.body, recipients: [msg.to.replace("+", "")] }),
      });
      const ok = res.ok;
      return { to: msg.to, status: ok ? "SENT" : "FAILED", providerId: "arkesel" };
    } catch (e) {
      return { to: msg.to, status: "FAILED", providerId: "arkesel", message: String(e) };
    }
  }
}

class TwilioSms implements SmsProvider {
  constructor(private sid: string, private token: string, private from: string) {}
  async send(msg: SmsMessage): Promise<SmsResult> {
    try {
      const body = new URLSearchParams({ To: msg.to, From: this.from, Body: msg.body });
      const res = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${this.sid}/Messages.json`, {
        method: "POST",
        headers: {
          Authorization: "Basic " + Buffer.from(`${this.sid}:${this.token}`).toString("base64"),
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body,
      });
      return { to: msg.to, status: res.ok ? "QUEUED" : "FAILED", providerId: "twilio" };
    } catch (e) {
      return { to: msg.to, status: "FAILED", providerId: "twilio", message: String(e) };
    }
  }
}

let cached: SmsProvider | null = null;

export function getSmsProvider(): SmsProvider {
  if (cached) return cached;
  const provider = (process.env.SMS_PROVIDER || "sandbox").toLowerCase();
  if (provider === "arkesel" && process.env.ARKESEL_API_KEY) {
    cached = new ArkeselSms(process.env.ARKESEL_API_KEY, process.env.SMS_SENDER_ID || "AmiFy");
  } else if (provider === "twilio" && process.env.TWILIO_SID && process.env.TWILIO_TOKEN) {
    cached = new TwilioSms(process.env.TWILIO_SID, process.env.TWILIO_TOKEN, process.env.TWILIO_FROM || "");
  } else {
    cached = new SandboxSms();
  }
  return cached;
}

export function isSmsConfigured(): boolean {
  const provider = (process.env.SMS_PROVIDER || "sandbox").toLowerCase();
  if (provider === "arkesel") return !!process.env.ARKESEL_API_KEY;
  if (provider === "twilio") return !!(process.env.TWILIO_SID && process.env.TWILIO_TOKEN);
  return false;
}

/** Fan out a notification to many phone numbers (best-effort). */
export async function sendBulkSms(numbers: string[], body: string): Promise<SmsResult[]> {
  const provider = getSmsProvider();
  return Promise.all(numbers.filter(Boolean).map((to) => provider.send({ to, body })));
}
