/**
 * AmiFy Payment Layer
 * --------------------
 * A provider-agnostic gateway interface so AmiFy can settle real money via:
 *   - Mobile Money (MTN MoMo, Vodafone Cash, AirtelTigo) — popular in Ghana/Africa
 *   - Cards
 *
 * Drop in a real provider (Paystack / Hubtel / Flutterwave) by implementing
 * `PaymentGateway` and selecting it via PAYMENT_PROVIDER env var. Until keys are
 * supplied, the SandboxGateway auto-confirms so the full flow is testable.
 */

export type ProviderId =
  | "MOMO_MTN"
  | "MOMO_VODAFONE"
  | "MOMO_AIRTELTIGO"
  | "CARD"
  | "WALLET";

export interface ChargeRequest {
  amountMinor: number; // pesewas / cents
  currency: string; // "GHS"
  provider: ProviderId;
  reference: string;
  customer: { email: string; phone?: string; name?: string };
  metadata?: Record<string, unknown>;
}

export interface ChargeResult {
  reference: string;
  status: "PENDING" | "COMPLETED" | "FAILED";
  // For redirect/USSD flows, the client may need to act on this:
  authorizationUrl?: string;
  ussdCode?: string;
  message?: string;
}

export interface PaymentGateway {
  charge(req: ChargeRequest): Promise<ChargeResult>;
  verify(reference: string): Promise<ChargeResult>;
}

/** Sandbox gateway: auto-confirms instantly. Used until real keys are set. */
class SandboxGateway implements PaymentGateway {
  async charge(req: ChargeRequest): Promise<ChargeResult> {
    return {
      reference: req.reference,
      status: "COMPLETED",
      message: "Sandbox payment auto-confirmed",
    };
  }
  async verify(reference: string): Promise<ChargeResult> {
    return { reference, status: "COMPLETED" };
  }
}

/**
 * Paystack gateway (supports Ghana mobile money + cards).
 * Activated when PAYSTACK_SECRET_KEY is present.
 * Docs: https://paystack.com/docs/payments/payments
 */
class PaystackGateway implements PaymentGateway {
  constructor(private secret: string) {}

  private momoChannel(p: ProviderId): string | undefined {
    switch (p) {
      case "MOMO_MTN":
        return "mtn";
      case "MOMO_VODAFONE":
        return "vod";
      case "MOMO_AIRTELTIGO":
        return "tgo";
      default:
        return undefined;
    }
  }

  async charge(req: ChargeRequest): Promise<ChargeResult> {
    const momo = this.momoChannel(req.provider);
    const endpoint = momo
      ? "https://api.paystack.co/charge"
      : "https://api.paystack.co/transaction/initialize";

    const body = momo
      ? {
          email: req.customer.email,
          amount: req.amountMinor,
          currency: req.currency,
          reference: req.reference,
          mobile_money: { phone: req.customer.phone, provider: momo },
        }
      : {
          email: req.customer.email,
          amount: req.amountMinor,
          currency: req.currency,
          reference: req.reference,
        };

    const res = await fetch(endpoint, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${this.secret}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    return {
      reference: req.reference,
      status: data?.data?.status === "success" ? "COMPLETED" : "PENDING",
      authorizationUrl: data?.data?.authorization_url,
      message: data?.message,
    };
  }

  async verify(reference: string): Promise<ChargeResult> {
    const res = await fetch(
      `https://api.paystack.co/transaction/verify/${reference}`,
      { headers: { Authorization: `Bearer ${this.secret}` } }
    );
    const data = await res.json();
    return {
      reference,
      status: data?.data?.status === "success" ? "COMPLETED" : "FAILED",
    };
  }
}

export function getGateway(): PaymentGateway {
  const provider = process.env.PAYMENT_PROVIDER;
  const paystackKey = process.env.PAYSTACK_SECRET_KEY;
  if (provider === "paystack" && paystackKey) {
    return new PaystackGateway(paystackKey);
  }
  // Default: sandbox (no real money moves; full app flow works for testing)
  return new SandboxGateway();
}

export function newReference(prefix = "amify"): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
}

/** Format minor units to a display string, e.g. 500 -> "GHS 5.00" */
export function formatMoney(minor: number, currency = "GHS"): string {
  return `${currency} ${(minor / 100).toFixed(2)}`;
}
