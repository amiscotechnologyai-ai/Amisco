"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { io, Socket } from "socket.io-client";
import type {
  ServerToClientEvents,
  ClientToServerEvents,
  ChatMessageDTO,
  PollDTO,
  QuestionDTO,
  ReactionDTO,
  TipDTO,
  SpeakerDTO,
  TipGoalDTO,
  ModerationStateDTO,
} from "@/types";

type AmiFySocket = Socket<ServerToClientEvents, ClientToServerEvents>;

let sharedSocket: AmiFySocket | null = null;

function getSocket(): AmiFySocket {
  if (!sharedSocket) {
    sharedSocket = io({
      path: "/api/socket",
      transports: ["websocket", "polling"],
      autoConnect: true,
    });
  }
  return sharedSocket;
}

/** Subscribe to the global live listener count across the whole platform. */
export function useGlobalLiveCount() {
  const [data, setData] = useState({ totalListeners: 0, liveStreams: 0 });

  useEffect(() => {
    const socket = getSocket();
    const handler = (payload: { totalListeners: number; liveStreams: number }) =>
      setData(payload);
    socket.on("global:liveCount", handler);
    return () => {
      socket.off("global:liveCount", handler);
    };
  }, []);

  return data;
}

/** Track per-stream listener counts in real time. */
export function useStreamListeners() {
  const [counts, setCounts] = useState<Record<string, number>>({});

  useEffect(() => {
    const socket = getSocket();
    const handler = ({ streamId, count }: { streamId: string; count: number }) =>
      setCounts((prev) => ({ ...prev, [streamId]: count }));
    socket.on("stream:listeners", handler);
    return () => {
      socket.off("stream:listeners", handler);
    };
  }, []);

  return counts;
}

/** Join a live stream room: presence + live chat. */
export function useLiveStream(streamId: string | null, token: string | null) {
  const [listeners, setListeners] = useState(0);
  const [messages, setMessages] = useState<ChatMessageDTO[]>([]);
  const socketRef = useRef<AmiFySocket | null>(null);

  useEffect(() => {
    if (!streamId) return;
    const socket = getSocket();
    socketRef.current = socket;

    socket.emit("stream:join", streamId);

    const onListeners = ({
      streamId: sid,
      count,
    }: {
      streamId: string;
      count: number;
    }) => {
      if (sid === streamId) setListeners(count);
    };
    const onMessage = (msg: ChatMessageDTO) => {
      if (msg.streamId === streamId)
        setMessages((prev) => [...prev, msg].slice(-200));
    };

    socket.on("stream:listeners", onListeners);
    socket.on("chat:message", onMessage);

    return () => {
      socket.emit("stream:leave", streamId);
      socket.off("stream:listeners", onListeners);
      socket.off("chat:message", onMessage);
    };
  }, [streamId]);

  const sendMessage = useCallback(
    (content: string) => {
      if (!streamId || !token || !socketRef.current) return;
      socketRef.current.emit("chat:send", { streamId, content, token });
    },
    [streamId, token]
  );

  const setInitialMessages = useCallback((msgs: ChatMessageDTO[]) => {
    setMessages(msgs);
  }, []);

  return { listeners, messages, sendMessage, setInitialMessages };
}

export interface FloatingReaction {
  id: number;
  emoji: string;
}

/**
 * Full live-engagement hook: polls, Q&A, floating reactions, tips and the
 * multi-speaker stage — all real-time over the shared socket.
 */
export function useEngagement(streamId: string | null, token: string | null) {
  const [polls, setPolls] = useState<PollDTO[]>([]);
  const [questions, setQuestions] = useState<QuestionDTO[]>([]);
  const [reactions, setReactions] = useState<FloatingReaction[]>([]);
  const [tips, setTips] = useState<TipDTO[]>([]);
  const [speakers, setSpeakers] = useState<SpeakerDTO[]>([]);
  const [pinned, setPinned] = useState<ChatMessageDTO | null>(null);
  const [tipGoal, setTipGoal] = useState<TipGoalDTO | null>(null);
  const [moderation, setModeration] = useState<ModerationStateDTO | null>(null);
  const [chatError, setChatError] = useState<string | null>(null);
  const reactionId = useRef(0);

  useEffect(() => {
    if (!streamId) return;
    const socket = getSocket();

    const onPollNew = (p: PollDTO) =>
      p.streamId === streamId && setPolls((prev) => [...prev, p]);
    const onPollUpdate = (p: PollDTO) =>
      setPolls((prev) => prev.map((x) => (x.id === p.id ? p : x)));
    const onQNew = (q: QuestionDTO) =>
      q.streamId === streamId && setQuestions((prev) => [...prev, q]);
    const onQUpdate = (q: QuestionDTO) =>
      setQuestions((prev) => prev.map((x) => (x.id === q.id ? q : x)));
    const onReaction = (r: ReactionDTO) => {
      if (r.streamId !== streamId) return;
      const id = ++reactionId.current;
      setReactions((prev) => [...prev, { id, emoji: r.emoji }]);
      setTimeout(
        () => setReactions((prev) => prev.filter((x) => x.id !== id)),
        2500
      );
    };
    const onTip = (t: TipDTO) => {
      if (t.streamId === streamId) setTips((prev) => [...prev, t].slice(-30));
    };
    const onStage = (payload: { streamId: string; speakers: SpeakerDTO[] }) => {
      if (payload.streamId === streamId) setSpeakers(payload.speakers);
    };
    const onPinned = (payload: {
      streamId: string;
      message: ChatMessageDTO | null;
    }) => {
      if (payload.streamId === streamId) setPinned(payload.message);
    };
    const onTipGoal = (g: TipGoalDTO) => {
      if (g.streamId === streamId) setTipGoal(g);
    };
    const onModState = (m: ModerationStateDTO) => {
      if (m.streamId === streamId) setModeration(m);
    };
    const onModMuted = (p: { streamId: string; userId: string; muted: boolean }) => {
      if (p.streamId !== streamId) return;
      setModeration((prev) => {
        if (!prev) return prev;
        const set = new Set(prev.mutedUserIds);
        if (p.muted) set.add(p.userId);
        else set.delete(p.userId);
        return { ...prev, mutedUserIds: Array.from(set) };
      });
    };
    const onModBanned = (p: { streamId: string; userId: string; banned: boolean }) => {
      if (p.streamId !== streamId) return;
      setModeration((prev) => {
        if (!prev) return prev;
        const set = new Set(prev.bannedUserIds);
        if (p.banned) set.add(p.userId);
        else set.delete(p.userId);
        return { ...prev, bannedUserIds: Array.from(set) };
      });
    };
    const onChatRejected = (p: { streamId: string; reason: string; cooldownSec?: number }) => {
      if (p.streamId !== streamId) return;
      setChatError(p.cooldownSec ? `${p.reason} (${p.cooldownSec}s)` : p.reason);
      setTimeout(() => setChatError(null), 3000);
    };

    socket.on("poll:new", onPollNew);
    socket.on("poll:update", onPollUpdate);
    socket.on("question:new", onQNew);
    socket.on("question:update", onQUpdate);
    socket.on("reaction:burst", onReaction);
    socket.on("tip:received", onTip);
    socket.on("stage:update", onStage);
    socket.on("chat:pinned", onPinned);
    socket.on("tipGoal:update", onTipGoal);
    socket.on("mod:state", onModState);
    socket.on("mod:muted", onModMuted);
    socket.on("mod:banned", onModBanned);
    socket.on("chat:rejected", onChatRejected);

    return () => {
      socket.off("poll:new", onPollNew);
      socket.off("poll:update", onPollUpdate);
      socket.off("question:new", onQNew);
      socket.off("question:update", onQUpdate);
      socket.off("reaction:burst", onReaction);
      socket.off("tip:received", onTip);
      socket.off("stage:update", onStage);
      socket.off("chat:pinned", onPinned);
      socket.off("tipGoal:update", onTipGoal);
      socket.off("mod:state", onModState);
      socket.off("mod:muted", onModMuted);
      socket.off("mod:banned", onModBanned);
      socket.off("chat:rejected", onChatRejected);
    };
  }, [streamId]);

  const s = () => getSocket();

  return {
    polls,
    questions,
    reactions,
    tips,
    speakers,
    pinned,
    tipGoal,
    moderation,
    chatError,
    setQuestions, // for seeding from REST
    createPoll: (question: string, options: string[]) =>
      streamId && token && s().emit("poll:create", { streamId, question, options, token }),
    votePoll: (pollId: string, optionId: string) =>
      token && s().emit("poll:vote", { pollId, optionId, token }),
    closePoll: (pollId: string) =>
      token && s().emit("poll:close", { pollId, token }),
    askQuestion: (content: string) =>
      streamId && token && s().emit("question:ask", { streamId, content, token }),
    upvoteQuestion: (questionId: string) =>
      token && s().emit("question:upvote", { questionId, token }),
    answerQuestion: (questionId: string) =>
      token && s().emit("question:answer", { questionId, token }),
    sendReaction: (emoji: string) =>
      streamId && token && s().emit("reaction:send", { streamId, emoji, token }),
    raiseHand: () =>
      streamId && token && s().emit("stage:raiseHand", { streamId, token }),
    inviteToStage: (userId: string) =>
      streamId && token && s().emit("stage:invite", { streamId, userId, token }),
    setMute: (muted: boolean) =>
      streamId && token && s().emit("stage:setMute", { streamId, muted, token }),
    leaveStage: () =>
      streamId && token && s().emit("stage:leave", { streamId, token }),
    pinMessage: (messageId: string | null) =>
      streamId && token && s().emit("chat:pin", { streamId, messageId, token }),
    // tip goals
    createTipGoal: (title: string, targetMinor: number) =>
      streamId && token && s().emit("tipGoal:create", { streamId, title, targetMinor, token }),
    // moderation
    setSlowMode: (seconds: number) =>
      streamId && token && s().emit("mod:setSlowMode", { streamId, seconds, token }),
    setBannedWords: (words: string) =>
      streamId && token && s().emit("mod:setBannedWords", { streamId, words, token }),
    muteUser: (userId: string, muted: boolean) =>
      streamId && token && s().emit("mod:mute", { streamId, userId, muted, token }),
    kickUser: (userId: string) =>
      streamId && token && s().emit("mod:kick", { streamId, userId, token }),
    banUser: (userId: string, banned: boolean) =>
      streamId && token && s().emit("mod:ban", { streamId, userId, banned, token }),
  };
}
