// hooks/useBackgroundAudio.ts
// Hook to manage background audio in live streams

import { useEffect, useState } from 'react';
import { bgAudio } from '@/lib/backgroundAudio';
import type { Socket } from 'socket.io-client';

interface UseBackgroundAudioOptions {
  streamId?: string;
  streamTitle?: string;
  creatorName?: string;
  creatorColor?: string;
  socket?: Socket;
}

export function useBackgroundAudio({
  streamId,
  streamTitle,
  creatorName,
  creatorColor,
  socket,
}: UseBackgroundAudioOptions) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(1);

  // Initialize background audio on component mount
  useEffect(() => {
    bgAudio.init().catch(console.error);
    bgAudio.persistAcrossNavigation();
  }, []);

  // Subscribe to audio events
  useEffect(() => {
    const unsubPlay = bgAudio.on('play', () => setIsPlaying(true));
    const unsubPause = bgAudio.on('pause', () => setIsPlaying(false));
    const unsubMuted = bgAudio.on('muted', (muted: boolean) => setIsMuted(muted));
    const unsubVolume = bgAudio.on('volume', (vol: number) => setVolume(vol));

    return () => {
      unsubPlay();
      unsubPause();
      unsubMuted();
      unsubVolume();
    };
  }, []);

  // When stream changes, start playing
  useEffect(() => {
    if (streamId && socket) {
      // Note: In production, audioUrl would come from your stream/livekit setup
      // For now, we assume the app has an audio source already configured
      console.log('[useBackgroundAudio] Starting stream:', streamId);

      // Show now-playing notification
      if (streamTitle && creatorName) {
        bgAudio.showNowPlayingNotification(streamTitle, creatorName);
      }
    }
  }, [streamId, socket, streamTitle, creatorName]);

  const startPlayback = async (audioUrl: string) => {
    if (streamId && socket) {
      await bgAudio.play(streamId, audioUrl, socket);
    }
  };

  const stopPlayback = () => {
    bgAudio.stop();
  };

  return {
    isPlaying,
    isMuted,
    volume,
    startPlayback,
    stopPlayback,
    pause: () => bgAudio.pause(),
    resume: () => bgAudio.resume(),
    setVolume: (vol: number) => bgAudio.setVolume(vol),
    setMuted: (muted: boolean) => bgAudio.setMuted(muted),
  };
}
