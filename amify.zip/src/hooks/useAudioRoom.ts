"use client";

import { useEffect, useState, useCallback, useRef } from "react";

/**
 * useAudioRoom — connects to the LiveKit audio room for a stream.
 *
 * It first asks our backend for a token (/api/livekit-token). If LiveKit
 * isn't configured yet, it reports `configured: false` and the UI shows
 * a friendly notice while every other live feature keeps working.
 *
 * When configured, install `livekit-client` and this hook will connect,
 * publish the mic for hosts/speakers, and play remote audio for listeners.
 */
export interface AudioRoomState {
  configured: boolean;
  connected: boolean;
  canPublish: boolean;
  micEnabled: boolean;
  message?: string;
}

export function useAudioRoom(streamId: string | null, token: string | null) {
  const [state, setState] = useState<AudioRoomState>({
    configured: false,
    connected: false,
    canPublish: false,
    micEnabled: false,
  });
  const roomRef = useRef<any>(null);

  useEffect(() => {
    if (!streamId || !token) return;
    let cancelled = false;

    (async () => {
      try {
        const res = await fetch("/api/livekit-token", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ streamId }),
        });
        const data = await res.json();
        if (cancelled) return;

        if (!data.configured) {
          setState((s) => ({
            ...s,
            configured: false,
            canPublish: data.canPublish,
            message: data.message,
          }));
          return;
        }

        // LiveKit is configured. Dynamically import the client SDK.
        // (Install with: npm i livekit-client)
        try {
          const LiveKit = await import(
            /* webpackIgnore: true */ "livekit-client" as any
          ).catch(() => null);

          if (!LiveKit) {
            setState((s) => ({
              ...s,
              configured: true,
              canPublish: data.canPublish,
              message:
                "Run `npm i livekit-client` to enable in-browser live audio.",
            }));
            return;
          }

          const room = new LiveKit.Room({ adaptiveStream: true, dynacast: true });
          await room.connect(data.url, data.token);
          roomRef.current = room;

          if (data.canPublish) {
            await room.localParticipant.setMicrophoneEnabled(true);
          }

          // Auto-play remote audio tracks
          room.on(
            LiveKit.RoomEvent.TrackSubscribed,
            (track: any) => {
              if (track.kind === "audio") {
                const el = track.attach();
                document.body.appendChild(el);
              }
            }
          );

          setState({
            configured: true,
            connected: true,
            canPublish: data.canPublish,
            micEnabled: data.canPublish,
          });
        } catch (e) {
          setState((s) => ({
            ...s,
            configured: true,
            canPublish: data.canPublish,
            message: "Audio SDK unavailable in this build.",
          }));
        }
      } catch {
        // token endpoint failed; non-fatal
      }
    })();

    return () => {
      cancelled = true;
      if (roomRef.current) {
        roomRef.current.disconnect();
        roomRef.current = null;
      }
    };
  }, [streamId, token]);

  const toggleMic = useCallback(async () => {
    const room = roomRef.current;
    if (!room) return;
    const next = !state.micEnabled;
    await room.localParticipant.setMicrophoneEnabled(next);
    setState((s) => ({ ...s, micEnabled: next }));
  }, [state.micEnabled]);

  return { ...state, toggleMic };
}
