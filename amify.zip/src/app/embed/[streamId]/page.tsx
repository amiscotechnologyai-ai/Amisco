import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

/**
 * Embeddable player widget — creators drop this on their own site via an iframe:
 *   <iframe src="https://YOURDOMAIN/embed/STREAM_ID" width="100%" height="180"
 *           frameborder="0" allow="autoplay"></iframe>
 *
 * Intentionally standalone (no app shell) and lightweight.
 */
export default async function EmbedPage({ params }: { params: { streamId: string } }) {
  const stream = await prisma.stream.findUnique({
    where: { id: params.streamId },
    include: { host: true, show: true },
  });

  if (!stream) {
    return (
      <div style={shell}>
        <p style={{ opacity: 0.7 }}>Stream not found.</p>
      </div>
    );
  }

  const isLive = stream.status === "LIVE";
  const accent = stream.coverColor || "#7c3aed";

  return (
    <div style={{ ...shell, background: `linear-gradient(135deg, ${accent}22, #0b0b12)` }}>
      <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
        <div style={{ ...cover, background: accent }}>{stream.emoji || "🎙️"}</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            {isLive && <span style={liveDot} />}
            <span style={{ fontSize: 11, letterSpacing: 1, textTransform: "uppercase", opacity: 0.8 }}>
              {isLive ? "Live now" : stream.status === "SCHEDULED" ? "Scheduled" : "Ended"}
            </span>
          </div>
          <div style={{ fontSize: 16, fontWeight: 700, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
            {stream.title}
          </div>
          <div style={{ fontSize: 13, opacity: 0.7 }}>
            {stream.host.displayName} · {stream.listenerCount} listening
          </div>
        </div>
        <a href={`/?stream=${stream.id}`} target="_blank" rel="noopener noreferrer" style={{ ...cta, background: accent }}>
          {isLive ? "Listen ▶" : "Open"}
        </a>
      </div>
      <div style={{ marginTop: 10, fontSize: 11, opacity: 0.5, textAlign: "right" }}>
        Powered by AmiFy
      </div>
    </div>
  );
}

const shell: React.CSSProperties = {
  fontFamily: "system-ui, -apple-system, sans-serif",
  color: "#fff",
  background: "#0b0b12",
  borderRadius: 16,
  padding: 16,
  width: "100%",
  boxSizing: "border-box",
};
const cover: React.CSSProperties = {
  width: 56,
  height: 56,
  borderRadius: 12,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  fontSize: 26,
  flexShrink: 0,
};
const liveDot: React.CSSProperties = {
  width: 8,
  height: 8,
  borderRadius: "50%",
  background: "#ef4444",
  display: "inline-block",
};
const cta: React.CSSProperties = {
  color: "#fff",
  textDecoration: "none",
  fontWeight: 700,
  fontSize: 13,
  padding: "8px 14px",
  borderRadius: 999,
  whiteSpace: "nowrap",
};
