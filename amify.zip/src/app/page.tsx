"use client";

import { useState, useEffect, useCallback } from "react";
import {
  Radio,
  Mic,
  TrendingUp,
  Settings,
  LogOut,
  Edit3,
  Search as SearchIcon,
  Zap,
  Plus,
} from "lucide-react";
import AppShell, { Page } from "@/components/AppShell";
import LiveStreamCard from "@/components/LiveStreamCard";
import LiveRoom from "@/components/LiveRoom";
import AuthModal from "@/components/AuthModal";
import AnalyticsDashboard from "@/components/AnalyticsDashboard";
import { useAuth } from "@/context/AuthContext";
import { useGlobalLiveCount, useStreamListeners } from "@/hooks/useSocket";
import type { StreamDTO, ShowDTO } from "@/types";

const CATEGORIES = ["All", "Music", "Talk", "News", "Technology", "Wellness", "Sports"];

export default function AmiFyApp() {
  const { user, token, logout } = useAuth();
  const [page, setPage] = useState<Page>("home");
  const [streams, setStreams] = useState<StreamDTO[]>([]);
  const [shows, setShows] = useState<ShowDTO[]>([]);
  const [activeStream, setActiveStream] = useState<StreamDTO | null>(null);
  const [showAuth, setShowAuth] = useState(false);
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [showGoLive, setShowGoLive] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState(false);
  const [showSchedule, setShowSchedule] = useState(false);

  const global = useGlobalLiveCount();
  const liveCounts = useStreamListeners();

  const loadStreams = useCallback(async () => {
    const res = await fetch(`/api/streams?status=LIVE&category=${category}`);
    if (res.ok) setStreams(await res.json());
  }, [category]);

  const loadShows = useCallback(async () => {
    const res = await fetch(`/api/shows?trending=true`);
    if (res.ok) setShows(await res.json());
  }, []);

  useEffect(() => {
    loadStreams();
    loadShows();
  }, [loadStreams, loadShows]);

  // Refresh streams periodically as a fallback to socket events
  useEffect(() => {
    const t = setInterval(loadStreams, 15000);
    return () => clearInterval(t);
  }, [loadStreams]);

  const requireAuth = (fn: () => void) => {
    if (!user) setShowAuth(true);
    else fn();
  };

  const totalListeners =
    global.totalListeners ||
    streams.reduce((a, s) => a + (liveCounts[s.id] ?? s.listenerCount), 0);

  // ---- HOME ----
  const Home = () => (
    <div className="px-4 md:px-6 pt-6 space-y-8 animate-fade-up">
      <div>
        <p className="text-brand-500 font-bold text-sm tracking-wide">AMIFY</p>
        <h1 className="text-4xl font-black">
          {greeting()} {user ? user.displayName.split(" ")[0] : ""} 👋
        </h1>
        <p className="text-[var(--text-muted)] mt-1">
          {global.liveStreams || streams.length} live now ·{" "}
          {totalListeners.toLocaleString()} listening
        </p>
      </div>

      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-2xl font-black flex items-center gap-2">
            <span className="w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse" />
            Live Now
          </h2>
        </div>
        {streams.length === 0 ? (
          <EmptyState
            title="No live streams yet"
            subtitle="Be the first to go live"
            cta="Go Live"
            onClick={() => requireAuth(() => setShowGoLive(true))}
          />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {streams.map((s) => (
              <LiveStreamCard
                key={s.id}
                stream={s}
                liveCount={liveCounts[s.id]}
                onClick={() => setActiveStream(s)}
              />
            ))}
          </div>
        )}
      </section>

      <section>
        <h2 className="text-2xl font-black mb-3">Trending Shows</h2>
        {shows.length === 0 ? (
          <p className="text-[var(--text-muted)] text-sm">
            No shows published yet.
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {shows.map((show) => (
              <div
                key={show.id}
                className="rounded-2xl p-4 cursor-pointer transition hover:scale-[1.02]"
                style={{
                  background: `linear-gradient(135deg, ${show.coverColor}, ${show.coverColor}55)`,
                }}
              >
                <div className="text-3xl mb-6">{show.emoji}</div>
                <p className="text-[10px] font-black uppercase tracking-wider text-white/70">
                  {show.category}
                </p>
                <h3 className="font-bold text-white truncate">{show.title}</h3>
                <p className="text-xs text-white/70 truncate">
                  {show.ownerName}
                </p>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );

  // ---- LIVE ----
  const Live = () => (
    <div className="px-4 md:px-6 pt-6 animate-fade-up">
      <div className="flex items-center gap-2 mb-1">
        <span className="w-3 h-3 bg-red-500 rounded-full animate-pulse" />
        <h1 className="text-3xl font-black">Live Now</h1>
      </div>
      <p className="text-[var(--text-muted)] mb-5">
        {totalListeners.toLocaleString()} listeners
      </p>

      <div className="flex gap-2 mb-6 overflow-x-auto scrollbar-hide pb-1">
        {CATEGORIES.map((c) => (
          <button
            key={c}
            onClick={() => setCategory(c)}
            className={`px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition ${
              category === c
                ? "bg-gradient-to-r from-brand-600 to-indigo-600 text-white"
                : "bg-[var(--bg-elevated)] text-[var(--text-muted)] hover:text-[var(--text)]"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {streams.length === 0 ? (
        <EmptyState
          title="Nothing live in this category"
          subtitle="Check back soon or start your own stream"
          cta="Go Live"
          onClick={() => requireAuth(() => setShowGoLive(true))}
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {streams.map((s) => (
            <LiveStreamCard
              key={s.id}
              stream={s}
              liveCount={liveCounts[s.id]}
              onClick={() => setActiveStream(s)}
            />
          ))}
        </div>
      )}
    </div>
  );

  // ---- SEARCH ----
  const Search = () => {
    const filtered = streams.filter(
      (s) =>
        s.title.toLowerCase().includes(search.toLowerCase()) ||
        s.hostName.toLowerCase().includes(search.toLowerCase())
    );
    return (
      <div className="px-4 md:px-6 pt-6 animate-fade-up">
        <h1 className="text-4xl font-black mb-4">Search</h1>
        <div className="flex items-center gap-3 px-4 py-3 rounded-full bg-[var(--bg-elevated)] border border-[var(--border)] mb-6">
          <SearchIcon size={20} className="text-[var(--text-muted)]" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Shows, episodes, creators…"
            className="flex-1 bg-transparent outline-none"
          />
        </div>

        {search ? (
          filtered.length ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {filtered.map((s) => (
                <LiveStreamCard
                  key={s.id}
                  stream={s}
                  liveCount={liveCounts[s.id]}
                  onClick={() => setActiveStream(s)}
                />
              ))}
            </div>
          ) : (
            <p className="text-[var(--text-muted)]">
              No results for &ldquo;{search}&rdquo;
            </p>
          )
        ) : (
          <>
            <h3 className="font-black text-lg mb-3">Browse Categories</h3>
            <div className="grid grid-cols-2 gap-3">
              {[
                { name: "Music", c: "#6d28d9" },
                { name: "Talk", c: "#d97706" },
                { name: "News", c: "#dc2626" },
                { name: "Technology", c: "#059669" },
              ].map((cat) => (
                <button
                  key={cat.name}
                  onClick={() => {
                    setCategory(cat.name);
                    setPage("live");
                  }}
                  className="rounded-2xl p-6 text-white font-bold text-left transition hover:scale-[1.02]"
                  style={{
                    background: `linear-gradient(135deg, ${cat.c}, ${cat.c}88)`,
                  }}
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </>
        )}
      </div>
    );
  };

  // ---- LIBRARY ----
  const LibraryView = () => {
    const [tab, setTab] = useState<"subscribed" | "saved" | "history">(
      "subscribed"
    );
    const [data, setData] = useState<any>({
      subscribed: [],
      saved: [],
      history: [],
    });

    useEffect(() => {
      if (!token) return;
      fetch("/api/library", {
        headers: { Authorization: `Bearer ${token}` },
      })
        .then((r) => (r.ok ? r.json() : null))
        .then((d) => d && setData(d))
        .catch(() => {});
    }, []);

    if (!user) {
      return (
        <div className="px-4 pt-20">
          <EmptyState
            title="Your library awaits"
            subtitle="Sign in to follow shows and save episodes"
            cta="Sign In"
            onClick={() => setShowAuth(true)}
          />
        </div>
      );
    }

    const items = data[tab] || [];

    return (
      <div className="pt-6 animate-fade-up">
        <h1 className="text-4xl font-black px-4 md:px-6 mb-4">My Library</h1>
        <div className="flex border-b border-[var(--border)] px-2">
          {(["subscribed", "saved", "history"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`flex-1 py-3 font-bold capitalize text-sm border-b-2 transition ${
                tab === t
                  ? "border-brand-500 text-brand-500"
                  : "border-transparent text-[var(--text-muted)]"
              }`}
            >
              {t}
            </button>
          ))}
        </div>
        <div className="p-4 md:px-6 space-y-3">
          {items.length === 0 ? (
            <p className="text-center text-[var(--text-muted)] py-10">
              Nothing here yet.
            </p>
          ) : (
            items.map((item: any) => (
              <div
                key={item.id}
                className="p-4 rounded-2xl bg-[var(--bg-elevated)]"
              >
                <h3 className="font-bold">{item.title}</h3>
                <p className="text-sm text-[var(--text-muted)]">
                  {item.host}
                  {item.episodes ? ` · ${item.episodes} episodes` : ""}
                  {item.duration ? ` · ${item.duration}` : ""}
                </p>
                {typeof item.progress === "number" && (
                  <div className="h-1.5 rounded-full bg-[var(--bg)] mt-2">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-brand-500 to-pink-500"
                      style={{ width: `${item.progress}%` }}
                    />
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    );
  };

  // ---- PROFILE ----
  const Profile = () => {
    if (!user) {
      return (
        <div className="px-4 pt-20">
          <EmptyState
            title="Welcome to AmiFy"
            subtitle="Sign in to access your profile and creator tools"
            cta="Sign In"
            onClick={() => setShowAuth(true)}
          />
        </div>
      );
    }
    return (
      <div className="animate-fade-up">
        <div className="p-6 bg-[var(--bg-elevated)]">
          <div className="flex items-center gap-4 mb-6">
            <div
              className="w-20 h-20 rounded-full flex items-center justify-center text-white font-black text-2xl"
              style={{ backgroundColor: user.avatarColor }}
            >
              {user.displayName.slice(0, 2).toUpperCase()}
            </div>
            <div className="flex-1">
              <h1 className="text-2xl font-black">{user.displayName}</h1>
              <p className="text-sm text-[var(--text-muted)]">
                @{user.username}
              </p>
              <span className="inline-flex items-center gap-1 text-xs font-bold mt-1 px-2 py-1 rounded-full bg-brand-500/15 text-brand-500">
                <Zap size={12} /> {user.plan} Plan
              </span>
            </div>
            <button className="p-3 rounded-full bg-[var(--bg)] hover:opacity-80 transition">
              <Edit3 size={18} />
            </button>
          </div>
        </div>

        <div className="p-6 space-y-3">
          <h2 className="text-lg font-black mb-1">Creator Tools</h2>
          <ActionButton
            icon={Radio}
            label="Start a Live Stream"
            sub="Go live and connect in real time"
            tone="red"
            onClick={() => setShowGoLive(true)}
          />
          <ActionButton
            icon={Plus}
            label="Schedule a Stream"
            sub="Plan ahead and let fans set reminders"
            tone="brand"
            onClick={() => setShowSchedule(true)}
          />
          <ActionButton
            icon={Mic}
            label="Record an Episode"
            sub="Record, edit and publish podcasts"
            tone="brand"
            onClick={() => {}}
          />
          <ActionButton
            icon={TrendingUp}
            label="Analytics Dashboard"
            sub="Earnings, audience and top content"
            tone="muted"
            onClick={() => setShowAnalytics(true)}
          />
        </div>

        <div className="p-6 space-y-3">
          <h2 className="text-lg font-black mb-1">Account</h2>
          <ActionButton
            icon={Settings}
            label="Settings"
            tone="muted"
            onClick={() => {}}
          />
          <ActionButton
            icon={LogOut}
            label="Sign Out"
            tone="red"
            onClick={logout}
          />
        </div>

        <footer className="px-6 pb-10 pt-4 text-xs text-[var(--text-muted)] space-y-1">
          <p className="font-bold text-[var(--text)]">
            Amisco Technology (AmiTech)
          </p>
          <p>Developer: Hon. Dr. Amisco</p>
          <p>+233 54 654 2046</p>
          <p>hondramisco@gmail.com · amiscotechnology@gmail.com</p>
        </footer>
      </div>
    );
  };

  return (
    <>
      <AppShell current={page} onNavigate={setPage}>
        {page === "home" && <Home />}
        {page === "live" && <Live />}
        {page === "search" && <Search />}
        {page === "library" && <LibraryView />}
        {page === "profile" && <Profile />}
      </AppShell>

      {/* Floating Go Live button */}
      {(page === "home" || page === "live") && (
        <button
          onClick={() => requireAuth(() => setShowGoLive(true))}
          className="fixed bottom-24 right-5 z-40 flex items-center gap-2 px-5 py-3.5 rounded-full bg-gradient-to-r from-red-500 to-pink-600 text-white font-bold shadow-2xl hover:scale-105 transition animate-pulse-glow"
        >
          <Radio size={20} /> Go Live
        </button>
      )}

      {activeStream && (
        <LiveRoom stream={activeStream} onClose={() => setActiveStream(null)} />
      )}
      {showAuth && <AuthModal onClose={() => setShowAuth(false)} />}
      {showAnalytics && (
        <AnalyticsDashboard onClose={() => setShowAnalytics(false)} />
      )}
      {showSchedule && (
        <ScheduleModal
          token={token}
          onClose={() => setShowSchedule(false)}
          onScheduled={() => setShowSchedule(false)}
        />
      )}
      {showGoLive && (
        <GoLiveModal
          token={token}
          onClose={() => setShowGoLive(false)}
          onCreated={(s) => {
            setShowGoLive(false);
            loadStreams();
            setActiveStream(s);
          }}
        />
      )}
    </>
  );
}

// ---- Helper components ----

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 18) return "Good afternoon";
  return "Good evening";
}

function EmptyState({
  title,
  subtitle,
  cta,
  onClick,
}: {
  title: string;
  subtitle: string;
  cta: string;
  onClick: () => void;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      <div className="w-16 h-16 rounded-2xl bg-[var(--bg-elevated)] flex items-center justify-center mb-4">
        <Radio size={28} className="text-brand-500" />
      </div>
      <h3 className="text-xl font-black">{title}</h3>
      <p className="text-[var(--text-muted)] mb-5">{subtitle}</p>
      <button
        onClick={onClick}
        className="px-6 py-3 rounded-full bg-gradient-to-r from-brand-600 to-indigo-600 text-white font-bold hover:opacity-90 transition"
      >
        {cta}
      </button>
    </div>
  );
}

function ActionButton({
  icon: Icon,
  label,
  sub,
  tone,
  onClick,
}: {
  icon: typeof Radio;
  label: string;
  sub?: string;
  tone: "red" | "brand" | "muted";
  onClick: () => void;
}) {
  const tones = {
    red: "bg-red-500/10 text-red-500 border-red-500/20",
    brand: "bg-brand-500/10 text-brand-500 border-brand-500/20",
    muted: "bg-[var(--bg-elevated)] text-[var(--text)] border-[var(--border)]",
  };
  return (
    <button
      onClick={onClick}
      className={`w-full p-4 rounded-2xl border flex items-center gap-3 text-left transition hover:opacity-90 ${tones[tone]}`}
    >
      <Icon size={22} />
      <div>
        <p className="font-bold">{label}</p>
        {sub && <p className="text-xs opacity-70">{sub}</p>}
      </div>
    </button>
  );
}

function GoLiveModal({
  token,
  onClose,
  onCreated,
}: {
  token: string | null;
  onClose: () => void;
  onCreated: (s: StreamDTO) => void;
}) {
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("Music");
  const [emoji, setEmoji] = useState("🎙️");
  const [loading, setLoading] = useState(false);
  const colors = ["#6d28d9", "#dc2626", "#059669", "#d97706", "#2563eb"];
  const [coverColor, setCoverColor] = useState(colors[0]);

  const create = async () => {
    if (!title.trim() || !token) return;
    setLoading(true);
    const res = await fetch("/api/streams", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ title, category, emoji, coverColor }),
    });
    setLoading(false);
    if (res.ok) onCreated(await res.json());
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-md rounded-3xl bg-[var(--bg-elevated)] border border-[var(--border)] p-6">
        <div className="flex items-center gap-2 mb-5">
          <Radio className="text-red-500" />
          <h2 className="text-2xl font-black">Go Live</h2>
        </div>
        <div className="space-y-3">
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Stream title"
            className="w-full px-4 py-3 rounded-xl bg-[var(--bg)] border border-[var(--border)] outline-none focus:border-brand-500"
          />
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full px-4 py-3 rounded-xl bg-[var(--bg)] border border-[var(--border)] outline-none"
          >
            {CATEGORIES.filter((c) => c !== "All").map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
          <div className="flex gap-2">
            {["🎙️", "🎵", "🤖", "🧘", "🏆", "🔥", "🎷", "💻"].map((e) => (
              <button
                key={e}
                onClick={() => setEmoji(e)}
                className={`text-2xl p-2 rounded-lg transition ${
                  emoji === e ? "bg-brand-500/20 scale-110" : ""
                }`}
              >
                {e}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            {colors.map((c) => (
              <button
                key={c}
                onClick={() => setCoverColor(c)}
                className={`w-8 h-8 rounded-full transition ${
                  coverColor === c ? "ring-2 ring-offset-2 ring-offset-[var(--bg-elevated)] ring-white scale-110" : ""
                }`}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>
          <button
            onClick={create}
            disabled={loading || !title.trim()}
            className="w-full py-3 rounded-xl font-bold bg-gradient-to-r from-red-500 to-pink-600 text-white hover:opacity-90 transition disabled:opacity-50"
          >
            {loading ? "Starting…" : "Start Streaming"}
          </button>
          <button
            onClick={onClose}
            className="w-full text-sm text-[var(--text-muted)]"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}

function ScheduleModal({
  token,
  onClose,
  onScheduled,
}: {
  token: string | null;
  onClose: () => void;
  onScheduled: () => void;
}) {
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("Music");
  const [when, setWhen] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    if (!title.trim() || !when || !token) return;
    setLoading(true);
    const res = await fetch("/api/schedule", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        title,
        category,
        scheduledFor: new Date(when).toISOString(),
      }),
    });
    setLoading(false);
    if (res.ok) onScheduled();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-md rounded-3xl bg-[var(--bg-elevated)] border border-[var(--border)] p-6">
        <h2 className="text-2xl font-black mb-4">Schedule a Stream</h2>
        <div className="space-y-3">
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Stream title"
            className="w-full px-4 py-3 rounded-xl bg-[var(--bg)] border border-[var(--border)] outline-none focus:border-brand-500"
          />
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full px-4 py-3 rounded-xl bg-[var(--bg)] border border-[var(--border)] outline-none"
          >
            {CATEGORIES.filter((c) => c !== "All").map((c) => (
              <option key={c}>{c}</option>
            ))}
          </select>
          <input
            type="datetime-local"
            value={when}
            onChange={(e) => setWhen(e.target.value)}
            className="w-full px-4 py-3 rounded-xl bg-[var(--bg)] border border-[var(--border)] outline-none focus:border-brand-500"
          />
          <button
            onClick={submit}
            disabled={loading || !title.trim() || !when}
            className="w-full py-3 rounded-xl font-bold bg-gradient-to-r from-brand-600 to-indigo-600 text-white hover:opacity-90 transition disabled:opacity-50"
          >
            {loading ? "Scheduling…" : "Schedule Stream"}
          </button>
          <button
            onClick={onClose}
            className="w-full text-sm text-[var(--text-muted)]"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}
