import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";

// GET /api/memberships?creatorId=... — list a creator's membership tiers
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const creatorId = searchParams.get("creatorId");
    const tiers = await prisma.membershipTier.findMany({
      where: creatorId ? { creatorId } : {},
      include: { _count: { select: { memberships: true } } },
      orderBy: { priceMinor: "asc" },
    });
    return NextResponse.json(
      tiers.map((t) => ({
        id: t.id,
        name: t.name,
        priceMinor: t.priceMinor,
        currency: t.currency,
        perks: safeParse(t.perks),
        memberCount: t._count.memberships,
      }))
    );
  } catch (err) {
    console.error("[api/memberships GET] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

// POST /api/memberships — create a tier (creator) or join one (member)
export async function POST(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload)
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();

    if (body.action === "create") {
      const { name, priceMinor, perks } = body;
      const tier = await prisma.membershipTier.create({
        data: {
          creatorId: payload.userId,
          name,
          priceMinor,
          perks: JSON.stringify(perks || []),
        },
      });
      return NextResponse.json({ id: tier.id, ok: true });
    }

    if (body.action === "join") {
      const { tierId } = body;
      const renewsAt = new Date();
      renewsAt.setMonth(renewsAt.getMonth() + 1);
      await prisma.membership.upsert({
        where: {
          memberId_tierId: { memberId: payload.userId, tierId },
        },
        update: { active: true, renewsAt },
        create: { memberId: payload.userId, tierId, active: true, renewsAt },
      });
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  } catch (err) {
    console.error("[api/memberships POST] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

function safeParse(s: string) {
  try {
    return JSON.parse(s);
  } catch {
    return [];
  }
}
