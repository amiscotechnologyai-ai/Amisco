import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";

// GET /api/badges?creatorId=... — get listener badges
// GET /api/badges — get creator verification status
export async function GET(req: NextRequest) {
  try {
    const creatorId = req.nextUrl.searchParams.get("creatorId");
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;

    if (!creatorId) {
      // VERIFICATION ENDPOINT (no auth required)
      const creatorIdParam = req.nextUrl.searchParams.get("id");
      if (!creatorIdParam) return NextResponse.json({ error: "creatorId or id required" }, { status: 400 });

      const creator = await prisma.user.findUnique({
        where: { id: creatorIdParam },
        select: {
          id: true,
          displayName: true,
          verified: true,
          shows: { select: { _count: { select: { episodes: true } } } },
          _count: { select: { followers: true, following: true } },
        },
      });
      if (!creator) return NextResponse.json({ error: "Creator not found" }, { status: 404 });

      let tier = creator.verified;
      if (tier === "UNVERIFIED") {
        const showCount = creator.shows.length;
        const episodeCount = creator.shows.reduce((sum, s) => sum + s._count.episodes, 0);
        const followers = creator._count.followers;
        if (episodeCount >= 10 && followers >= 100) tier = "RISING" as any;
        if (episodeCount >= 50 && followers >= 1000) tier = "PRO" as any;
      }

      return NextResponse.json({
        creatorId: creator.id,
        displayName: creator.displayName,
        verified: tier,
        stats: {
          shows: creator.shows.length,
          episodes: creator.shows.reduce((sum, s) => sum + s._count.episodes, 0),
          followers: creator._count.followers,
        },
      });
    } else {
      // BADGES ENDPOINT (auth required)
      if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

      const badges = await prisma.listenerBadge.findMany({
        where: { userId: payload.userId, creatorId },
      });

      const isMember = await prisma.membership.findFirst({
        where: { memberId: payload.userId, creatorId },
      });

      const hasTipped = await prisma.tip.findFirst({
        where: { senderId: payload.userId, recipientId: creatorId },
      });

      const isFollowing = await prisma.follow.findFirst({
        where: { followerId: payload.userId, followeeId: creatorId },
      });
      const followedBy = await prisma.follow.findFirst({
        where: { followerId: creatorId, followeeId: payload.userId },
      });
      const isFriend = isFollowing && followedBy;

      const allBadges = new Set<string>();
      badges.forEach((b) => allBadges.add(b.type));
      if (isMember) allBadges.add("member");
      if (hasTipped) allBadges.add("tipper");
      if (isFriend) allBadges.add("friend");

      return NextResponse.json({
        userId: payload.userId,
        creatorId,
        badges: Array.from(allBadges),
        earned: {
          member: !!isMember,
          tipper: !!hasTipped,
          friend: !!isFriend,
        },
      });
    }
  } catch (err) {
    console.error("[api/badges GET] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

// POST /api/badges — award a badge to a listener
export async function POST(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { userId, badgeType } = await req.json();
    if (!userId || !badgeType) return NextResponse.json({ error: "userId and badgeType required" }, { status: 400 });

    // Only creator can award badges in their context
    // This is typically called by server on tip/membership events
    const badge = await prisma.listenerBadge.upsert({
      where: { userId_type_creatorId: { userId, type: badgeType, creatorId: payload.userId } },
      update: { awardedAt: new Date() },
      create: { userId, type: badgeType, creatorId: payload.userId },
    });

    return NextResponse.json({ status: "OK", badge });
  } catch (err) {
    console.error("[api/badges POST] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
