import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";

// GET /api/schedule — upcoming scheduled streams
export async function GET() {
  try {
    const streams = await prisma.stream.findMany({
      where: { status: "SCHEDULED", scheduledFor: { gte: new Date() } },
      include: {
        host: { select: { displayName: true } },
        _count: { select: { reminders: true } },
      },
      orderBy: { scheduledFor: "asc" },
      take: 50,
    });
    return NextResponse.json(
      streams.map((s) => ({
        id: s.id,
        title: s.title,
        category: s.category,
        emoji: s.emoji,
        coverColor: s.coverColor,
        hostName: s.host.displayName,
        scheduledFor: s.scheduledFor?.toISOString(),
        reminderCount: s._count.reminders,
      }))
    );
  } catch (err) {
    console.error("[api/schedule GET] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

// POST /api/schedule — create a scheduled stream OR set a reminder
export async function POST(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload)
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();

    // Set a reminder for an existing scheduled stream
    if (body.action === "remind" && body.streamId) {
      await prisma.streamReminder.upsert({
        where: {
          streamId_userId: { streamId: body.streamId, userId: payload.userId },
        },
        update: {},
        create: { streamId: body.streamId, userId: payload.userId },
      });
      return NextResponse.json({ ok: true });
    }

    // Create a scheduled stream
    const { title, category, emoji, coverColor, scheduledFor } = body;
    if (!title || !category || !scheduledFor) {
      return NextResponse.json({ error: "Missing fields" }, { status: 400 });
    }
    const stream = await prisma.stream.create({
      data: {
        title,
        category,
        emoji: emoji || "🔴",
        coverColor: coverColor || "#4c1d95",
        hostId: payload.userId,
        status: "SCHEDULED",
        scheduledFor: new Date(scheduledFor),
      },
    });
    return NextResponse.json({ id: stream.id, ok: true });
  } catch (err) {
    console.error("[api/schedule POST] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
