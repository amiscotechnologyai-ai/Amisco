import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// GET /api/clips?episodeId=... — list clips for an episode (shareable highlights)
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const episodeId = searchParams.get("episodeId");
    const clips = await prisma.clip.findMany({
      where: episodeId ? { episodeId } : {},
      orderBy: { shareCount: "desc" },
      take: 50,
      include: {
        episode: { select: { title: true, show: { select: { title: true } } } },
      },
    });
    return NextResponse.json(
      clips.map((c) => ({
        id: c.id,
        title: c.title,
        startSec: c.startSec,
        endSec: c.endSec,
        videoUrl: c.videoUrl,
        audioUrl: c.audioUrl,
        shareCount: c.shareCount,
        episodeTitle: c.episode.title,
        showTitle: c.episode.show.title,
      }))
    );
  } catch (err) {
    console.error("[api/clips GET] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

// POST /api/clips/share { clipId } — record a share
export async function POST(req: NextRequest) {
  try {
    const { clipId } = await req.json();
    await prisma.clip.update({
      where: { id: clipId },
      data: { shareCount: { increment: 1 } },
    });
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("[api/clips POST] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
