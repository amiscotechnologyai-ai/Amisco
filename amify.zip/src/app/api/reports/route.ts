import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";

// POST /api/reports — submit a report
// body: { targetType: "stream"|"user"|"message"|"episode", targetId, reason, details? }
export async function POST(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { targetType, targetId, reason, details } = await req.json();
    if (!targetType || !targetId || !reason)
      return NextResponse.json({ error: "targetType, targetId and reason required" }, { status: 400 });

    const report = await prisma.report.create({
      data: {
        reporterId: payload.userId,
        targetType,
        targetId,
        reason: String(reason).slice(0, 200),
        details: details ? String(details).slice(0, 1000) : null,
      },
    });
    return NextResponse.json({ status: "OK", reportId: report.id });
  } catch (err) {
    console.error("[api/reports POST] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

// GET /api/reports — list open reports (admin/moderator view)
export async function GET(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const status = req.nextUrl.searchParams.get("status") || "OPEN";
    const reports = await prisma.report.findMany({
      where: { status: status as "OPEN" | "REVIEWING" | "RESOLVED" | "DISMISSED" },
      orderBy: { createdAt: "desc" },
      take: 100,
    });
    return NextResponse.json({ reports });
  } catch (err) {
    console.error("[api/reports GET] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
