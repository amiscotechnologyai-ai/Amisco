import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";

const LOCALES = ["en", "tw", "ga", "ee", "ha"];

// PATCH /api/settings — update the current user's preferences
export async function PATCH(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const data: Record<string, unknown> = {};

    if (typeof body.locale === "string" && LOCALES.includes(body.locale)) data.locale = body.locale;
    if (typeof body.dataSaver === "boolean") data.dataSaver = body.dataSaver;
    if (typeof body.smsOptIn === "boolean") data.smsOptIn = body.smsOptIn;
    if (typeof body.notificationsOn === "boolean") data.notificationsOn = body.notificationsOn;
    if (typeof body.autoDownload === "boolean") data.autoDownload = body.autoDownload;
    if (typeof body.streamOnWifiOnly === "boolean") data.streamOnWifiOnly = body.streamOnWifiOnly;
    if (typeof body.theme === "string" && ["dark", "light"].includes(body.theme)) data.theme = body.theme;
    if (typeof body.phone === "string") data.phone = body.phone.slice(0, 20);
    if (["LOW", "STANDARD", "HIGH", "LOSSLESS"].includes(body.audioQuality)) data.audioQuality = body.audioQuality;
    if (typeof body.birthDate === "string") {
      const d = new Date(body.birthDate);
      if (!isNaN(d.getTime())) data.birthDate = d;
    }

    if (Object.keys(data).length === 0)
      return NextResponse.json({ error: "Nothing to update" }, { status: 400 });

    const user = await prisma.user.update({ where: { id: payload.userId }, data });
    return NextResponse.json({
      status: "OK",
      settings: {
        locale: user.locale,
        dataSaver: user.dataSaver,
        smsOptIn: user.smsOptIn,
        notificationsOn: user.notificationsOn,
        autoDownload: user.autoDownload,
        streamOnWifiOnly: user.streamOnWifiOnly,
        theme: user.theme,
        phone: user.phone,
        audioQuality: user.audioQuality,
      },
    });
  } catch (err) {
    console.error("[api/settings PATCH] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
