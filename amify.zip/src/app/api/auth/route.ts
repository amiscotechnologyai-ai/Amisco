import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { hashPassword, verifyPassword, signToken } from "@/lib/auth";

// POST /api/auth  — body { action: "register" | "login", ... }
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { action } = body;

    if (action === "register") {
      const { email, username, displayName, password } = body;
      if (!email || !username || !displayName || !password) {
        return NextResponse.json({ error: "Missing fields" }, { status: 400 });
      }

      const existing = await prisma.user.findFirst({
        where: { OR: [{ email }, { username }] },
      });
      if (existing) {
        return NextResponse.json(
          { error: "Email or username already in use" },
          { status: 409 }
        );
      }

      const colors = ["#7c3aed", "#ec4899", "#f97316", "#10b981", "#3b82f6"];
      const user = await prisma.user.create({
        data: {
          email,
          username,
          displayName,
          passwordHash: await hashPassword(password),
          avatarColor: colors[Math.floor(Math.random() * colors.length)],
        },
      });

      const token = signToken({ userId: user.id, username: user.username });
      return NextResponse.json({
        token,
        user: publicUser(user),
      });
    }

    if (action === "login") {
      const { emailOrUsername, password } = body;
      const user = await prisma.user.findFirst({
        where: {
          OR: [{ email: emailOrUsername }, { username: emailOrUsername }],
        },
      });
      if (!user || !(await verifyPassword(password, user.passwordHash))) {
        return NextResponse.json(
          { error: "Invalid credentials" },
          { status: 401 }
        );
      }

      const token = signToken({ userId: user.id, username: user.username });
      return NextResponse.json({ token, user: publicUser(user) });
    }

    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  } catch (err) {
    console.error("[api/auth] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

function publicUser(u: any) {
  return {
    id: u.id,
    email: u.email,
    username: u.username,
    displayName: u.displayName,
    bio: u.bio,
    avatarColor: u.avatarColor,
    plan: u.plan,
    isCreator: u.isCreator,
    theme: u.theme,
  };
}
