import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";
import { createLiveKitToken, isLiveKitConfigured, liveKitUrl } from "@/lib/livekit";

// POST /api/livekit-token  { streamId }
// Returns a LiveKit access token for the audio room.
// Hosts and stage speakers get publish rights; listeners get subscribe-only.
export async function POST(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload)
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { streamId } = await req.json();
    const stream = await prisma.stream.findUnique({ where: { id: streamId } });
    if (!stream)
      return NextResponse.json({ error: "Stream not found" }, { status: 404 });

    const user = await prisma.user.findUnique({ where: { id: payload.userId } });
    if (!user)
      return NextResponse.json({ error: "User not found" }, { status: 404 });

    // Ensure a room name exists for this stream
    const roomName = stream.roomName || `amify_${stream.id}`;
    if (!stream.roomName) {
      await prisma.stream.update({
        where: { id: stream.id },
        data: { roomName },
      });
    }

    // Determine publish rights
    const isHost = stream.hostId === user.id;
    const speaker = await prisma.speaker.findUnique({
      where: { streamId_userId: { streamId, userId: user.id } },
    });
    const canPublish =
      isHost || (speaker && speaker.role !== "LISTENER") || false;

    if (!isLiveKitConfigured()) {
      return NextResponse.json({
        configured: false,
        message:
          "LiveKit not configured. Set LIVEKIT_API_KEY, LIVEKIT_API_SECRET and NEXT_PUBLIC_LIVEKIT_URL to enable live audio. Chat, presence, polls, Q&A and reactions work without it.",
        roomName,
        canPublish,
      });
    }

    const lkToken = createLiveKitToken({
      roomName,
      identity: user.id,
      name: user.displayName,
      canPublish,
    });

    return NextResponse.json({
      configured: true,
      token: lkToken,
      url: liveKitUrl,
      roomName,
      canPublish,
    });
  } catch (err) {
    console.error("[api/livekit-token] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
