import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";
import { getGateway, newReference } from "@/lib/payments";
import { emitTip, emitTipGoal } from "@/lib/realtime";
import type { PaymentProvider } from "@prisma/client";

// POST /api/tips — send a tip / virtual gift to a creator during a stream
export async function POST(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload)
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const {
      recipientId,
      streamId,
      amountMinor,
      giftType,
      message,
      provider = "MOMO_MTN",
      phone,
    } = await req.json();

    if (!recipientId || !amountMinor || amountMinor < 100) {
      return NextResponse.json(
        { error: "Minimum tip is GHS 1.00" },
        { status: 400 }
      );
    }

    const sender = await prisma.user.findUnique({ where: { id: payload.userId } });
    if (!sender)
      return NextResponse.json({ error: "User not found" }, { status: 404 });

    const reference = newReference("tip");
    const gateway = getGateway();

    // 1. Record a pending payment
    await prisma.payment.create({
      data: {
        amountMinor,
        provider: provider as PaymentProvider,
        status: "PENDING",
        reference,
        userId: sender.id,
        purpose: "tip",
      },
    });

    // 2. Charge via the configured gateway
    const charge = await gateway.charge({
      amountMinor,
      currency: "GHS",
      provider,
      reference,
      customer: { email: sender.email, phone, name: sender.displayName },
    });

    if (charge.status === "FAILED") {
      await prisma.payment.update({
        where: { reference },
        data: { status: "FAILED" },
      });
      return NextResponse.json({ error: "Payment failed" }, { status: 402 });
    }

    // For redirect/pending flows, return the action to the client
    if (charge.status === "PENDING" && charge.authorizationUrl) {
      return NextResponse.json({
        status: "PENDING",
        authorizationUrl: charge.authorizationUrl,
        reference,
      });
    }

    // 3. Settle: create tip, credit creator wallet, broadcast
    const tip = await prisma.$transaction(async (tx) => {
      await tx.payment.update({
        where: { reference },
        data: { status: "COMPLETED" },
      });
      const created = await tx.tip.create({
        data: {
          amountMinor,
          senderId: sender.id,
          recipientId,
          streamId: streamId || null,
          giftType: giftType || null,
          message: message || null,
          status: "COMPLETED",
        },
      });
      // creator keeps 85%, platform fee 15%
      const creatorShare = Math.floor(amountMinor * 0.85);
      await tx.user.update({
        where: { id: recipientId },
        data: { walletBalance: { increment: creatorShare } },
      });
      return created;
    });

    const dto = {
      id: tip.id,
      amountMinor: tip.amountMinor,
      currency: tip.currency,
      giftType: tip.giftType,
      message: tip.message,
      senderName: sender.displayName,
      streamId: tip.streamId,
      createdAt: tip.createdAt.toISOString(),
    };

    emitTip(streamId, dto);

    // Advance any active tip goal on this stream
    if (streamId) {
      try {
        const goal = await prisma.tipGoal.findFirst({
          where: { streamId, active: true },
          orderBy: { createdAt: "desc" },
        });
        if (goal) {
          const next = goal.currentMinor + amountMinor;
          const updated = await prisma.tipGoal.update({
            where: { id: goal.id },
            data: { currentMinor: next, reached: next >= goal.targetMinor },
          });
          emitTipGoal(streamId, {
            id: updated.id,
            streamId,
            title: updated.title,
            targetMinor: updated.targetMinor,
            currentMinor: updated.currentMinor,
            currency: updated.currency,
            reached: updated.reached,
            active: updated.active,
          });
        }
      } catch (e) {
        console.error("[api/tips] tipGoal update error:", e);
      }
    }

    return NextResponse.json({ status: "COMPLETED", tip: dto });
  } catch (err) {
    console.error("[api/tips POST] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
