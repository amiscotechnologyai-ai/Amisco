import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";
import { newReference } from "@/lib/payments";
import type { PaymentProvider } from "@prisma/client";

// GET /api/vod — list VODs a user has access to or can purchase
export async function GET(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    const showId = req.nextUrl.searchParams.get("showId");
    const creatorId = req.nextUrl.searchParams.get("creatorId");

    let where: any = { status: "READY" };
    if (showId) where.stream = { showId };
    if (creatorId) where.stream = { host: { id: creatorId } };

    const vods = await prisma.vod.findMany({
      where,
      include: {
        stream: { select: { id: true, title: true, startedAt: true, host: { select: { displayName: true } } } },
      },
      orderBy: { createdAt: "desc" },
      take: 50,
    });

    // Check which ones user owns/can access
    let purchased: string[] = [];
    if (payload) {
      const payments = await prisma.payment.findMany({
        where: { userId: payload.userId, purpose: "vod" },
        select: { reference: true },
      });
      purchased = payments.map((p) => p.reference);
    }

    return NextResponse.json({
      vods: vods.map((v) => ({
        ...v,
        isPurchased: purchased.includes(v.id),
      })),
    });
  } catch (err) {
    console.error("[api/vod GET] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

// POST /api/vod/purchase — buy access to a VOD
export async function POST(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { vodId, provider = "WALLET" } = await req.json();
    if (!vodId) return NextResponse.json({ error: "vodId required" }, { status: 400 });

    const vod = await prisma.vod.findUnique({
      where: { id: vodId },
      include: { stream: { select: { hostId: true } } },
    });
    if (!vod) return NextResponse.json({ error: "VOD not found" }, { status: 404 });
    if (!vod.isPremium || vod.priceMinor <= 0)
      return NextResponse.json({ error: "This VOD is free" }, { status: 400 });

    const buyer = await prisma.user.findUnique({ where: { id: payload.userId } });
    if (!buyer) return NextResponse.json({ error: "User not found" }, { status: 404 });

    if (provider === "WALLET") {
      if (buyer.walletBalance < vod.priceMinor)
        return NextResponse.json({ error: "Insufficient balance" }, { status: 402 });

      // Deduct from wallet, credit host
      await prisma.$transaction(async (tx) => {
        await tx.user.update({ where: { id: buyer.id }, data: { walletBalance: { decrement: vod.priceMinor } } });
        await tx.user.update({
          where: { id: vod.stream.hostId },
          data: { walletBalance: { increment: Math.floor(vod.priceMinor * 0.85) } },
        });
        await tx.payment.create({
          data: {
            amountMinor: vod.priceMinor,
            provider: "WALLET",
            status: "COMPLETED",
            reference: newReference("vod"),
            userId: buyer.id,
            purpose: "vod",
          },
        });
        await tx.vod.update({ where: { id: vodId }, data: { purchaseCount: { increment: 1 } } });
      });

      return NextResponse.json({ status: "OK", message: "Purchased" });
    }

    return NextResponse.json({ error: "Provider not supported" }, { status: 400 });
  } catch (err) {
    console.error("[api/vod POST] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
