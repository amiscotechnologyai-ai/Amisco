import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";

// GET /api/sponsorships?category=... — list active campaigns a creator can take
export async function GET(req: NextRequest) {
  try {
    const category = req.nextUrl.searchParams.get("category");
    const sponsorships = await prisma.sponsorship.findMany({
      where: { active: true, ...(category ? { category } : {}) },
      orderBy: { budgetMinor: "desc" },
      take: 50,
    });
    return NextResponse.json({ sponsorships });
  } catch (err) {
    console.error("[api/sponsorships GET] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

// POST /api/sponsorships — advertiser submits a campaign
export async function POST(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { advertiser, contactEmail, campaign, audioUrl, category, budgetMinor, cpmMinor } =
      await req.json();
    if (!advertiser || !contactEmail || !campaign || !category || !budgetMinor)
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 });

    const s = await prisma.sponsorship.create({
      data: {
        advertiser: String(advertiser).slice(0, 120),
        contactEmail,
        campaign: String(campaign).slice(0, 200),
        audioUrl: audioUrl || null,
        category,
        budgetMinor,
        cpmMinor: cpmMinor || 0,
      },
    });
    return NextResponse.json({ status: "OK", id: s.id });
  } catch (err) {
    console.error("[api/sponsorships POST] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
