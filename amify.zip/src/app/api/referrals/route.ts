import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";

const REFERRAL_REWARD_MINOR = 500; // GHS 5.00 credited to referrer per signup

function genCode(username: string): string {
  const base = username.replace(/[^a-zA-Z0-9]/g, "").slice(0, 8).toUpperCase() || "AMIFY";
  const rand = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `${base}-${rand}`;
}

// GET /api/referrals — return this user's invite code + stats (creates code if missing)
export async function GET(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    let user = await prisma.user.findUnique({ where: { id: payload.userId } });
    if (!user) return NextResponse.json({ error: "Not found" }, { status: 404 });

    if (!user.referralCode) {
      user = await prisma.user.update({
        where: { id: user.id },
        data: { referralCode: genCode(user.username) },
      });
    }

    const referrals = await prisma.referral.findMany({ where: { referrerId: user.id } });
    const rewardedMinor = referrals.filter((r) => r.rewarded).reduce((s, r) => s + r.rewardMinor, 0);

    return NextResponse.json({
      code: user.referralCode,
      invited: referrals.length,
      rewardedMinor,
      currency: "GHS",
    });
  } catch (err) {
    console.error("[api/referrals GET] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

// POST /api/referrals/redeem — called at signup with a code (body: { code })
// Credits the referrer once the new user is created.
export async function POST(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { code } = await req.json();
    if (!code) return NextResponse.json({ error: "Code required" }, { status: 400 });

    const referrer = await prisma.user.findUnique({ where: { referralCode: code } });
    if (!referrer) return NextResponse.json({ error: "Invalid code" }, { status: 404 });
    if (referrer.id === payload.userId)
      return NextResponse.json({ error: "Cannot refer yourself" }, { status: 400 });

    const existing = await prisma.referral.findUnique({ where: { referredId: payload.userId } });
    if (existing) return NextResponse.json({ error: "Already referred" }, { status: 409 });

    await prisma.$transaction(async (tx) => {
      await tx.referral.create({
        data: {
          code,
          referrerId: referrer.id,
          referredId: payload.userId,
          rewardMinor: REFERRAL_REWARD_MINOR,
          rewarded: true,
        },
      });
      await tx.user.update({
        where: { id: referrer.id },
        data: { walletBalance: { increment: REFERRAL_REWARD_MINOR } },
      });
    });

    return NextResponse.json({ status: "OK", rewardedMinor: REFERRAL_REWARD_MINOR });
  } catch (err) {
    console.error("[api/referrals POST] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
