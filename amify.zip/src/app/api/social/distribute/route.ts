import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";
import { distributeClip, type SocialPlatform } from "@/lib/social";

// POST /api/social/distribute — push an existing clip to social platforms
// body: { clipId, platforms: ["tiktok","instagram","x"], caption? }
export async function POST(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { clipId, platforms, caption } = await req.json();
    if (!clipId || !Array.isArray(platforms) || platforms.length === 0)
      return NextResponse.json({ error: "clipId and platforms required" }, { status: 400 });

    const clip = await prisma.clip.findUnique({
      where: { id: clipId },
      include: { episode: { include: { creator: true, show: true } } },
    });
    if (!clip) return NextResponse.json({ error: "Clip not found" }, { status: 404 });
    if (clip.episode.creatorId !== payload.userId)
      return NextResponse.json({ error: "Not your clip" }, { status: 403 });

    const text =
      caption || `${clip.title} — from "${clip.episode.show?.title}" on AmiFy 🎙️ #podcast`;

    const results = await distributeClip(
      clip.videoUrl || clip.audioUrl || clip.episode.audioUrl,
      text,
      platforms as SocialPlatform[]
    );

    return NextResponse.json({ status: "OK", results });
  } catch (err) {
    console.error("[api/social/distribute POST] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
