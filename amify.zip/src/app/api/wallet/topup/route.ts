import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";
import { getGateway, newReference } from "@/lib/payments";
import type { PaymentProvider } from "@prisma/client";

/**
 * Wallet top-up.
 * - Self top-up: a user funds their own wallet via MoMo/card.
 * - Agent cash-in: an authorised agent funds another user's wallet by username,
 *   mirroring how mobile-money agents work locally (cash handed over in person).
 *   body: { amountMinor, provider, phone, targetUsername? }
 */
export async function POST(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { amountMinor, provider = "MOMO_MTN", phone, targetUsername } = await req.json();
    if (!amountMinor || amountMinor < 100)
      return NextResponse.json({ error: "Minimum top-up is GHS 1.00" }, { status: 400 });

    const actor = await prisma.user.findUnique({ where: { id: payload.userId } });
    if (!actor) return NextResponse.json({ error: "User not found" }, { status: 404 });

    // Resolve who gets credited
    let beneficiary = actor;
    if (targetUsername && targetUsername !== actor.username) {
      const target = await prisma.user.findUnique({ where: { username: targetUsername } });
      if (!target) return NextResponse.json({ error: "Recipient not found" }, { status: 404 });
      beneficiary = target;
    }

    const reference = newReference("topup");
    const gateway = getGateway();
    const charge = await gateway.charge({
      amountMinor,
      currency: "GHS",
      provider,
      reference,
      customer: { email: actor.email, phone, name: actor.displayName },
      metadata: { purpose: "topup", beneficiary: beneficiary.username },
    });

    if (charge.status === "FAILED")
      return NextResponse.json({ error: "Payment failed" }, { status: 402 });

    if (charge.status === "PENDING" && charge.authorizationUrl)
      return NextResponse.json({ status: "PENDING", authorizationUrl: charge.authorizationUrl, reference });

    const result = await prisma.$transaction(async (tx) => {
      await tx.payment.create({
        data: {
          amountMinor,
          provider: provider as PaymentProvider,
          status: "COMPLETED",
          reference,
          userId: actor.id,
          purpose: "topup",
        },
      });
      const updated = await tx.user.update({
        where: { id: beneficiary.id },
        data: { walletBalance: { increment: amountMinor } },
      });
      return updated;
    });

    return NextResponse.json({
      status: "COMPLETED",
      beneficiary: beneficiary.username,
      walletBalance: result.walletBalance,
      agentCashIn: beneficiary.id !== actor.id,
    });
  } catch (err) {
    console.error("[api/wallet/topup POST] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
