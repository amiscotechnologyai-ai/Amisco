import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";

// GET /api/analytics/sessions?streamId=... — get listener session data for heatmap
// GET /api/analytics/creator?period=... — get creator earnings & performance
export async function GET(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const streamId = req.nextUrl.searchParams.get("streamId");
    const period = req.nextUrl.searchParams.get("period");

    // Route to sessions or creator endpoint based on params
    if (streamId) {
      // SESSIONS ENDPOINT
      const stream = await prisma.stream.findUnique({
        where: { id: streamId },
        select: { hostId: true, startedAt: true, endedAt: true },
      });
      if (!stream) return NextResponse.json({ error: "Stream not found" }, { status: 404 });
      if (stream.hostId !== payload.userId) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

      const sessions = await prisma.listenerSession.findMany({
        where: { streamId },
        include: { user: { select: { displayName: true } } },
        orderBy: { joinedAt: "asc" },
      });

      const streamStart = stream.startedAt?.getTime() || Date.now();
      const streamEnd = stream.endedAt?.getTime() || Date.now();
      const durationMin = Math.ceil((streamEnd - streamStart) / 60000);
      const buckets = Math.ceil(durationMin / 10);

      const heatmap: number[] = Array(buckets).fill(0);
      sessions.forEach((s) => {
        const joinMin = Math.floor((s.joinedAt.getTime() - streamStart) / 60000);
        const leaveMin = s.leftAt ? Math.floor((s.leftAt.getTime() - streamStart) / 60000) : durationMin;
        for (let i = Math.max(0, joinMin); i < Math.min(buckets, leaveMin); i++) {
          heatmap[i]++;
        }
      });

      const totalListeners = sessions.length;
      const avgDurationSec = sessions.length ? Math.round(sessions.reduce((sum, s) => sum + s.durationSec, 0) / sessions.length) : 0;
      const peakListeners = Math.max(...heatmap, 0);
      const totalGifts = sessions.reduce((sum, s) => sum + s.giftCount, 0);
      const totalMessages = sessions.reduce((sum, s) => sum + s.messageCount, 0);

      return NextResponse.json({
        heatmap,
        buckets,
        durationMin,
        stats: {
          totalListeners,
          avgDurationSec,
          peakListeners,
          totalGifts,
          totalMessages,
          avgEngagementScore: Math.round((totalGifts + totalMessages) / Math.max(1, totalListeners)),
        },
        sessions: sessions.map((s) => ({
          user: s.user.displayName,
          joinedAt: s.joinedAt,
          durationSec: s.durationSec,
          giftCount: s.giftCount,
          messageCount: s.messageCount,
        })),
      });
    } else {
      // CREATOR ANALYTICS ENDPOINT
      const daysBack = period === "7d" ? 7 : period === "90d" ? 90 : period === "all" ? 365 : 30;

      const user = await prisma.user.findUnique({
        where: { id: payload.userId },
        select: { walletBalance: true, totalEarningsMinor: true, verified: true, primaryCurrency: true },
      });
      if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });

      const tips = await prisma.tip.findMany({
        where: {
          recipientId: payload.userId,
          createdAt: { gte: new Date(Date.now() - daysBack * 86400000) },
        },
      });

      const memberships = await prisma.membership.findMany({
        where: {
          creatorId: payload.userId,
          createdAt: { gte: new Date(Date.now() - daysBack * 86400000) },
        },
      });

      const vods = await prisma.vod.findMany({
        where: {
          stream: { hostId: payload.userId },
          createdAt: { gte: new Date(Date.now() - daysBack * 86400000) },
        },
      });

      const totalTipsMinor = tips.reduce((sum, t) => sum + t.amountMinor, 0);
      const totalMembershipsMinor = memberships.reduce((sum, m) => sum + (m.priceMinor || 0), 0);
      const totalVodMinor = vods.reduce((sum, v) => sum + v.purchaseCount * v.priceMinor, 0);

      return NextResponse.json({
        earnings: {
          tips: totalTipsMinor,
          memberships: totalMembershipsMinor,
          vod: totalVodMinor,
          total: totalTipsMinor + totalMembershipsMinor + totalVodMinor,
        },
        wallet: user.walletBalance,
        lifetime: user.totalEarningsMinor,
        verified: user.verified,
        currency: user.primaryCurrency,
        sources: {
          tipCount: tips.length,
          memberCount: memberships.length,
          vodPurchases: vods.reduce((sum, v) => sum + v.purchaseCount, 0),
        },
      });
    }
  } catch (err) {
    console.error("[api/analytics GET] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
