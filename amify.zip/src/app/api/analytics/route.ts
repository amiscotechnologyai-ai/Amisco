import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";

// GET /api/analytics — creator dashboard: audience, earnings, top content
export async function GET(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload)
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const userId = payload.userId;

    const [
      user,
      shows,
      episodes,
      streams,
      tipsAgg,
      tipCount,
      followerCount,
      recentTips,
    ] = await Promise.all([
      prisma.user.findUnique({ where: { id: userId } }),
      prisma.show.count({ where: { ownerId: userId } }),
      prisma.episode.findMany({
        where: { creatorId: userId },
        select: { title: true, playCount: true },
        orderBy: { playCount: "desc" },
        take: 5,
      }),
      prisma.stream.findMany({
        where: { hostId: userId },
        select: { title: true, peakListeners: true, status: true },
        orderBy: { peakListeners: "desc" },
        take: 5,
      }),
      prisma.tip.aggregate({
        where: { recipientId: userId, status: "COMPLETED" },
        _sum: { amountMinor: true },
      }),
      prisma.tip.count({ where: { recipientId: userId } }),
      prisma.follow.count({ where: { followingId: userId } }),
      prisma.tip.findMany({
        where: { recipientId: userId },
        include: { sender: { select: { displayName: true } } },
        orderBy: { createdAt: "desc" },
        take: 8,
      }),
    ]);

    const totalPlays = await prisma.episode.aggregate({
      where: { creatorId: userId },
      _sum: { playCount: true },
    });

    return NextResponse.json({
      walletBalance: user?.walletBalance ?? 0,
      totalEarnedMinor: tipsAgg._sum.amountMinor ?? 0,
      tipCount,
      followerCount,
      showCount: shows,
      totalPlays: totalPlays._sum.playCount ?? 0,
      topEpisodes: episodes,
      topStreams: streams,
      recentTips: recentTips.map((t) => ({
        amountMinor: t.amountMinor,
        senderName: t.sender.displayName,
        giftType: t.giftType,
        createdAt: t.createdAt.toISOString(),
      })),
    });
  } catch (err) {
    console.error("[api/analytics] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
