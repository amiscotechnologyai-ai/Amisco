import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";

// GET /api/downloads — list the user's offline downloads
export async function GET(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const downloads = await prisma.offlineDownload.findMany({
      where: { userId: payload.userId },
      include: { episode: { include: { show: true } } },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ downloads });
  } catch (err) {
    console.error("[api/downloads GET] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

// POST /api/downloads — mark an episode downloaded (quality respects data-saver)
// body: { episodeId, quality? }
export async function POST(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { episodeId, quality } = await req.json();
    if (!episodeId) return NextResponse.json({ error: "episodeId required" }, { status: 400 });

    const user = await prisma.user.findUnique({ where: { id: payload.userId } });
    const q = quality || (user?.dataSaver ? "LOW" : user?.audioQuality || "STANDARD");

    const dl = await prisma.offlineDownload.upsert({
      where: { userId_episodeId: { userId: payload.userId, episodeId } },
      update: { quality: q },
      create: { userId: payload.userId, episodeId, quality: q },
    });
    return NextResponse.json({ status: "OK", download: dl });
  } catch (err) {
    console.error("[api/downloads POST] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

// DELETE /api/downloads?episodeId=... — remove a download
export async function DELETE(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const episodeId = req.nextUrl.searchParams.get("episodeId");
    if (!episodeId) return NextResponse.json({ error: "episodeId required" }, { status: 400 });

    await prisma.offlineDownload.deleteMany({ where: { userId: payload.userId, episodeId } });
    return NextResponse.json({ status: "OK" });
  } catch (err) {
    console.error("[api/downloads DELETE] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
