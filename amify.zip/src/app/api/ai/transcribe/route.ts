import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";
import { transcribeAudio, generateShowNotes } from "@/lib/ai";

// POST /api/ai/transcribe { episodeId }
// Transcribes the episode, then generates show notes, chapters and clip ideas.
export async function POST(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload)
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { episodeId } = await req.json();
    const episode = await prisma.episode.findUnique({
      where: { id: episodeId },
    });
    if (!episode)
      return NextResponse.json({ error: "Episode not found" }, { status: 404 });
    if (episode.creatorId !== payload.userId)
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });

    // Mark processing
    const transcript = await prisma.transcript.upsert({
      where: { episodeId },
      update: { status: "PROCESSING" },
      create: { episodeId, status: "PROCESSING" },
    });

    // Run transcription
    const result = await transcribeAudio(episode.audioUrl);
    const notes = await generateShowNotes(result.fullText, episode.title);

    // Persist transcript + show notes
    await prisma.transcript.update({
      where: { id: transcript.id },
      data: {
        status: "READY",
        language: result.language,
        fullText: result.fullText,
        showNotes: JSON.stringify(notes),
        segments: result.segments as any,
      },
    });

    // Persist chapters
    if (notes.chapters?.length) {
      await prisma.chapter.deleteMany({ where: { episodeId } });
      await prisma.chapter.createMany({
        data: notes.chapters.map((c) => ({
          episodeId,
          title: c.title,
          startSec: c.startSec,
        })),
      });
    }

    // Persist clip suggestions
    if (notes.clipSuggestions?.length) {
      await prisma.clip.createMany({
        data: notes.clipSuggestions.map((c) => ({
          episodeId,
          title: c.title,
          startSec: c.startSec,
          endSec: c.endSec,
        })),
      });
    }

    return NextResponse.json({
      status: "READY",
      transcript: result.fullText,
      showNotes: notes,
    });
  } catch (err) {
    console.error("[api/ai/transcribe] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
