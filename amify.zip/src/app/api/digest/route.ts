import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";

/**
 * GET /api/digest — a personalised "Your Weekly Mix":
 *  - new episodes from shows/creators the user follows or has played
 *  - plus trending episodes in their most-played categories
 * Falls back to platform trending for new users.
 */
export async function GET(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const userId = payload.userId;
    const since = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

    // Creators the user follows
    const follows = await prisma.follow.findMany({ where: { followerId: userId } });
    const followedIds = follows.map((f) => f.followingId);

    // Categories from recent play history
    const history = await prisma.playHistory.findMany({
      where: { userId },
      include: { episode: { include: { show: true } } },
      orderBy: { playedAt: "desc" },
      take: 30,
    });
    const categoryCount = new Map<string, number>();
    for (const h of history) {
      const cat = h.episode?.show?.category;
      if (cat) categoryCount.set(cat, (categoryCount.get(cat) || 0) + 1);
    }
    const topCategories = [...categoryCount.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([c]) => c);

    // New episodes from followed creators
    const fromFollowed = followedIds.length
      ? await prisma.episode.findMany({
          where: { creatorId: { in: followedIds }, publishedAt: { gte: since } },
          include: { show: true, creator: true },
          orderBy: { publishedAt: "desc" },
          take: 10,
        })
      : [];

    // Trending in the user's top categories (by play count)
    const trending = await prisma.episode.findMany({
      where: topCategories.length ? { show: { category: { in: topCategories } } } : {},
      include: { show: true, creator: true },
      orderBy: { playCount: "desc" },
      take: 10,
    });

    const seen = new Set<string>();
    const pick = (e: { id: string; title: string; durationSec: number; show: { title: string; emoji: string; coverColor: string; category: string } | null; creator: { displayName: string } }) => {
      if (seen.has(e.id)) return null;
      seen.add(e.id);
      return {
        id: e.id,
        title: e.title,
        durationSec: e.durationSec,
        showTitle: e.show?.title ?? "",
        emoji: e.show?.emoji ?? "🎙️",
        coverColor: e.show?.coverColor ?? "#4c1d95",
        category: e.show?.category ?? "",
        creatorName: e.creator.displayName,
      };
    };

    const items = [...fromFollowed, ...trending].map(pick).filter(Boolean).slice(0, 12);

    return NextResponse.json({
      generatedAt: new Date().toISOString(),
      topCategories,
      newFromFollowed: fromFollowed.length,
      items,
    });
  } catch (err) {
    console.error("[api/digest GET] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
