import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";

// GET /api/library — returns the authenticated user's library
export async function GET(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const [subscriptions, saved, history] = await Promise.all([
      prisma.subscription.findMany({
        where: { userId: payload.userId },
        include: {
          show: {
            include: {
              owner: { select: { displayName: true } },
              _count: { select: { episodes: true, subscriptions: true } },
            },
          },
        },
      }),
      prisma.savedEpisode.findMany({
        where: { userId: payload.userId },
        include: {
          episode: {
            include: {
              show: { select: { title: true } },
              creator: { select: { displayName: true } },
            },
          },
        },
        orderBy: { createdAt: "desc" },
      }),
      prisma.playHistory.findMany({
        where: { userId: payload.userId },
        include: {
          episode: {
            include: {
              show: { select: { title: true } },
              creator: { select: { displayName: true } },
            },
          },
        },
        orderBy: { playedAt: "desc" },
        take: 50,
      }),
    ]);

    return NextResponse.json({
      subscribed: subscriptions.map((s) => ({
        id: s.show.id,
        title: s.show.title,
        host: s.show.owner.displayName,
        episodes: s.show._count.episodes,
        followers: s.show._count.subscriptions,
        emoji: s.show.emoji,
      })),
      saved: saved.map((s) => ({
        id: s.episode.id,
        title: s.episode.title,
        host: s.episode.creator.displayName,
        duration: formatDuration(s.episode.durationSec),
        date: s.createdAt.toISOString(),
      })),
      history: history.map((h) => ({
        id: h.episode.id,
        title: h.episode.title,
        host: h.episode.creator.displayName,
        progress:
          h.episode.durationSec > 0
            ? Math.round((h.progressSec / h.episode.durationSec) * 100)
            : 0,
      })),
    });
  } catch (err) {
    console.error("[api/library GET] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

function formatDuration(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}
