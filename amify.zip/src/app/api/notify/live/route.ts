import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";
import { sendBulkSms, isSmsConfigured } from "@/lib/sms";

/**
 * POST /api/notify/live — host alerts followers that they're live.
 * Sends SMS to followers who opted in and have a phone number, and creates
 * in-app notifications for everyone. body: { streamId }
 */
export async function POST(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { streamId } = await req.json();
    if (!streamId) return NextResponse.json({ error: "streamId required" }, { status: 400 });

    const stream = await prisma.stream.findUnique({ where: { id: streamId } });
    if (!stream) return NextResponse.json({ error: "Stream not found" }, { status: 404 });
    if (stream.hostId !== payload.userId)
      return NextResponse.json({ error: "Only the host can notify" }, { status: 403 });

    const host = await prisma.user.findUnique({ where: { id: stream.hostId } });
    const followers = await prisma.follow.findMany({
      where: { followingId: stream.hostId },
      include: { follower: true },
    });

    // In-app notifications for all followers with notifications on
    const inAppTargets = followers.filter((f) => f.follower.notificationsOn);
    if (inAppTargets.length) {
      await prisma.notification.createMany({
        data: inAppTargets.map((f) => ({
          userId: f.followerId,
          type: "live",
          message: `${host?.displayName} is live: ${stream.title}`,
        })),
      });
    }

    // SMS for followers who opted in and have a phone
    const smsTargets = followers
      .filter((f) => f.follower.smsOptIn && f.follower.phone)
      .map((f) => f.follower.phone as string);

    let smsSent = 0;
    if (smsTargets.length) {
      const results = await sendBulkSms(
        smsTargets,
        `${host?.displayName} is LIVE on AmiFy: "${stream.title}". Tune in now.`
      );
      smsSent = results.filter((r) => r.status === "SENT" || r.status === "QUEUED").length;
    }

    return NextResponse.json({
      status: "OK",
      inAppNotified: inAppTargets.length,
      smsTargets: smsTargets.length,
      smsSent,
      smsLive: isSmsConfigured(),
    });
  } catch (err) {
    console.error("[api/notify/live POST] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
