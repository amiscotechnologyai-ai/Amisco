import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// GET /api/shows?category=Technology&trending=true
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const category = searchParams.get("category");
    const trending = searchParams.get("trending") === "true";

    const shows = await prisma.show.findMany({
      where: category && category !== "All" ? { category } : {},
      include: {
        owner: { select: { displayName: true } },
        _count: { select: { episodes: true, subscriptions: true } },
      },
      orderBy: trending
        ? { subscriptions: { _count: "desc" } }
        : { createdAt: "desc" },
      take: trending ? 8 : 50,
    });

    return NextResponse.json(
      shows.map((s) => ({
        id: s.id,
        title: s.title,
        description: s.description,
        category: s.category,
        coverColor: s.coverColor,
        emoji: s.emoji,
        ownerName: s.owner.displayName,
        episodeCount: s._count.episodes,
        subscriberCount: s._count.subscriptions,
      }))
    );
  } catch (err) {
    console.error("[api/shows GET] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
