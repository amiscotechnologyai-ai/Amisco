import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";
import { getGateway, newReference } from "@/lib/payments";
import type { PaymentProvider } from "@prisma/client";

// GET /api/tickets?streamId=... — does the current user hold a valid ticket?
export async function GET(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const streamId = req.nextUrl.searchParams.get("streamId");
    if (!streamId) return NextResponse.json({ error: "streamId required" }, { status: 400 });

    const ticket = await prisma.ticket.findUnique({
      where: { streamId_userId: { streamId, userId: payload.userId } },
    });
    return NextResponse.json({ hasTicket: !!ticket && ticket.status === "VALID", ticket });
  } catch (err) {
    console.error("[api/tickets GET] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

// POST /api/tickets — buy a ticket for a ticketed live event
export async function POST(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { streamId, provider = "MOMO_MTN", phone } = await req.json();
    if (!streamId) return NextResponse.json({ error: "streamId required" }, { status: 400 });

    const stream = await prisma.stream.findUnique({ where: { id: streamId } });
    if (!stream) return NextResponse.json({ error: "Stream not found" }, { status: 404 });
    if (!stream.isTicketed || stream.ticketPriceMinor <= 0)
      return NextResponse.json({ error: "This event is free" }, { status: 400 });

    const buyer = await prisma.user.findUnique({ where: { id: payload.userId } });
    if (!buyer) return NextResponse.json({ error: "User not found" }, { status: 404 });

    const existing = await prisma.ticket.findUnique({
      where: { streamId_userId: { streamId, userId: buyer.id } },
    });
    if (existing && existing.status === "VALID")
      return NextResponse.json({ status: "ALREADY_HELD", ticket: existing });

    const reference = newReference("ticket");
    const gateway = getGateway();
    const charge = await gateway.charge({
      amountMinor: stream.ticketPriceMinor,
      currency: "GHS",
      provider,
      reference,
      customer: { email: buyer.email, phone, name: buyer.displayName },
      metadata: { streamId, purpose: "ticket" },
    });

    if (charge.status === "FAILED")
      return NextResponse.json({ error: "Payment failed" }, { status: 402 });

    if (charge.status === "PENDING" && charge.authorizationUrl)
      return NextResponse.json({ status: "PENDING", authorizationUrl: charge.authorizationUrl, reference });

    // Settle: record payment + issue ticket, credit host 85%
    const ticket = await prisma.$transaction(async (tx) => {
      await tx.payment.create({
        data: {
          amountMinor: stream.ticketPriceMinor,
          provider: provider as PaymentProvider,
          status: "COMPLETED",
          reference,
          userId: buyer.id,
          purpose: "ticket",
        },
      });
      const t = await tx.ticket.upsert({
        where: { streamId_userId: { streamId, userId: buyer.id } },
        update: { status: "VALID", reference, priceMinor: stream.ticketPriceMinor },
        create: {
          streamId,
          userId: buyer.id,
          priceMinor: stream.ticketPriceMinor,
          reference,
          status: "VALID",
        },
      });
      await tx.user.update({
        where: { id: stream.hostId },
        data: { walletBalance: { increment: Math.floor(stream.ticketPriceMinor * 0.85) } },
      });
      return t;
    });

    return NextResponse.json({ status: "COMPLETED", ticket });
  } catch (err) {
    console.error("[api/tickets POST] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
