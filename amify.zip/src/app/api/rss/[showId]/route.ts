import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// GET /api/rss/[showId] — standards-compliant podcast RSS feed
// so a show syndicates to Apple Podcasts, Spotify, etc.
export async function GET(
  req: NextRequest,
  { params }: { params: { showId: string } }
) {
  try {
    const show = await prisma.show.findUnique({
      where: { id: params.showId },
      include: {
        owner: { select: { displayName: true, email: true } },
        episodes: { orderBy: { publishedAt: "desc" }, take: 300 },
      },
    });

    if (!show) {
      return new NextResponse("Show not found", { status: 404 });
    }

    const base =
      process.env.NEXT_PUBLIC_BASE_URL || `https://${req.headers.get("host")}`;

    const esc = (s: string) =>
      s
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");

    const items = show.episodes
      .map(
        (ep) => `
    <item>
      <title>${esc(ep.title)}</title>
      <description>${esc(ep.description || "")}</description>
      <pubDate>${ep.publishedAt.toUTCString()}</pubDate>
      <guid isPermaLink="false">${ep.id}</guid>
      <enclosure url="${esc(ep.audioUrl)}" type="audio/mpeg" />
      <itunes:duration>${ep.durationSec}</itunes:duration>
    </item>`
      )
      .join("");

    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:itunes="http://www.itunes.com/dtds/podcast-1.0.dtd">
  <channel>
    <title>${esc(show.title)}</title>
    <link>${base}</link>
    <language>en</language>
    <description>${esc(show.description || show.title)}</description>
    <itunes:author>${esc(show.owner.displayName)}</itunes:author>
    <itunes:category text="${esc(show.category)}" />
    <itunes:owner>
      <itunes:name>${esc(show.owner.displayName)}</itunes:name>
      <itunes:email>${esc(show.owner.email)}</itunes:email>
    </itunes:owner>
    <generator>AmiFy by Amisco Technology</generator>${items}
  </channel>
</rss>`;

    return new NextResponse(xml, {
      headers: {
        "Content-Type": "application/rss+xml; charset=utf-8",
        "Cache-Control": "public, max-age=600",
      },
    });
  } catch (err) {
    console.error("[api/rss] error:", err);
    return new NextResponse("Server error", { status: 500 });
  }
}
