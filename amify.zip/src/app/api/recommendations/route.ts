import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";

// GET /api/recommendations — get personalized creator recommendations
export async function GET(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const limit = parseInt(req.nextUrl.searchParams.get("limit") || "10");

    // Get user's following list
    const user = await prisma.user.findUnique({
      where: { id: payload.userId },
      include: { following: { select: { followeeId: true } } },
    });
    if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });

    const followingIds = user.following.map((f) => f.followeeId);

    // Get user's play history categories
    const history = await prisma.playHistory.findMany({
      where: { userId: payload.userId },
      include: { episode: { select: { show: { select: { category: true, ownerId: true } } } } },
      take: 20,
      orderBy: { playedAt: "desc" },
    });

    const preferredCategories = new Map<string, number>();
    const preferredCreators = new Set<string>();
    history.forEach((h) => {
      const cat = h.episode.show.category;
      const owner = h.episode.show.ownerId;
      preferredCategories.set(cat, (preferredCategories.get(cat) || 0) + 1);
      preferredCreators.add(owner);
    });

    // Find creators in preferred categories that user doesn't follow
    const creators = await prisma.user.findMany({
      where: {
        isCreator: true,
        id: { notIn: [payload.userId, ...followingIds] },
      },
      include: {
        shows: { select: { category: true, id: true } },
      },
      take: limit * 3, // Get more, then score
    });

    // Score creators
    const scored = creators.map((c) => {
      let score = 0;
      c.shows.forEach((s) => {
        score += preferredCategories.get(s.category) || 0;
      });
      return { creator: c, score };
    });

    const recommendations = scored
      .filter((s) => s.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, limit)
      .map((s) => ({
        id: s.creator.id,
        displayName: s.creator.displayName,
        avatarColor: s.creator.avatarColor,
        verified: s.creator.verified,
        categories: [...new Set(s.creator.shows.map((sh) => sh.category))],
        reason: "Trending in your interests",
      }));

    // Save recommendations for tracking
    for (const rec of recommendations) {
      await prisma.creatorRecommendation.upsert({
        where: { userId_recommendedCreatorId: { userId: payload.userId, recommendedCreatorId: rec.id } },
        update: { score: scored.find((s) => s.creator.id === rec.id)?.score || 0 },
        create: {
          userId: payload.userId,
          recommendedCreatorId: rec.id,
          score: scored.find((s) => s.creator.id === rec.id)?.score || 0,
          reason: rec.reason,
        },
      });
    }

    return NextResponse.json({ recommendations });
  } catch (err) {
    console.error("[api/recommendations GET] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

// POST /api/recommendations/click — track recommendation click
export async function POST(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { creatorId } = await req.json();
    if (!creatorId) return NextResponse.json({ error: "creatorId required" }, { status: 400 });

    await prisma.creatorRecommendation.updateMany({
      where: { userId: payload.userId, recommendedCreatorId: creatorId },
      data: { clicked: true, views: { increment: 1 } },
    });

    return NextResponse.json({ status: "OK" });
  } catch (err) {
    console.error("[api/recommendations POST] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
