import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";

// GET /api/streaks — get user's listen streak OR list supported currencies
export async function GET(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;

    // Check if requesting currencies or streaks
    if (req.nextUrl.pathname.includes("currencies") || req.nextUrl.searchParams.has("currencies")) {
      // CURRENCIES ENDPOINT (no auth)
      const rates = {
        GHS: { code: "GHS", name: "Ghana Cedi", rate: 1 },
        ZAR: { code: "ZAR", name: "South Africa Rand", rate: 0.054 },
        KES: { code: "KES", name: "Kenya Shilling", rate: 0.0073 },
        NGN: { code: "NGN", name: "Nigeria Naira", rate: 0.0019 },
        UGX: { code: "UGX", name: "Uganda Shilling", rate: 0.00025 },
        USD: { code: "USD", name: "US Dollar", rate: 12.5 },
      };
      return NextResponse.json({ currencies: rates });
    }

    // STREAKS ENDPOINT (auth required)
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const user = await prisma.user.findUnique({
      where: { id: payload.userId },
      select: { listenStreak: true, streakStartedAt: true },
    });
    if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });

    const lastListen = await prisma.playHistory.findFirst({
      where: { userId: payload.userId },
      orderBy: { playedAt: "desc" },
      select: { playedAt: true },
    });

    const now = Date.now();
    const isStreakActive = lastListen && now - lastListen.playedAt.getTime() < 86400000;

    return NextResponse.json({
      userId: payload.userId,
      streak: user.listenStreak,
      startedAt: user.streakStartedAt,
      isActive: isStreakActive,
      lastListenedAt: lastListen?.playedAt,
      reward: user.listenStreak >= 7 ? "Streak milestone! Unlock 50 GHS bonus" : null,
    });
  } catch (err) {
    console.error("[api/streaks GET] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

// POST /api/streaks — update user's listen streak OR set currency
export async function POST(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = await req.json();
    const { currency } = body;

    // Check if setting currency
    if (currency) {
      // SET CURRENCY ENDPOINT
      const validCurrencies = ["GHS", "ZAR", "KES", "NGN", "UGX", "USD"];
      if (!validCurrencies.includes(currency))
        return NextResponse.json({ error: "Invalid currency" }, { status: 400 });

      const user = await prisma.user.update({
        where: { id: payload.userId },
        data: { primaryCurrency: currency as any },
        select: { id: true, primaryCurrency: true, walletBalance: true },
      });

      return NextResponse.json({ status: "OK", user });
    }

    // UPDATE STREAK ENDPOINT
    const user = await prisma.user.findUnique({
      where: { id: payload.userId },
      select: { listenStreak: true, streakStartedAt: true },
    });
    if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });

    const lastListen = await prisma.playHistory.findFirst({
      where: { userId: payload.userId },
      orderBy: { playedAt: "desc" },
      select: { playedAt: true },
    });

    const now = new Date();
    let newStreak = user.listenStreak || 0;
    let streakStartedAt = user.streakStartedAt;

    if (!lastListen || now.getTime() - lastListen.playedAt.getTime() > 86400000) {
      newStreak = 1;
      streakStartedAt = now;
    } else {
      const lastDay = new Date(lastListen.playedAt);
      if (now.toDateString() !== lastDay.toDateString()) {
        newStreak++;
      }
    }

    if (newStreak === 7) {
      await prisma.user.update({
        where: { id: payload.userId },
        data: { walletBalance: { increment: 5000 } },
      });
    }

    await prisma.user.update({
      where: { id: payload.userId },
      data: { listenStreak: newStreak, streakStartedAt },
    });

    return NextResponse.json({
      status: "OK",
      streak: newStreak,
      bonus: newStreak === 7 ? "50 GHS awarded!" : null,
    });
  } catch (err) {
    console.error("[api/streaks POST] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
