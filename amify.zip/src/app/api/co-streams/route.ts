import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";

// POST /api/co-streams — initiate a co-stream with another creator
export async function POST(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { otherCreatorId } = await req.json();
    if (!otherCreatorId) return NextResponse.json({ error: "otherCreatorId required" }, { status: 400 });

    const user = await prisma.user.findUnique({ where: { id: payload.userId } });
    const other = await prisma.user.findUnique({ where: { id: otherCreatorId } });
    if (!user || !other) return NextResponse.json({ error: "Creator not found" }, { status: 404 });

    // Create co-stream record
    const coStream = await prisma.coStream.create({
      data: {
        creator1Id: payload.userId,
        creator2Id: otherCreatorId,
        status: "SCHEDULED",
      },
    });

    // Clear existing co-streams for both creators (only one active at a time)
    await prisma.coStream.deleteMany({
      where: {
        OR: [{ creator1Id: payload.userId }, { creator2Id: payload.userId }],
        status: "SCHEDULED",
        createdAt: { lt: new Date(Date.now() - 60000) }, // older than 1 min
      },
    });

    return NextResponse.json({ status: "OK", coStream });
  } catch (err) {
    console.error("[api/co-streams POST] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

// GET /api/co-streams?creatorId=... — get active or pending co-streams
export async function GET(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const creatorId = req.nextUrl.searchParams.get("creatorId") || payload.userId;
    const coStreams = await prisma.coStream.findMany({
      where: {
        OR: [{ creator1Id: creatorId }, { creator2Id: creatorId }],
        status: { in: ["SCHEDULED", "LIVE"] },
      },
      include: {
        creator1: { select: { id: true, displayName: true, avatarColor: true } },
        creator2: { select: { id: true, displayName: true, avatarColor: true } },
      },
      orderBy: { createdAt: "desc" },
      take: 10,
    });

    return NextResponse.json({ coStreams });
  } catch (err) {
    console.error("[api/co-streams GET] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

// DELETE /api/co-streams?id=... — cancel a co-stream
export async function DELETE(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const id = req.nextUrl.searchParams.get("id");
    if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });

    const coStream = await prisma.coStream.findUnique({ where: { id } });
    if (!coStream) return NextResponse.json({ error: "Not found" }, { status: 404 });
    if (coStream.creator1Id !== payload.userId && coStream.creator2Id !== payload.userId)
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });

    await prisma.coStream.delete({ where: { id } });
    return NextResponse.json({ status: "OK" });
  } catch (err) {
    console.error("[api/co-streams DELETE] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
