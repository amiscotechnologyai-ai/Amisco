import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// GET /api/streams/[id] — stream detail + recent chat
export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const stream = await prisma.stream.findUnique({
      where: { id: params.id },
      include: {
        host: { select: { displayName: true, avatarColor: true } },
        chatMessages: {
          orderBy: { createdAt: "desc" },
          take: 50,
          include: { user: { select: { displayName: true, avatarColor: true } } },
        },
      },
    });

    if (!stream) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }

    return NextResponse.json({
      id: stream.id,
      title: stream.title,
      category: stream.category,
      status: stream.status,
      coverColor: stream.coverColor,
      emoji: stream.emoji,
      hostId: stream.hostId,
      hostName: stream.host.displayName,
      listenerCount: stream.listenerCount,
      peakListeners: stream.peakListeners,
      startedAt: stream.startedAt?.toISOString() ?? null,
      chat: stream.chatMessages.reverse().map((m) => ({
        id: m.id,
        content: m.content,
        streamId: stream.id,
        userId: m.userId,
        username: m.user.displayName,
        avatarColor: m.user.avatarColor,
        createdAt: m.createdAt.toISOString(),
      })),
    });
  } catch (err) {
    console.error("[api/streams/:id GET] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
