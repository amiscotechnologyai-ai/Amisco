import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyToken, getTokenFromHeader } from "@/lib/auth";

// GET /api/streams?status=LIVE&category=Music
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status") as
      | "LIVE"
      | "SCHEDULED"
      | "ENDED"
      | null;
    const category = searchParams.get("category");

    const streams = await prisma.stream.findMany({
      where: {
        ...(status ? { status } : {}),
        ...(category && category !== "All" ? { category } : {}),
      },
      include: { host: { select: { displayName: true } } },
      orderBy: { listenerCount: "desc" },
    });

    return NextResponse.json(
      streams.map((s) => ({
        id: s.id,
        title: s.title,
        category: s.category,
        status: s.status,
        coverColor: s.coverColor,
        emoji: s.emoji,
        hostId: s.hostId,
        hostName: s.host.displayName,
        listenerCount: s.listenerCount,
        peakListeners: s.peakListeners,
        startedAt: s.startedAt?.toISOString() ?? null,
      }))
    );
  } catch (err) {
    console.error("[api/streams GET] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

// POST /api/streams — create a new stream (requires auth)
export async function POST(req: NextRequest) {
  try {
    const token = getTokenFromHeader(req.headers.get("authorization"));
    const payload = token ? verifyToken(token) : null;
    if (!payload) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { title, category, emoji, coverColor, showId } = await req.json();
    if (!title || !category) {
      return NextResponse.json({ error: "Missing fields" }, { status: 400 });
    }

    const stream = await prisma.stream.create({
      data: {
        title,
        category,
        emoji: emoji || "🔴",
        coverColor: coverColor || "#4c1d95",
        hostId: payload.userId,
        showId: showId || null,
        status: "LIVE",
        startedAt: new Date(),
      },
      include: { host: { select: { displayName: true } } },
    });

    // mark the user as a creator
    await prisma.user.update({
      where: { id: payload.userId },
      data: { isCreator: true },
    });

    return NextResponse.json({
      id: stream.id,
      title: stream.title,
      category: stream.category,
      status: stream.status,
      coverColor: stream.coverColor,
      emoji: stream.emoji,
      hostId: stream.hostId,
      hostName: stream.host.displayName,
      listenerCount: 0,
      peakListeners: 0,
      startedAt: stream.startedAt?.toISOString() ?? null,
    });
  } catch (err) {
    console.error("[api/streams POST] error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
