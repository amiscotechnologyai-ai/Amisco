import type { Metadata, Viewport } from "next";
import { Plus_Jakarta_Sans, Outfit } from "next/font/google";
import "./globals.css";
import { ThemeProvider } from "@/context/ThemeContext";
import { AuthProvider } from "@/context/AuthContext";
import { LocaleProvider } from "@/context/LocaleContext";
import { FloatingInstallBanner } from "@/components/FloatingInstallBanner";
import { PWAInstallPrompt } from "@/components/PWAInstallPrompt";
import { MobilePlayer } from "@/components/MobilePlayer";
import PWARegister from "@/components/PWARegister";

const display = Outfit({
  subsets: ["latin"],
  variable: "--font-display",
  weight: ["400", "500", "600", "700", "800", "900"],
});

const body = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-body",
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: "AmiFy — Amplify your voice",
  description:
    "Premium audio live streaming platform. Go live, listen to creators, enjoy background playback. Works offline, installs on home screen.",
  applicationName: "AmiFy",
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "AmiFy",
  },
  keywords: ["audio", "streaming", "live", "podcasts", "radio", "creators"],
};

export const viewport: Viewport = {
  themeColor: "#7c3aed",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover", // For notch support
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <head>
        {/* PWA Meta Tags */}
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="apple-mobile-web-app-title" content="AmiFy" />
        
        {/* Safe area for notch devices */}
        <meta name="viewport-fit" content="cover" />
        
        {/* Favicon - AmiFy Logo */}
        <link rel="icon" href="/favicon.ico" sizes="32x32" />
        <link rel="icon" href="/favicon-32.png" type="image/png" sizes="32x32" />
        
        {/* Apple Touch Icon - AmiFy Logo for iOS */}
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        
        {/* Theme color matches logo navy blue */}
        <meta name="theme-color" content="#1a2332" />
        
        {/* Service Worker registration */}
        <PWARegister />
      </head>
      <body className={`${display.variable} ${body.variable} antialiased`}>
        <ThemeProvider>
          <LocaleProvider>
            <AuthProvider>
              {children}
              
              {/* Floating Install Banner - PROMINENT, shows immediately on first visit */}
              <FloatingInstallBanner />
              
              {/* PWA Install Prompt (alternative for some devices) */}
              <PWAInstallPrompt />
              
              {/* Mobile Player for background audio */}
              <MobilePlayer
                streamTitle="Live Stream"
                creatorName="Creator"
              />
            </AuthProvider>
          </LocaleProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
