// components/FloatingInstallBanner.tsx
// Super prominent floating banner - appears immediately on first visit
// Visual-first design for non-technical users

'use client';

import { useState, useEffect } from 'react';
import { Download, X, Smartphone, ArrowDown } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export function FloatingInstallBanner() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showBanner, setShowBanner] = useState(false);
  const [installed, setInstalled] = useState(false);
  const [isAndroid, setIsAndroid] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  useEffect(() => {
    // Check device type
    const ua = navigator.userAgent;
    setIsAndroid(/Android/.test(ua));
    setIsIOS(/iPad|iPhone|iPod/.test(ua));

    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setInstalled(true);
      return;
    }

    // Check if already dismissed today
    const dismissedDate = localStorage.getItem('pwa-banner-dismissed-date');
    const today = new Date().toDateString();
    if (dismissedDate === today) {
      return;
    }

    // Listen for beforeinstallprompt (Android)
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      // Show immediately on first visit
      setShowBanner(true);
    };

    window.addEventListener('beforeinstallprompt', handler);

    // iOS: Show banner immediately
    if (isIOS && !installed) {
      // Small delay to not be too aggressive
      setTimeout(() => setShowBanner(true), 1000);
    }

    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, [installed, isIOS]);

  const handleAndroidInstall = async () => {
    if (!deferredPrompt) return;

    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;

    if (outcome === 'accepted') {
      setShowBanner(false);
      setDeferredPrompt(null);
      localStorage.removeItem('pwa-banner-dismissed-date');
    } else {
      dismissBanner();
    }
  };

  const dismissBanner = () => {
    setShowBanner(false);
    const today = new Date().toDateString();
    localStorage.setItem('pwa-banner-dismissed-date', today);
  };

  if (installed || !showBanner) {
    return null;
  }

  // ============================================
  // ANDROID: One-click install
  // ============================================
  if (isAndroid && deferredPrompt) {
    return (
      <div className="fixed top-0 left-0 right-0 z-[300] animate-in slide-in-from-top-4 duration-500">
        {/* Gradient background */}
        <div className="absolute inset-0 bg-gradient-to-r from-brand-600 via-purple-600 to-brand-500 opacity-95 backdrop-blur-md" />

        {/* Content */}
        <div className="relative px-4 py-4 max-w-2xl mx-auto">
          <div className="flex items-center gap-3">
            {/* Animated icon */}
            <div className="flex-shrink-0">
              <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center animate-bounce">
                <Smartphone size={28} className="text-white" />
              </div>
            </div>

            {/* Main text (minimal) */}
            <div className="flex-1 min-w-0">
              <p className="font-bold text-white text-base leading-tight">
                📱 Add AmiFy to Home Screen
              </p>
              <p className="text-xs text-white/80 mt-1 leading-tight">
                🎧 Listen offline • ⚡ Fast • 📴 Works everywhere
              </p>
            </div>

            {/* Buttons */}
            <div className="flex gap-2 flex-shrink-0">
              {/* Install button - BIG and green */}
              <button
                onClick={handleAndroidInstall}
                className="px-5 py-3 rounded-xl bg-white text-brand-600 font-black text-sm hover:bg-gray-100 transition-all transform hover:scale-105 active:scale-95 shadow-lg"
              >
                ✓ Add
              </button>

              {/* Close button */}
              <button
                onClick={dismissBanner}
                className="p-2.5 rounded-xl bg-white/20 hover:bg-white/30 transition text-white"
              >
                <X size={20} />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ============================================
  // iOS: Visual step-by-step guide
  // ============================================
  if (isIOS && !showIOSGuide) {
    return (
      <div className="fixed top-0 left-0 right-0 z-[300] animate-in slide-in-from-top-4 duration-500">
        <div className="absolute inset-0 bg-gradient-to-r from-brand-600 via-purple-600 to-brand-500 opacity-95 backdrop-blur-md" />

        <div className="relative px-4 py-4 max-w-2xl mx-auto">
          <div className="flex items-center gap-3">
            {/* Icon */}
            <div className="flex-shrink-0">
              <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center animate-bounce">
                <Smartphone size={28} className="text-white" />
              </div>
            </div>

            {/* Text */}
            <div className="flex-1 min-w-0">
              <p className="font-bold text-white text-base leading-tight">
                📱 Add AmiFy to Home Screen
              </p>
              <p className="text-xs text-white/80 mt-1 leading-tight">
                Tap Share → Add to Home Screen
              </p>
            </div>

            {/* Buttons */}
            <div className="flex gap-2 flex-shrink-0">
              <button
                onClick={() => setShowIOSGuide(true)}
                className="px-5 py-3 rounded-xl bg-white text-brand-600 font-black text-sm hover:bg-gray-100 transition-all transform hover:scale-105 active:scale-95 shadow-lg"
              >
                How?
              </button>
              <button
                onClick={dismissBanner}
                className="p-2.5 rounded-xl bg-white/20 hover:bg-white/30 transition text-white"
              >
                <X size={20} />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ============================================
  // iOS: Visual step-by-step modal
  // ============================================
  if (isIOS && showIOSGuide) {
    return (
      <div className="fixed inset-0 z-[300] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
        <div className="bg-[var(--bg-elevated)] rounded-3xl p-6 max-w-sm w-full shadow-2xl animate-in zoom-in-50 duration-300">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-black text-white">How to Add AmiFy</h2>
            <button
              onClick={() => {
                setShowIOSGuide(false);
                dismissBanner();
              }}
              className="p-2 rounded-full hover:bg-[var(--bg)] transition"
            >
              <X size={24} className="text-[var(--text-muted)]" />
            </button>
          </div>

          {/* Visual steps */}
          <div className="space-y-4 mb-8">
            {/* Step 1: Share */}
            <div className="bg-[var(--bg)] rounded-2xl p-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-brand-500/20 text-brand-500 flex items-center justify-center font-bold flex-shrink-0">
                  1
                </div>
                <p className="font-bold text-white text-sm">Tap Share ⬆️</p>
              </div>
              <p className="text-xs text-[var(--text-muted)] ml-13">
                Look for the arrow button at the bottom of Safari
              </p>
            </div>

            {/* Arrow */}
            <div className="flex justify-center">
              <ArrowDown size={20} className="text-brand-500 animate-bounce" />
            </div>

            {/* Step 2: Scroll */}
            <div className="bg-[var(--bg)] rounded-2xl p-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-brand-500/20 text-brand-500 flex items-center justify-center font-bold flex-shrink-0">
                  2
                </div>
                <p className="font-bold text-white text-sm">Scroll Down</p>
              </div>
              <p className="text-xs text-[var(--text-muted)] ml-13">
                Swipe through the options
              </p>
            </div>

            {/* Arrow */}
            <div className="flex justify-center">
              <ArrowDown size={20} className="text-brand-500 animate-bounce" />
            </div>

            {/* Step 3: Add to Home Screen */}
            <div className="bg-brand-500/10 border border-brand-500/30 rounded-2xl p-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-brand-500 text-white flex items-center justify-center font-bold flex-shrink-0">
                  3
                </div>
                <p className="font-bold text-white text-sm">Tap "Add to Home Screen"</p>
              </div>
              <p className="text-xs text-[var(--text-muted)] ml-13">
                You'll see this option in the list
              </p>
            </div>

            {/* Arrow */}
            <div className="flex justify-center">
              <ArrowDown size={20} className="text-brand-500 animate-bounce" />
            </div>

            {/* Step 4: Confirm */}
            <div className="bg-[var(--bg)] rounded-2xl p-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-green-500/20 text-green-400 flex items-center justify-center font-bold flex-shrink-0">
                  ✓
                </div>
                <p className="font-bold text-white text-sm">Tap "Add"</p>
              </div>
              <p className="text-xs text-[var(--text-muted)] ml-13">
                AmiFy appears on your home screen!
              </p>
            </div>
          </div>

          {/* Benefits cards */}
          <div className="grid grid-cols-3 gap-2 mb-6">
            <div className="bg-[var(--bg)] rounded-lg p-3 text-center">
              <p className="text-2xl mb-1">🎧</p>
              <p className="text-xs text-[var(--text-muted)] font-medium">Listen Offline</p>
            </div>
            <div className="bg-[var(--bg)] rounded-lg p-3 text-center">
              <p className="text-2xl mb-1">⚡</p>
              <p className="text-xs text-[var(--text-muted)] font-medium">Super Fast</p>
            </div>
            <div className="bg-[var(--bg)] rounded-lg p-3 text-center">
              <p className="text-2xl mb-1">🔔</p>
              <p className="text-xs text-[var(--text-muted)] font-medium">Get Alerts</p>
            </div>
          </div>

          {/* Action buttons */}
          <button
            onClick={() => {
              setShowIOSGuide(false);
              dismissBanner();
            }}
            className="w-full py-3 rounded-xl bg-brand-600 text-white font-bold text-sm hover:bg-brand-700 transition"
          >
            Got It! Let's Go ✓
          </button>
        </div>
      </div>
    );
  }

  return null;
}
