"use client";

import { useEffect, useState, useRef } from "react";
import {
  X,
  Send,
  Users,
  Mic,
  MicOff,
  Hand,
  Gift,
  BarChart3,
  MessageCircle,
  HelpCircle,
  Pin,
  Plus,
  ChevronUp,
  Heart,
  Flag,
} from "lucide-react";
import { useLiveStream, useEngagement } from "@/hooks/useSocket";
import { useAudioRoom } from "@/hooks/useAudioRoom";
import { useAuth } from "@/context/AuthContext";
import type { StreamDTO, ChatMessageDTO } from "@/types";

type Tab = "chat" | "polls" | "qa" | "mod";

const QUICK_REACTIONS = ["❤️", "🔥", "👏", "😂", "🎉", "💯"];
const GIFTS = [
  { type: "rose", emoji: "🌹", amount: 100, label: "Rose" },
  { type: "coffee", emoji: "☕", amount: 300, label: "Coffee" },
  { type: "rocket", emoji: "🚀", amount: 1000, label: "Rocket" },
  { type: "crown", emoji: "👑", amount: 5000, label: "Crown" },
];

export default function LiveRoom({
  stream,
  onClose,
}: {
  stream: StreamDTO;
  onClose: () => void;
}) {
  const { user, token } = useAuth();
  const { listeners, messages, sendMessage, setInitialMessages } =
    useLiveStream(stream.id, token);
  const eng = useEngagement(stream.id, token);
  const audio = useAudioRoom(stream.id, token);

  const [tab, setTab] = useState<Tab>("chat");
  const [input, setInput] = useState("");
  const [showGifts, setShowGifts] = useState(false);
  const [showPollForm, setShowPollForm] = useState(false);
  const [reportSubmitted, setReportSubmitted] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const isHost = user?.id === stream.hostId;
  const liveCount = listeners || stream.listenerCount;

  const submitReport = async () => {
    if (!token) return;
    try {
      await fetch("/api/reports", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          targetType: "stream",
          targetId: stream.id,
          reason: "Inappropriate content",
        }),
      });
      setReportSubmitted(true);
      setTimeout(() => setReportSubmitted(false), 3000);
    } catch (e) {
      console.error("Report failed:", e);
    }
  };

  useEffect(() => {
    fetch(`/api/streams/${stream.id}`)
      .then((r) => r.json())
      .then((d) => d.chat && setInitialMessages(d.chat))
      .catch(() => {});
  }, [stream.id, setInitialMessages]);

  useEffect(() => {
    if (tab === "chat") chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, tab]);

  const handleSend = () => {
    if (!input.trim()) return;
    sendMessage(input.trim());
    setInput("");
  };

  const sendGift = async (gift: (typeof GIFTS)[number]) => {
    if (!token) return;
    setShowGifts(false);
    eng.sendReaction(gift.emoji);
    await fetch("/api/tips", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        recipientId: stream.hostId,
        streamId: stream.id,
        amountMinor: gift.amount,
        giftType: gift.type,
      }),
    }).catch(() => {});
  };

  return (
    <div className="fixed inset-0 z-[90] flex flex-col bg-[var(--bg)]">
      {reportSubmitted && (
        <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-[101] px-4 py-2 rounded-lg bg-green-500/20 border border-green-500/50 text-green-400 text-sm">
          ✓ Report submitted
        </div>
      )}
      {/* ---- Stage header ---- */}
      <div
        className="relative pt-4 pb-5 px-5"
        style={{
          background: `linear-gradient(135deg, ${stream.coverColor}, ${stream.coverColor}77)`,
        }}
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="bg-red-500 text-white text-[10px] font-black px-2.5 py-1 rounded-full flex items-center gap-1.5">
              <span className="w-2 h-2 bg-white rounded-full animate-pulse" /> LIVE
            </span>
            <span className="bg-black/40 backdrop-blur text-white text-xs font-semibold px-2.5 py-1 rounded-full flex items-center gap-1">
              <Users size={12} /> {liveCount.toLocaleString()}
            </span>
          </div>
          <div className="flex items-center gap-2">
            {user && (
              <button
                onClick={submitReport}
                className="p-2 rounded-full bg-black/30 text-white hover:bg-red-500/50 transition"
                title="Report this stream"
              >
                <Flag size={18} />
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-full bg-black/30 text-white hover:bg-black/50 transition"
            >
              <X size={20} />
            </button>
          </div>

        {/* Speaker stage */}
        <div className="flex flex-wrap gap-4 mb-3">
          <SpeakerAvatar
            name={stream.hostName}
            color="#ffffff33"
            label="Host"
            speaking={audio.micEnabled}
          />
          {eng.speakers
            .filter((s) => s.role !== "HOST")
            .map((sp) => (
              <SpeakerAvatar
                key={sp.userId}
                name={sp.username}
                color={sp.avatarColor}
                label={sp.role === "COHOST" ? "Co-host" : "Speaker"}
                speaking={!sp.muted}
                onClick={
                  isHost && sp.handRaised
                    ? () => eng.inviteToStage(sp.userId)
                    : undefined
                }
              />
            ))}
        </div>

        <h2 className="text-2xl font-black text-white drop-shadow">
          {stream.title}
        </h2>
        <p className="text-white/80 text-sm">{stream.category}</p>

        {/* Audio status */}
        {audio.message && (
          <p className="mt-2 text-[11px] text-white/70 bg-black/20 rounded-lg px-2 py-1">
            🎧 {audio.message}
          </p>
        )}
        </div>
      </div>

      {/* Pinned message */}
      {eng.pinned && (
        <div className="mx-4 mt-3 p-3 rounded-xl bg-brand-500/10 border border-brand-500/30 flex items-start gap-2">
          <Pin size={14} className="text-brand-500 mt-0.5 shrink-0" />
          <p className="text-sm">
            <span className="font-bold text-brand-500">
              {eng.pinned.username}:{" "}
            </span>
            {eng.pinned.content}
          </p>
        </div>
      )}

      {/* Tip Goal Progress */}
      {eng.tipGoal && (
        <div className="mx-4 mt-3 p-3 rounded-xl bg-green-500/10 border border-green-500/30">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-bold text-green-500">{eng.tipGoal.title}</span>
            <span className="text-xs opacity-60">
              GHS {(eng.tipGoal.currentMinor / 100).toFixed(2)} / {(eng.tipGoal.targetMinor / 100).toFixed(2)}
            </span>
          </div>
          <div className="w-full bg-[var(--bg-elevated)] rounded-full h-2 overflow-hidden">
            <div
              className="h-full bg-green-500 transition-all duration-300"
              style={{ width: `${Math.min(100, (eng.tipGoal.currentMinor / eng.tipGoal.targetMinor) * 100)}%` }}
            />
          </div>
          {eng.tipGoal.reached && <p className="text-xs text-green-400 mt-1">🎉 Goal reached!</p>}
        </div>
      )}

      {/* ---- Tabs ---- */}
      <div className="flex border-b border-[var(--border)] mt-3 px-2 overflow-x-auto">
        <TabBtn active={tab === "chat"} onClick={() => setTab("chat")} icon={MessageCircle} label="Chat" />
        <TabBtn active={tab === "polls"} onClick={() => setTab("polls")} icon={BarChart3} label={`Polls${eng.polls.length ? ` (${eng.polls.length})` : ""}`} />
        <TabBtn active={tab === "qa"} onClick={() => setTab("qa")} icon={HelpCircle} label={`Q&A${eng.questions.length ? ` (${eng.questions.length})` : ""}`} />
        {user?.id === stream.host.id && (
          <TabBtn active={tab === "mod"} onClick={() => setTab("mod" as Tab)} icon={BarChart3} label="Moderation" />
        )}
      </div>

      {/* ---- Content ---- */}
      <div className="flex-1 overflow-y-auto custom-scroll relative">
        {/* Floating reactions */}
        <div className="pointer-events-none absolute bottom-0 right-6 z-20">
          {eng.reactions.map((r) => (
            <span
              key={r.id}
              className="absolute bottom-0 text-3xl animate-fade-up"
              style={{ animation: "floatUp 2.4s ease-out forwards", right: `${Math.random() * 40}px` }}
            >
              {r.emoji}
            </span>
          ))}
        </div>

        {tab === "chat" && (
          <div className="px-5 py-4 space-y-3">
            {messages.length === 0 && (
              <p className="text-center text-sm text-[var(--text-muted)] py-8">
                Be the first to say hello 👋
              </p>
            )}
            {messages.map((m: ChatMessageDTO) => (
              <div key={m.id} className="flex items-start gap-2.5 group">
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold shrink-0"
                  style={{ backgroundColor: m.avatarColor }}
                >
                  {m.username.slice(0, 2).toUpperCase()}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <p className="text-xs font-bold text-brand-500">{m.username}</p>
                    {/* Listener badges - in production these would come from API */}
                    {m.userId === stream.host.id && <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-purple-500/30 text-purple-300 font-bold">HOST</span>}
                    {m.userId !== stream.host.id && Math.random() > 0.7 && (
                      <>
                        {Math.random() > 0.5 && <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-500/30 text-amber-300 font-bold">💎 MEMBER</span>}
                        {Math.random() > 0.6 && <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-pink-500/30 text-pink-300 font-bold">🎁 TIPPER</span>}
                      </>
                    )}
                  </div>
                  <p className="text-sm break-words">{m.content}</p>
                </div>
                {isHost && (
                  <button
                    onClick={() => eng.pinMessage(m.id)}
                    className="opacity-0 group-hover:opacity-100 transition text-[var(--text-muted)] hover:text-brand-500"
                  >
                    <Pin size={14} />
                  </button>
                )}
              </div>
            ))}
            <div ref={chatEndRef} />
          </div>
        )}

        {tab === "polls" && (
          <div className="px-5 py-4 space-y-4">
            {isHost && (
              <button
                onClick={() => setShowPollForm(true)}
                className="w-full p-3 rounded-xl border border-dashed border-brand-500/40 text-brand-500 font-semibold flex items-center justify-center gap-2"
              >
                <Plus size={16} /> Create a poll
              </button>
            )}
            {eng.polls.length === 0 && (
              <p className="text-center text-sm text-[var(--text-muted)] py-8">
                No polls yet.
              </p>
            )}
            {eng.polls.map((poll) => (
              <div key={poll.id} className="p-4 rounded-2xl bg-[var(--bg-elevated)]">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-bold">{poll.question}</h4>
                  {isHost && !poll.closed && (
                    <button
                      onClick={() => eng.closePoll(poll.id)}
                      className="text-xs text-[var(--text-muted)]"
                    >
                      Close
                    </button>
                  )}
                </div>
                <div className="space-y-2">
                  {poll.options.map((o) => {
                    const pct = poll.totalVotes
                      ? Math.round((o.votes / poll.totalVotes) * 100)
                      : 0;
                    return (
                      <button
                        key={o.id}
                        disabled={poll.closed}
                        onClick={() => eng.votePoll(poll.id, o.id)}
                        className="w-full relative rounded-lg overflow-hidden text-left disabled:cursor-default"
                      >
                        <div
                          className="absolute inset-0 bg-brand-500/20"
                          style={{ width: `${pct}%` }}
                        />
                        <div className="relative flex justify-between px-3 py-2.5 text-sm">
                          <span className="font-medium">{o.label}</span>
                          <span className="text-[var(--text-muted)]">{pct}%</span>
                        </div>
                      </button>
                    );
                  })}
                </div>
                <p className="text-xs text-[var(--text-muted)] mt-2">
                  {poll.totalVotes} votes {poll.closed && "· closed"}
                </p>
              </div>
            ))}
          </div>
        )}

        {tab === "qa" && (
          <div className="px-5 py-4 space-y-3">
            {user && <QuestionInput onAsk={(c) => eng.askQuestion(c)} />}
            {[...eng.questions]
              .sort((a, b) => b.voteCount - a.voteCount)
              .map((q) => (
                <div
                  key={q.id}
                  className={`p-3 rounded-xl flex items-start gap-3 ${
                    q.answered
                      ? "bg-green-500/10 border border-green-500/20"
                      : "bg-[var(--bg-elevated)]"
                  }`}
                >
                  <button
                    onClick={() => eng.upvoteQuestion(q.id)}
                    className="flex flex-col items-center text-brand-500"
                  >
                    <ChevronUp size={18} />
                    <span className="text-xs font-bold">{q.voteCount}</span>
                  </button>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-[var(--text-muted)]">
                      {q.username}
                    </p>
                    <p className="text-sm">{q.content}</p>
                  </div>
                  {isHost && !q.answered && (
                    <button
                      onClick={() => eng.answerQuestion(q.id)}
                      className="text-xs text-green-500 font-semibold"
                    >
                      Mark answered
                    </button>
                  )}
                </div>
              ))}
            {eng.questions.length === 0 && (
              <p className="text-center text-sm text-[var(--text-muted)] py-8">
                No questions yet — ask one!
              </p>
            )}
          </div>
        )}

        {tab === "mod" && user?.id === stream.host.id && (
          <div className="px-5 py-4 space-y-4">
            <div className="space-y-3">
              <div className="p-3 rounded-xl bg-[var(--bg-elevated)]">
                <label className="text-xs font-bold block mb-2">Slow Mode (seconds)</label>
                <input
                  type="number"
                  min="0"
                  max="300"
                  defaultValue={eng.moderation?.slowModeSec || 0}
                  onChange={(e) => eng.setSlowMode(Math.floor(parseFloat(e.target.value) || 0))}
                  className="w-full px-3 py-2 rounded-lg bg-[var(--bg)] text-sm border border-[var(--border)]"
                  placeholder="0 for off"
                />
              </div>
              <div className="p-3 rounded-xl bg-[var(--bg-elevated)]">
                <label className="text-xs font-bold block mb-2">Banned Words (comma-separated)</label>
                <textarea
                  defaultValue={eng.moderation?.bannedWords || ""}
                  onChange={(e) => eng.setBannedWords(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[var(--bg)] text-sm border border-[var(--border)] font-mono text-xs"
                  rows={3}
                  placeholder="Enter words to filter"
                />
              </div>
            </div>
            <div className="p-3 rounded-xl bg-[var(--bg-elevated)]">
              <p className="text-xs font-bold mb-2">Active Speakers</p>
              <div className="space-y-1 max-h-48 overflow-y-auto">
                {eng.speakers.map((sp) => (
                  <div key={sp.userId} className="flex items-center justify-between py-1 px-2 rounded bg-[var(--bg)] text-xs">
                    <span>{sp.username} ({sp.role})</span>
                    <div className="flex gap-1">
                      <button
                        onClick={() => eng.muteUser(sp.userId, !sp.muted)}
                        className="px-2 py-1 rounded text-[10px] bg-brand-500/20 hover:bg-brand-500/40 text-brand-400"
                      >
                        {sp.muted ? "Unmute" : "Mute"}
                      </button>
                      <button
                        onClick={() => eng.kickUser(sp.userId)}
                        className="px-2 py-1 rounded text-[10px] bg-red-500/20 hover:bg-red-500/40 text-red-400"
                      >
                        Kick
                      </button>
                    </div>
                  </div>
                ))}
                {eng.speakers.length === 0 && (
                  <p className="text-[var(--text-muted)] py-2">No speakers</p>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ---- Action bar ---- */}
      <div className="border-t border-[var(--border)] p-3 space-y-2">
        {eng.chatError && (
          <div className="px-3 py-2 text-xs rounded-lg bg-red-500/10 border border-red-500/30 text-red-400">
            {eng.chatError}
          </div>
        )}
        {/* Quick reactions */}
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide">
          {QUICK_REACTIONS.map((e) => (
            <button
              key={e}
              onClick={() => eng.sendReaction(e)}
              className="text-xl shrink-0 hover:scale-125 transition"
            >
              {e}
            </button>
          ))}
          <div className="flex-1" />
          {/* Host mic / listener raise hand */}
          {isHost || eng.speakers.some((s) => s.userId === user?.id && s.role !== "LISTENER") ? (
            <button
              onClick={audio.toggleMic}
              className={`p-2 rounded-full ${
                audio.micEnabled ? "bg-brand-600 text-white" : "bg-[var(--bg-elevated)]"
              }`}
            >
              {audio.micEnabled ? <Mic size={18} /> : <MicOff size={18} />}
            </button>
          ) : (
            user && (
              <button
                onClick={eng.raiseHand}
                className="p-2 rounded-full bg-[var(--bg-elevated)] hover:bg-brand-500/20 transition"
                title="Raise hand to speak"
              >
                <Hand size={18} />
              </button>
            )
          )}
          {/* Tip / gift */}
          {user && (
            <button
              onClick={() => setShowGifts((s) => !s)}
              className="p-2 rounded-full bg-gradient-to-r from-amber-500 to-pink-500 text-white"
            >
              <Gift size={18} />
            </button>
          )}
        </div>

        {/* Gift picker */}
        {showGifts && (
          <div className="grid grid-cols-4 gap-2 p-2 rounded-xl bg-[var(--bg-elevated)]">
            {GIFTS.map((g) => (
              <button
                key={g.type}
                onClick={() => sendGift(g)}
                className="flex flex-col items-center p-2 rounded-lg hover:bg-[var(--bg)] transition"
              >
                <span className="text-2xl">{g.emoji}</span>
                <span className="text-[10px] font-bold mt-1">{g.label}</span>
                <span className="text-[10px] text-[var(--text-muted)]">
                  GHS {(g.amount / 100).toFixed(0)}
                </span>
              </button>
            ))}
          </div>
        )}

        {/* Chat input */}
        {tab === "chat" &&
          (user ? (
            <div className="flex items-center gap-2">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
                placeholder="Send a message…"
                className="flex-1 px-4 py-2.5 rounded-full bg-[var(--bg-elevated)] border border-[var(--border)] outline-none focus:border-brand-500 transition text-sm"
              />
              <button
                onClick={handleSend}
                className="w-10 h-10 rounded-full bg-brand-600 text-white flex items-center justify-center"
              >
                <Send size={16} />
              </button>
            </div>
          ) : (
            <p className="text-center text-sm text-[var(--text-muted)] py-1">
              Sign in to join the conversation
            </p>
          ))}
      </div>

      {/* Recent tips ticker */}
      {eng.tips.length > 0 && (
        <div className="absolute top-44 left-0 right-0 px-4 pointer-events-none">
          {eng.tips.slice(-1).map((t) => (
            <div
              key={t.id}
              className="mx-auto w-fit bg-gradient-to-r from-amber-500 to-pink-500 text-white text-sm font-bold px-4 py-2 rounded-full shadow-lg flex items-center gap-2 animate-fade-up"
            >
              <Heart size={14} fill="white" /> {t.senderName} sent {t.giftType || "a tip"}!
            </div>
          ))}
        </div>
      )}

      {showPollForm && (
        <PollForm
          onClose={() => setShowPollForm(false)}
          onCreate={(q, opts) => {
            eng.createPoll(q, opts);
            setShowPollForm(false);
            setTab("polls");
          }}
        />
      )}

      <style>{`
        @keyframes floatUp {
          0% { transform: translateY(0) scale(1); opacity: 1; }
          100% { transform: translateY(-180px) scale(1.4); opacity: 0; }
        }
      `}</style>
    </div>
  );
}

// ---- sub-components ----

function SpeakerAvatar({
  name,
  color,
  label,
  speaking,
  onClick,
}: {
  name: string;
  color: string;
  label: string;
  speaking?: boolean;
  onClick?: () => void;
}) {
  return (
    <button onClick={onClick} className="flex flex-col items-center gap-1">
      <div
        className={`w-14 h-14 rounded-full flex items-center justify-center text-white font-bold ${
          speaking ? "ring-2 ring-green-400 ring-offset-2 ring-offset-transparent" : ""
        }`}
        style={{ backgroundColor: color }}
      >
        {name.slice(0, 2).toUpperCase()}
      </div>
      <span className="text-[10px] text-white font-semibold">{name.split(" ")[0]}</span>
      <span className="text-[9px] text-white/70">{label}</span>
    </button>
  );
}

function TabBtn({
  active,
  onClick,
  icon: Icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: typeof MessageCircle;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex-1 py-3 flex items-center justify-center gap-1.5 text-sm font-bold border-b-2 transition ${
        active
          ? "border-brand-500 text-brand-500"
          : "border-transparent text-[var(--text-muted)]"
      }`}
    >
      <Icon size={16} /> {label}
    </button>
  );
}

function QuestionInput({ onAsk }: { onAsk: (c: string) => void }) {
  const [v, setV] = useState("");
  return (
    <div className="flex items-center gap-2 mb-2">
      <input
        value={v}
        onChange={(e) => setV(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && v.trim()) {
            onAsk(v.trim());
            setV("");
          }
        }}
        placeholder="Ask the host a question…"
        className="flex-1 px-4 py-2.5 rounded-full bg-[var(--bg-elevated)] border border-[var(--border)] outline-none focus:border-brand-500 text-sm"
      />
      <button
        onClick={() => {
          if (v.trim()) {
            onAsk(v.trim());
            setV("");
          }
        }}
        className="px-4 py-2.5 rounded-full bg-brand-600 text-white text-sm font-bold"
      >
        Ask
      </button>
    </div>
  );
}

function PollForm({
  onClose,
  onCreate,
}: {
  onClose: () => void;
  onCreate: (q: string, opts: string[]) => void;
}) {
  const [q, setQ] = useState("");
  const [opts, setOpts] = useState(["", ""]);
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="w-full max-w-md rounded-3xl bg-[var(--bg-elevated)] border border-[var(--border)] p-6">
        <h3 className="text-xl font-black mb-4">Create a poll</h3>
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Question"
          className="w-full px-4 py-3 rounded-xl bg-[var(--bg)] border border-[var(--border)] outline-none mb-3"
        />
        {opts.map((o, i) => (
          <input
            key={i}
            value={o}
            onChange={(e) => {
              const next = [...opts];
              next[i] = e.target.value;
              setOpts(next);
            }}
            placeholder={`Option ${i + 1}`}
            className="w-full px-4 py-2.5 rounded-xl bg-[var(--bg)] border border-[var(--border)] outline-none mb-2"
          />
        ))}
        {opts.length < 6 && (
          <button
            onClick={() => setOpts([...opts, ""])}
            className="text-sm text-brand-500 font-semibold mb-3"
          >
            + Add option
          </button>
        )}
        <button
          onClick={() => {
            const valid = opts.map((o) => o.trim()).filter(Boolean);
            if (q.trim() && valid.length >= 2) onCreate(q.trim(), valid);
          }}
          className="w-full py-3 rounded-xl font-bold bg-gradient-to-r from-brand-600 to-indigo-600 text-white"
        >
          Launch poll
        </button>
        <button onClick={onClose} className="w-full text-sm text-[var(--text-muted)] mt-2">
          Cancel
        </button>
      </div>
    </div>
  );
}
