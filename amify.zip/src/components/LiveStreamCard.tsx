"use client";

import { Play, Users } from "lucide-react";
import type { StreamDTO } from "@/types";

interface Props {
  stream: StreamDTO;
  liveCount?: number;
  onClick: () => void;
}

export default function LiveStreamCard({ stream, liveCount, onClick }: Props) {
  const count = liveCount ?? stream.listenerCount;
  const isLive = stream.status === "LIVE";

  return (
    <button
      onClick={onClick}
      className="text-left rounded-2xl overflow-hidden group transition hover:scale-[1.02] active:scale-[0.98] w-full"
    >
      <div
        className="aspect-video relative flex items-center justify-center overflow-hidden"
        style={{
          background: `linear-gradient(135deg, ${stream.coverColor}, ${stream.coverColor}99)`,
        }}
      >
        <span className="text-6xl drop-shadow-lg select-none">
          {stream.emoji}
        </span>

        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition flex items-center justify-center">
          <div className="w-16 h-16 rounded-full bg-white/25 flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
            <Play size={30} className="text-white ml-1" fill="white" />
          </div>
        </div>

        {isLive && (
          <div className="absolute top-3 left-3 bg-red-500 text-white text-[10px] font-black px-2.5 py-1 rounded-full flex items-center gap-1.5">
            <span className="w-2 h-2 bg-white rounded-full animate-pulse" />
            LIVE
          </div>
        )}

        <div className="absolute top-3 right-3 bg-black/40 backdrop-blur-sm text-white text-[11px] font-semibold px-2.5 py-1 rounded-full flex items-center gap-1">
          <Users size={12} />
          {count.toLocaleString()}
        </div>

        <div className="absolute bottom-3 left-3">
          <span
            className="inline-block text-[10px] font-bold px-2 py-1 rounded-md text-white"
            style={{ backgroundColor: "rgba(0,0,0,0.4)" }}
          >
            {stream.category}
          </span>
        </div>
      </div>

      <div className="p-3 bg-[var(--bg-elevated)]">
        <h3 className="font-bold text-base leading-tight mb-0.5 truncate">
          {stream.title}
        </h3>
        <p className="text-xs text-[var(--text-muted)] truncate">
          {stream.hostName}
        </p>
      </div>
    </button>
  );
}
