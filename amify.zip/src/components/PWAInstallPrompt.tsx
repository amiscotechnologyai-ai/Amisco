// components/PWAInstallPrompt.tsx
// Floating install prompt - visible and prominent for first-time visitors

'use client';

import { useState, useEffect } from 'react';
import { Download, X, Smartphone } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export function PWAInstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showPrompt, setShowPrompt] = useState(false);
  const [showManualAndroid, setShowManualAndroid] = useState(false);
  const [showManualIOS, setShowManualIOS] = useState(false);
  const [installed, setInstalled] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
  const isAndroid = /Android/.test(navigator.userAgent);

  useEffect(() => {
    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setInstalled(true);
      return;
    }

    // Check if user dismissed (show again after 7 days)
    const dismissTime = localStorage.getItem('pwa-install-dismissed-time');
    if (dismissTime) {
      const daysSinceDismiss = (Date.now() - parseInt(dismissTime)) / (1000 * 60 * 60 * 24);
      if (daysSinceDismiss < 7) {
        return;
      }
    }

    // Listen for beforeinstallprompt (Android Chrome)
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      // Show immediately on first visit
      setShowPrompt(true);
    };

    window.addEventListener('beforeinstallprompt', handler);

    // iOS: Show manual instructions immediately
    if (isIOS && !installed && !dismissed) {
      // Delay slightly to avoid being intrusive
      setTimeout(() => {
        setShowPrompt(true);
      }, 500);
    }

    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, [installed, dismissed, isIOS]);

  const handleAndroidInstall = async () => {
    if (!deferredPrompt) return;

    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;

    if (outcome === 'accepted') {
      setShowPrompt(false);
      setDeferredPrompt(null);
      localStorage.removeItem('pwa-install-dismissed-time');
    } else {
      handleDismiss();
    }
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    setDismissed(true);
    localStorage.setItem('pwa-install-dismissed-time', Date.now().toString());
  };

  if (installed || !showPrompt || dismissed) {
    return null;
  }

  // ANDROID: Automatic install (Chrome has native support)
  if (isAndroid && deferredPrompt) {
    return (
      <div className="fixed top-0 left-0 right-0 z-[200] animate-in slide-in-from-top-2">
        <div className="bg-gradient-to-r from-brand-600 to-purple-600 text-white p-4 shadow-lg">
          <div className="max-w-xl mx-auto flex items-center gap-3">
            {/* Icon */}
            <div className="flex-shrink-0">
              <div className="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center animate-bounce">
                <Download size={24} className="text-white" />
              </div>
            </div>

            {/* Text */}
            <div className="flex-1 min-w-0">
              <p className="font-bold text-sm">📱 Add AmiFy to Home Screen</p>
              <p className="text-xs opacity-90 mt-0.5">Listen offline • Background audio • Fast access</p>
            </div>

            {/* Buttons */}
            <div className="flex gap-2 flex-shrink-0">
              <button
                onClick={handleAndroidInstall}
                className="px-4 py-2 rounded-lg bg-white text-brand-600 font-bold text-sm hover:bg-gray-100 transition whitespace-nowrap"
              >
                Install
              </button>
              <button
                onClick={handleDismiss}
                className="p-2 rounded-lg hover:bg-white/20 transition"
              >
                <X size={20} />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // iOS: Manual installation guide
  if (isIOS) {
    return (
      <div className="fixed inset-0 z-[200] bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
        <div className="bg-[var(--bg-elevated)] rounded-3xl p-6 max-w-sm w-full shadow-2xl">
          {/* Close button */}
          <button
            onClick={handleDismiss}
            className="absolute top-4 right-4 p-2 rounded-full hover:bg-[var(--bg)] transition"
          >
            <X size={24} />
          </button>

          {/* Header with icon */}
          <div className="text-center mb-6">
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-brand-500 to-purple-600 flex items-center justify-center mx-auto mb-4">
              <Smartphone size={40} className="text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">Add AmiFy</h2>
            <p className="text-[var(--text-muted)] text-sm">Get quick access from your home screen</p>
          </div>

          {/* Steps with visual guide */}
          <div className="space-y-4 mb-6">
            {/* Step 1 */}
            <div className="flex gap-3">
              <div className="w-10 h-10 rounded-full bg-brand-500/20 text-brand-500 flex items-center justify-center font-bold flex-shrink-0">
                1
              </div>
              <div className="pt-2">
                <p className="font-semibold text-white text-sm">Tap the Share button</p>
                <p className="text-xs text-[var(--text-muted)] mt-1">Look for the ⬆️ arrow at the bottom</p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex gap-3">
              <div className="w-10 h-10 rounded-full bg-brand-500/20 text-brand-500 flex items-center justify-center font-bold flex-shrink-0">
                2
              </div>
              <div className="pt-2">
                <p className="font-semibold text-white text-sm">Scroll and select "Add to Home Screen"</p>
                <p className="text-xs text-[var(--text-muted)] mt-1">Swipe through the options</p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex gap-3">
              <div className="w-10 h-10 rounded-full bg-brand-500/20 text-brand-500 flex items-center justify-center font-bold flex-shrink-0">
                3
              </div>
              <div className="pt-2">
                <p className="font-semibold text-white text-sm">Tap "Add" to confirm</p>
                <p className="text-xs text-[var(--text-muted)] mt-1">AmiFy will appear on your home screen</p>
              </div>
            </div>

            {/* Step 4 */}
            <div className="flex gap-3">
              <div className="w-10 h-10 rounded-full bg-brand-500/20 text-brand-500 flex items-center justify-center font-bold flex-shrink-0">
                ✓
              </div>
              <div className="pt-2">
                <p className="font-semibold text-white text-sm">Tap the icon to open AmiFy</p>
                <p className="text-xs text-[var(--text-muted)] mt-1">Works offline • Background audio</p>
              </div>
            </div>
          </div>

          {/* Benefits */}
          <div className="bg-[var(--bg)] rounded-2xl p-4 mb-6 space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-lg">🎧</span>
              <p className="text-sm text-white">Listen in the background</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-lg">📴</span>
              <p className="text-sm text-white">Works without internet</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-lg">⚡</span>
              <p className="text-sm text-white">Super fast access</p>
            </div>
          </div>

          {/* Action buttons */}
          <button
            onClick={handleDismiss}
            className="w-full py-3 rounded-xl bg-brand-600 text-white font-bold text-sm hover:bg-brand-700 transition mb-2"
          >
            Got It! ✓
          </button>
          <button
            onClick={handleDismiss}
            className="w-full py-2 rounded-xl bg-[var(--bg)] text-[var(--text-muted)] font-semibold text-sm hover:bg-[var(--border)] transition"
          >
            Maybe Later
          </button>
        </div>
      </div>
    );
  }

  // Fallback for other devices
  if (!isAndroid && !isIOS) {
    return (
      <div className="fixed top-0 left-0 right-0 z-[200] animate-in slide-in-from-top-2">
        <div className="bg-gradient-to-r from-brand-600 to-purple-600 text-white p-4 shadow-lg">
          <div className="max-w-xl mx-auto flex items-center gap-3">
            <div className="flex-shrink-0">
              <div className="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center animate-bounce">
                <Download size={24} className="text-white" />
              </div>
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-bold text-sm">📱 Get AmiFy on Your Device</p>
              <p className="text-xs opacity-90 mt-0.5">Works like a native app • Offline support • Background audio</p>
            </div>
            <button
              onClick={handleDismiss}
              className="p-2 rounded-lg hover:bg-white/20 transition flex-shrink-0"
            >
              <X size={20} />
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
}

