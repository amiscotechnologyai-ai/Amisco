"use client";

import { useEffect, useState } from "react";
import { X, TrendingUp, Wallet, Users, Heart, Play, Banknote } from "lucide-react";
import { useAuth } from "@/context/AuthContext";

interface Analytics {
  walletBalance: number;
  totalEarnedMinor: number;
  tipCount: number;
  followerCount: number;
  showCount: number;
  totalPlays: number;
  topEpisodes: { title: string; playCount: number }[];
  topStreams: { title: string; peakListeners: number; status: string }[];
  recentTips: {
    amountMinor: number;
    senderName: string;
    giftType?: string | null;
    createdAt: string;
  }[];
}

export default function AnalyticsDashboard({ onClose }: { onClose: () => void }) {
  const { token } = useAuth();
  const [data, setData] = useState<Analytics | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!token) return;
    fetch("/api/analytics", { headers: { Authorization: `Bearer ${token}` } })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => setData(d))
      .finally(() => setLoading(false));
  }, [token]);

  const money = (m: number) => `GHS ${(m / 100).toFixed(2)}`;

  return (
    <div className="fixed inset-0 z-[95] bg-[var(--bg)] overflow-y-auto">
      <div className="sticky top-0 backdrop-blur-xl bg-[var(--bg)]/80 border-b border-[var(--border)] px-5 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <TrendingUp className="text-brand-500" />
          <h1 className="text-xl font-black">Analytics Dashboard</h1>
        </div>
        <button onClick={onClose} className="p-2 rounded-full bg-[var(--bg-elevated)]">
          <X size={20} />
        </button>
      </div>

      <div className="p-5 space-y-6 pb-24">
        {loading ? (
          <p className="text-center text-[var(--text-muted)] py-12">Loading…</p>
        ) : !data ? (
          <p className="text-center text-[var(--text-muted)] py-12">
            No data available.
          </p>
        ) : (
          <>
            {/* Earnings highlight */}
            <div className="rounded-3xl p-6 bg-gradient-to-br from-brand-600 to-indigo-700 text-white">
              <div className="flex items-center gap-2 mb-1 opacity-90">
                <Wallet size={18} /> <span className="text-sm font-semibold">Wallet Balance</span>
              </div>
              <p className="text-4xl font-black">{money(data.walletBalance)}</p>
              <div className="flex gap-6 mt-4 text-sm">
                <div>
                  <p className="opacity-80">Total earned</p>
                  <p className="font-bold">{money(data.totalEarnedMinor)}</p>
                </div>
                <div>
                  <p className="opacity-80">Tips received</p>
                  <p className="font-bold">{data.tipCount}</p>
                </div>
              </div>
            </div>

            {/* Stat grid */}
            <div className="grid grid-cols-2 gap-3">
              <Stat icon={Users} label="Followers" value={data.followerCount.toLocaleString()} />
              <Stat icon={Play} label="Total Plays" value={data.totalPlays.toLocaleString()} />
              <Stat icon={Heart} label="Tips" value={data.tipCount.toLocaleString()} />
              <Stat icon={TrendingUp} label="Shows" value={data.showCount.toLocaleString()} />
            </div>

            {/* Top episodes */}
            {data.topEpisodes.length > 0 && (
              <Section title="Top Episodes">
                {data.topEpisodes.map((e, i) => (
                  <Row key={i} left={e.title} right={`${e.playCount.toLocaleString()} plays`} rank={i + 1} />
                ))}
              </Section>
            )}

            {/* Top streams */}
            {data.topStreams.length > 0 && (
              <Section title="Top Live Streams">
                {data.topStreams.map((s, i) => (
                  <Row
                    key={i}
                    left={s.title}
                    right={`${s.peakListeners.toLocaleString()} peak`}
                    rank={i + 1}
                  />
                ))}
              </Section>
            )}

            {/* Recent tips */}
            {data.recentTips.length > 0 && (
              <Section title="Recent Tips">
                {data.recentTips.map((t, i) => (
                  <Row
                    key={i}
                    left={`${t.senderName} ${t.giftType ? `· ${t.giftType}` : ""}`}
                    right={money(t.amountMinor)}
                  />
                ))}
              </Section>
            )}

            {/* Payout */}
            <button className="w-full p-4 rounded-2xl bg-[var(--bg-elevated)] border border-[var(--border)] flex items-center justify-center gap-2 font-bold">
              <Banknote size={18} className="text-green-500" />
              Withdraw to Mobile Money
            </button>
          </>
        )}
      </div>
    </div>
  );
}

function Stat({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Users;
  label: string;
  value: string;
}) {
  return (
    <div className="p-4 rounded-2xl bg-[var(--bg-elevated)]">
      <Icon size={18} className="text-brand-500 mb-2" />
      <p className="text-2xl font-black">{value}</p>
      <p className="text-xs text-[var(--text-muted)]">{label}</p>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="font-black text-lg mb-3">{title}</h3>
      <div className="space-y-2">{children}</div>
    </div>
  );
}

function Row({
  left,
  right,
  rank,
}: {
  left: string;
  right: string;
  rank?: number;
}) {
  return (
    <div className="flex items-center gap-3 p-3 rounded-xl bg-[var(--bg-elevated)]">
      {rank && (
        <span className="w-6 h-6 rounded-full bg-brand-500/20 text-brand-500 text-xs font-bold flex items-center justify-center shrink-0">
          {rank}
        </span>
      )}
      <span className="flex-1 truncate text-sm font-medium">{left}</span>
      <span className="text-sm text-[var(--text-muted)] shrink-0">{right}</span>
    </div>
  );
}
