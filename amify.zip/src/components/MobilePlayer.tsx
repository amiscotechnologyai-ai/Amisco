// components/MobilePlayer.tsx
// Mini player for mobile, shows when audio is playing

'use client';

import { useState, useEffect, useRef } from 'react';
import { Play, Pause, Volume2, VolumeX, ChevronUp, X } from 'lucide-react';
import { bgAudio } from '@/lib/backgroundAudio';

interface MobilePlayerProps {
  streamTitle?: string;
  creatorName?: string;
  creatorColor?: string;
  onExpandClick?: () => void;
}

export function MobilePlayer({
  streamTitle = 'Live Stream',
  creatorName = 'Creator',
  creatorColor = '#7c3aed',
  onExpandClick,
}: MobilePlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const [isVisible, setIsVisible] = useState(false);
  const [isMinimized, setIsMinimized] = useState(true);

  useEffect(() => {
    // Subscribe to background audio state changes
    const unsubPlay = bgAudio.on('play', () => {
      setIsPlaying(true);
      setIsVisible(true);
    });

    const unsubPause = bgAudio.on('pause', () => {
      setIsPlaying(false);
    });

    const unsubStop = bgAudio.on('stop', () => {
      setIsVisible(false);
      setIsMinimized(true);
    });

    const unsubMuted = bgAudio.on('muted', (muted: boolean) => {
      setIsMuted(muted);
    });

    const unsubVolume = bgAudio.on('volume', (vol: number) => {
      setVolume(vol);
    });

    const unsubForeground = bgAudio.on('foreground', () => {
      // App came to foreground, update UI
      const state = bgAudio.getState();
      setIsPlaying(state.isPlaying);
      setIsMuted(state.isMuted);
      setVolume(state.volume);
    });

    return () => {
      unsubPlay();
      unsubPause();
      unsubStop();
      unsubMuted();
      unsubVolume();
      unsubForeground();
    };
  }, []);

  const handlePlayPause = () => {
    if (isPlaying) {
      bgAudio.pause();
    } else {
      bgAudio.resume();
    }
  };

  const handleMute = () => {
    bgAudio.setMuted(!isMuted);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVolume = parseFloat(e.target.value);
    bgAudio.setVolume(newVolume);
  };

  const handleClose = () => {
    bgAudio.stop();
    setIsVisible(false);
  };

  const handleExpand = () => {
    setIsMinimized(false);
    onExpandClick?.();
  };

  if (!isVisible) {
    return null;
  }

  // Minimized state: compact bar at bottom
  if (isMinimized) {
    return (
      <div
        className="fixed bottom-0 left-0 right-0 z-[100] bg-[var(--bg-elevated)] border-t border-[var(--border)] p-3"
        onClick={handleExpand}
      >
        <div className="flex items-center gap-3 cursor-pointer">
          <div
            className="w-12 h-12 rounded-lg flex-shrink-0"
            style={{ backgroundColor: creatorColor }}
          >
            <div className="w-full h-full flex items-center justify-center">
              {isPlaying ? (
                <div className="flex gap-1">
                  <div className="w-1 h-2 bg-white rounded-full animate-pulse"></div>
                  <div className="w-1 h-4 bg-white rounded-full animate-pulse" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-1 h-3 bg-white rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                </div>
              ) : (
                <Pause size={20} className="text-white" />
              )}
            </div>
          </div>

          <div className="flex-1 min-w-0">
            <p className="font-semibold text-sm text-white truncate">{streamTitle}</p>
            <p className="text-xs text-[var(--text-muted)] truncate">by {creatorName}</p>
          </div>

          <button
            onClick={(e) => {
              e.stopPropagation();
              handlePlayPause();
            }}
            className="p-2 rounded-full hover:bg-[var(--bg)] transition"
          >
            {isPlaying ? <Pause size={20} /> : <Play size={20} />}
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              handleExpand();
            }}
            className="p-2 rounded-full hover:bg-[var(--bg)] transition text-brand-500"
          >
            <ChevronUp size={20} />
          </button>
        </div>
      </div>
    );
  }

  // Expanded state: full controls
  return (
    <div className="fixed inset-0 z-[150] bg-black/50 backdrop-blur-sm flex items-end">
      <div className="w-full bg-[var(--bg-elevated)] rounded-t-3xl p-6 max-h-[80vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => setIsMinimized(true)}
            className="p-2 rounded-full hover:bg-[var(--bg)] transition"
          >
            <ChevronUp size={24} className="text-brand-500" />
          </button>
          <h2 className="text-lg font-bold text-white flex-1 text-center truncate px-4">
            Now Playing
          </h2>
          <button
            onClick={handleClose}
            className="p-2 rounded-full hover:bg-[var(--bg)] transition text-[var(--text-muted)]"
          >
            <X size={24} />
          </button>
        </div>

        {/* Album Art */}
        <div
          className="w-full aspect-square rounded-2xl mb-6 flex items-center justify-center text-white text-6xl"
          style={{ backgroundColor: creatorColor }}
        >
          🎙️
        </div>

        {/* Stream Info */}
        <div className="text-center mb-8">
          <h3 className="text-2xl font-bold text-white mb-2">{streamTitle}</h3>
          <p className="text-[var(--text-muted)]">{creatorName}</p>
        </div>

        {/* Controls */}
        <div className="flex items-center justify-center gap-6 mb-8">
          {/* Mute button */}
          <button
            onClick={handleMute}
            className="p-3 rounded-full bg-[var(--bg)] hover:bg-[var(--border)] transition"
          >
            {isMuted ? <VolumeX size={24} /> : <Volume2 size={24} />}
          </button>

          {/* Play/Pause */}
          <button
            onClick={handlePlayPause}
            className="p-5 rounded-full bg-brand-600 hover:bg-brand-700 transition text-white"
          >
            {isPlaying ? <Pause size={32} /> : <Play size={32} />}
          </button>

          {/* Volume slider (placeholder) */}
          <div className="w-12 h-12 rounded-full bg-[var(--bg)] flex items-center justify-center opacity-50">
            🔊
          </div>
        </div>

        {/* Volume slider */}
        <div className="flex items-center gap-3 mb-8">
          <VolumeX size={18} className="text-[var(--text-muted)]" />
          <input
            type="range"
            min="0"
            max="1"
            step="0.1"
            value={volume}
            onChange={handleVolumeChange}
            className="flex-1"
          />
          <Volume2 size={18} className="text-brand-500" />
        </div>

        {/* Status info */}
        <div className="text-center text-sm text-[var(--text-muted)]">
          {isPlaying ? (
            <>
              <p className="mb-2">🎧 Playing in background</p>
              <p className="text-xs">Audio continues when you close this window</p>
            </>
          ) : (
            <p>Paused</p>
          )}
        </div>
      </div>
    </div>
  );
}
