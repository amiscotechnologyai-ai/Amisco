"use client";

import { useState, useRef, useEffect } from "react";
import {
  Sun,
  Moon,
  Zap,
  Home,
  Search,
  Library,
  User,
  Radio,
} from "lucide-react";
import { useTheme } from "@/context/ThemeContext";
import { useAuth } from "@/context/AuthContext";

export type Page = "home" | "live" | "search" | "library" | "profile";

interface ShellProps {
  current: Page;
  onNavigate: (p: Page) => void;
  children: React.ReactNode;
}

export default function AppShell({ current, onNavigate, children }: ShellProps) {
  const { theme, toggleTheme } = useTheme();
  const { user } = useAuth();
  const [showNotif, setShowNotif] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setShowNotif(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const navItems: { id: Page; label: string; icon: typeof Home }[] = [
    { id: "home", label: "Home", icon: Home },
    { id: "live", label: "Live", icon: Radio },
    { id: "search", label: "Search", icon: Search },
    { id: "library", label: "Library", icon: Library },
    { id: "profile", label: "Profile", icon: User },
  ];

  return (
    <div className="min-h-screen bg-[var(--bg)] text-[var(--text)]">
      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-xl bg-[var(--bg)]/80 border-b border-[var(--border)]">
        <div className="max-w-5xl mx-auto px-4 md:px-6 py-3 flex items-center justify-between">
          <button
            onClick={() => onNavigate("home")}
            className="flex items-center gap-3"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center text-white font-black text-xl shadow-lg">
              A
            </div>
            <div className="text-left">
              <h1 className="font-black text-lg leading-none tracking-tight">
                AmiFy
              </h1>
              <p className="text-[10px] text-[var(--text-muted)] tracking-wide">
                Amplify your voice
              </p>
            </div>
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={toggleTheme}
              aria-label="Toggle theme"
              className="p-2.5 rounded-full bg-[var(--bg-elevated)] hover:opacity-80 transition"
            >
              {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
            </button>

            <div className="relative" ref={notifRef}>
              <button
                onClick={() => setShowNotif((s) => !s)}
                aria-label="Notifications"
                className="p-2.5 rounded-full bg-[var(--bg-elevated)] hover:opacity-80 transition relative"
              >
                <Zap size={18} />
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full" />
              </button>
              {showNotif && (
                <div className="absolute right-0 mt-2 w-72 rounded-2xl shadow-2xl overflow-hidden bg-[var(--bg-elevated)] border border-[var(--border)] z-50">
                  <div className="p-3 border-b border-[var(--border)] font-bold text-sm">
                    Notifications
                  </div>
                  <div className="p-6 text-center text-sm text-[var(--text-muted)]">
                    You&apos;re all caught up.
                  </div>
                </div>
              )}
            </div>

            {user && (
              <div
                className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold text-sm"
                style={{ backgroundColor: user.avatarColor }}
              >
                {user.displayName.slice(0, 2).toUpperCase()}
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Content */}
      <main className="max-w-5xl mx-auto pb-28">{children}</main>

      {/* Bottom nav */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 backdrop-blur-xl bg-[var(--bg)]/90 border-t border-[var(--border)]">
        <div className="max-w-5xl mx-auto flex items-center justify-around px-2">
          {navItems.map(({ id, label, icon: Icon }) => {
            const active = current === id;
            return (
              <button
                key={id}
                onClick={() => onNavigate(id)}
                className={`flex-1 py-3 flex flex-col items-center gap-1 transition ${
                  active
                    ? "text-brand-500"
                    : "text-[var(--text-muted)] hover:text-[var(--text)]"
                }`}
              >
                <Icon size={22} strokeWidth={active ? 2.5 : 2} />
                <span className="text-[10px] font-semibold">{label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
