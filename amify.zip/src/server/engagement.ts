import { prisma } from "../lib/prisma";
import type { PollDTO, QuestionDTO, SpeakerDTO } from "../types";

export async function buildPollDTO(pollId: string): Promise<PollDTO | null> {
  const poll = await prisma.poll.findUnique({
    where: { id: pollId },
    include: { options: { include: { _count: { select: { votes: true } } } } },
  });
  if (!poll) return null;
  const options = poll.options.map((o) => ({
    id: o.id,
    label: o.label,
    votes: o._count.votes,
  }));
  return {
    id: poll.id,
    streamId: poll.streamId,
    question: poll.question,
    closed: poll.closed,
    options,
    totalVotes: options.reduce((a, o) => a + o.votes, 0),
  };
}

export async function buildQuestionDTO(
  questionId: string
): Promise<QuestionDTO | null> {
  const q = await prisma.question.findUnique({
    where: { id: questionId },
    include: { user: { select: { displayName: true } } },
  });
  if (!q) return null;
  return {
    id: q.id,
    streamId: q.streamId,
    userId: q.userId,
    username: q.user.displayName,
    content: q.content,
    answered: q.answered,
    voteCount: q.voteCount,
    createdAt: q.createdAt.toISOString(),
  };
}

export async function buildStageDTO(streamId: string): Promise<SpeakerDTO[]> {
  const speakers = await prisma.speaker.findMany({
    where: { streamId, role: { not: "LISTENER" } },
    include: { user: { select: { displayName: true, avatarColor: true } } },
    orderBy: { joinedAt: "asc" },
  });
  return speakers.map((s) => ({
    userId: s.userId,
    username: s.user.displayName,
    avatarColor: s.user.avatarColor,
    role: s.role as SpeakerDTO["role"],
    handRaised: s.handRaised,
    muted: s.muted,
  }));
}
