import type { Server as HTTPServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { prisma } from "../lib/prisma";
import { verifyToken } from "../lib/auth";
import { buildPollDTO, buildQuestionDTO, buildStageDTO } from "./engagement";
import { setIO } from "../lib/realtime";
import {
  parseBannedWords,
  findBannedWord,
  checkSlowMode,
  clearSlowMode,
  aiFlagsMessage,
} from "../lib/moderation";
import type {
  ServerToClientEvents,
  ClientToServerEvents,
} from "../types";

/**
 * In-memory presence tracker.
 * Maps streamId -> Set of socket ids currently listening.
 * This gives us accurate, real-time listener counts that reflect
 * actual connected clients (no mock numbers).
 */
const presence = new Map<string, Set<string>>();

// In-memory moderation state: streamId -> sets of userIds.
const mutedUsers = new Map<string, Set<string>>();
const bannedUsers = new Map<string, Set<string>>();

function isMuted(streamId: string, userId: string): boolean {
  return mutedUsers.get(streamId)?.has(userId) ?? false;
}
function isBanned(streamId: string, userId: string): boolean {
  return bannedUsers.get(streamId)?.has(userId) ?? false;
}
function setUserFlag(map: Map<string, Set<string>>, streamId: string, userId: string, on: boolean) {
  let set = map.get(streamId);
  if (!set) {
    set = new Set();
    map.set(streamId, set);
  }
  if (on) set.add(userId);
  else set.delete(userId);
}

/** Confirm the requester is the stream host or a co-host speaker. */
async function isStreamModerator(streamId: string, userId: string): Promise<boolean> {
  const stream = await prisma.stream.findUnique({ where: { id: streamId } });
  if (!stream) return false;
  if (stream.hostId === userId) return true;
  const speaker = await prisma.speaker.findFirst({
    where: { streamId, userId, role: { in: ["HOST", "COHOST"] } },
  });
  return !!speaker;
}

async function emitModState(
  io: SocketIOServer,
  streamId: string,
  slowModeSec?: number,
  bannedWords?: string
) {
  let sm = slowModeSec;
  let bw = bannedWords;
  if (sm === undefined || bw === undefined) {
    const stream = await prisma.stream.findUnique({ where: { id: streamId } });
    if (sm === undefined) sm = stream?.slowModeSec ?? 0;
    if (bw === undefined) bw = stream?.bannedWords ?? "";
  }
  io.to(streamId).emit("mod:state", {
    streamId,
    slowModeSec: sm,
    bannedWords: bw,
    mutedUserIds: Array.from(mutedUsers.get(streamId) ?? []),
    bannedUserIds: Array.from(bannedUsers.get(streamId) ?? []),
  });
}

function getListenerCount(streamId: string): number {
  return presence.get(streamId)?.size ?? 0;
}

async function persistListenerCount(streamId: string, count: number) {
  try {
    const stream = await prisma.stream.findUnique({ where: { id: streamId } });
    if (!stream) return;
    await prisma.stream.update({
      where: { id: streamId },
      data: {
        listenerCount: count,
        peakListeners: Math.max(stream.peakListeners, count),
      },
    });
  } catch (err) {
    console.error("[socket] persistListenerCount error:", err);
  }
}

async function broadcastGlobalCount(io: SocketIOServer) {
  let totalListeners = 0;
  for (const set of presence.values()) totalListeners += set.size;
  const liveStreams = await prisma.stream.count({ where: { status: "LIVE" } });
  io.emit("global:liveCount", { totalListeners, liveStreams });
}

export function initSocketServer(httpServer: HTTPServer): SocketIOServer {
  const io = new SocketIOServer<ClientToServerEvents, ServerToClientEvents>(
    httpServer,
    {
      cors: { origin: "*", methods: ["GET", "POST"] },
      path: "/api/socket",
    }
  );

  setIO(io);

  io.on("connection", (socket) => {
    console.log(`[socket] connected: ${socket.id}`);

    // Listener joins a live stream room
    socket.on("stream:join", async (streamId) => {
      socket.join(streamId);
      if (!presence.has(streamId)) presence.set(streamId, new Set());
      presence.get(streamId)!.add(socket.id);

      // Track listener session for analytics
      if (socket.data.userId) {
        try {
          await prisma.listenerSession.create({
            data: {
              userId: socket.data.userId,
              streamId,
            },
          });
        } catch (err) {
          console.error("[socket] session create error:", err);
        }
      }

      const count = getListenerCount(streamId);
      io.to(streamId).emit("stream:listeners", { streamId, count });
      await persistListenerCount(streamId, count);
      await broadcastGlobalCount(io);
    });

    // Listener leaves a stream room
    socket.on("stream:leave", async (streamId) => {
      socket.leave(streamId);
      presence.get(streamId)?.delete(socket.id);

      // Update listener session (mark leftAt and calculate duration)
      if (socket.data.userId) {
        try {
          const session = await prisma.listenerSession.findFirst({
            where: {
              userId: socket.data.userId,
              streamId,
              leftAt: null,
            },
            orderBy: { joinedAt: "desc" },
          });
          if (session) {
            const now = new Date();
            const durationSec = Math.floor((now.getTime() - session.joinedAt.getTime()) / 1000);
            await prisma.listenerSession.update({
              where: { id: session.id },
              data: { leftAt: now, durationSec },
            });
          }
        } catch (err) {
          console.error("[socket] session update error:", err);
        }
      }

      const count = getListenerCount(streamId);
      io.to(streamId).emit("stream:listeners", { streamId, count });
      await persistListenerCount(streamId, count);
      await broadcastGlobalCount(io);
    });

    // Real-time chat in a live stream
    socket.on("chat:send", async ({ streamId, content, token }) => {
      const payload = verifyToken(token);
      if (!payload) return;
      if (!content?.trim()) return;

      try {
        const user = await prisma.user.findUnique({
          where: { id: payload.userId },
        });
        if (!user) return;

        // Banned from this room -> silently reject with reason
        if (isBanned(streamId, user.id)) {
          socket.emit("chat:rejected", { streamId, reason: "You are banned from this room" });
          return;
        }
        // Muted -> reject
        if (isMuted(streamId, user.id)) {
          socket.emit("chat:rejected", { streamId, reason: "You are muted" });
          return;
        }

        const stream = await prisma.stream.findUnique({ where: { id: streamId } });
        if (!stream) return;

        // Slow mode (hosts/co-hosts bypass)
        const moderator = stream.hostId === user.id;
        if (!moderator && stream.slowModeSec > 0) {
          const cooldown = checkSlowMode(streamId, user.id, stream.slowModeSec);
          if (cooldown > 0) {
            socket.emit("chat:rejected", { streamId, reason: "Slow mode is on", cooldownSec: cooldown });
            return;
          }
        }

        // Banned words
        const extra = parseBannedWords(stream.bannedWords);
        const hit = findBannedWord(content, extra);
        if (hit) {
          socket.emit("chat:rejected", { streamId, reason: "Message blocked by moderation" });
          return;
        }

        // Optional AI moderation (no-op without OPENAI_API_KEY)
        if (await aiFlagsMessage(content)) {
          socket.emit("chat:rejected", { streamId, reason: "Message flagged by moderation" });
          return;
        }

        const saved = await prisma.chatMessage.create({
          data: {
            content: content.slice(0, 500),
            streamId,
            userId: user.id,
          },
        });

        io.to(streamId).emit("chat:message", {
          id: saved.id,
          content: saved.content,
          streamId,
          userId: user.id,
          username: user.displayName,
          avatarColor: user.avatarColor,
          createdAt: saved.createdAt.toISOString(),
        });
      } catch (err) {
        console.error("[socket] chat:send error:", err);
      }
    });

    // Host starts broadcasting
    socket.on("stream:goLive", async ({ streamId, token }) => {
      const payload = verifyToken(token);
      if (!payload) return;
      try {
        const stream = await prisma.stream.findUnique({
          where: { id: streamId },
        });
        if (!stream || stream.hostId !== payload.userId) return;

        await prisma.stream.update({
          where: { id: streamId },
          data: { status: "LIVE", startedAt: new Date() },
        });
        io.emit("stream:status", { streamId, status: "LIVE" });
        await broadcastGlobalCount(io);
      } catch (err) {
        console.error("[socket] stream:goLive error:", err);
      }
    });

    // Host ends broadcast
    socket.on("stream:end", async ({ streamId, token }) => {
      const payload = verifyToken(token);
      if (!payload) return;
      try {
        const stream = await prisma.stream.findUnique({
          where: { id: streamId },
        });
        if (!stream || stream.hostId !== payload.userId) return;

        await prisma.stream.update({
          where: { id: streamId },
          data: { status: "ENDED", endedAt: new Date() },
        });
        io.emit("stream:status", { streamId, status: "ENDED" });
        presence.delete(streamId);
        mutedUsers.delete(streamId);
        bannedUsers.delete(streamId);
        clearSlowMode(streamId);
        await broadcastGlobalCount(io);
      } catch (err) {
        console.error("[socket] stream:end error:", err);
      }
    });

    // Host pins / unpins a chat message
    socket.on("chat:pin", async ({ streamId, messageId, token }) => {
      const payload = verifyToken(token);
      if (!payload) return;
      try {
        const stream = await prisma.stream.findUnique({ where: { id: streamId } });
        if (!stream || stream.hostId !== payload.userId) return;
        await prisma.stream.update({
          where: { id: streamId },
          data: { pinnedMsgId: messageId },
        });
        let message = null;
        if (messageId) {
          const m = await prisma.chatMessage.findUnique({
            where: { id: messageId },
            include: { user: { select: { displayName: true, avatarColor: true } } },
          });
          if (m)
            message = {
              id: m.id,
              content: m.content,
              streamId,
              userId: m.userId,
              username: m.user.displayName,
              avatarColor: m.user.avatarColor,
              createdAt: m.createdAt.toISOString(),
            };
        }
        io.to(streamId).emit("chat:pinned", { streamId, message });
      } catch (err) {
        console.error("[socket] chat:pin error:", err);
      }
    });

    // ---- POLLS ----
    socket.on("poll:create", async ({ streamId, question, options, token }) => {
      const payload = verifyToken(token);
      if (!payload || !question?.trim() || options.length < 2) return;
      try {
        const stream = await prisma.stream.findUnique({ where: { id: streamId } });
        if (!stream || stream.hostId !== payload.userId) return;
        const poll = await prisma.poll.create({
          data: {
            streamId,
            question: question.slice(0, 200),
            options: {
              create: options.slice(0, 6).map((label) => ({ label: label.slice(0, 80) })),
            },
          },
        });
        const dto = await buildPollDTO(poll.id);
        if (dto) io.to(streamId).emit("poll:new", dto);
      } catch (err) {
        console.error("[socket] poll:create error:", err);
      }
    });

    socket.on("poll:vote", async ({ pollId, optionId, token }) => {
      const payload = verifyToken(token);
      if (!payload) return;
      try {
        const poll = await prisma.poll.findUnique({ where: { id: pollId } });
        if (!poll || poll.closed) return;
        await prisma.pollVote.upsert({
          where: { userId_pollId: { userId: payload.userId, pollId } },
          update: { optionId },
          create: { userId: payload.userId, pollId, optionId },
        });
        const dto = await buildPollDTO(pollId);
        if (dto) io.to(poll.streamId).emit("poll:update", dto);
      } catch (err) {
        console.error("[socket] poll:vote error:", err);
      }
    });

    socket.on("poll:close", async ({ pollId, token }) => {
      const payload = verifyToken(token);
      if (!payload) return;
      try {
        const poll = await prisma.poll.findUnique({ where: { id: pollId } });
        if (!poll) return;
        const stream = await prisma.stream.findUnique({ where: { id: poll.streamId } });
        if (!stream || stream.hostId !== payload.userId) return;
        await prisma.poll.update({ where: { id: pollId }, data: { closed: true } });
        const dto = await buildPollDTO(pollId);
        if (dto) io.to(poll.streamId).emit("poll:update", dto);
      } catch (err) {
        console.error("[socket] poll:close error:", err);
      }
    });

    // ---- Q&A ----
    socket.on("question:ask", async ({ streamId, content, token }) => {
      const payload = verifyToken(token);
      if (!payload || !content?.trim()) return;
      try {
        const q = await prisma.question.create({
          data: { streamId, userId: payload.userId, content: content.slice(0, 300) },
        });
        const dto = await buildQuestionDTO(q.id);
        if (dto) io.to(streamId).emit("question:new", dto);
      } catch (err) {
        console.error("[socket] question:ask error:", err);
      }
    });

    socket.on("question:upvote", async ({ questionId, token }) => {
      const payload = verifyToken(token);
      if (!payload) return;
      try {
        const existing = await prisma.questionVote.findUnique({
          where: { questionId_userId: { questionId, userId: payload.userId } },
        });
        if (existing) return; // one vote per user
        await prisma.questionVote.create({
          data: { questionId, userId: payload.userId },
        });
        const q = await prisma.question.update({
          where: { id: questionId },
          data: { voteCount: { increment: 1 } },
        });
        const dto = await buildQuestionDTO(questionId);
        if (dto) io.to(q.streamId).emit("question:update", dto);
      } catch (err) {
        console.error("[socket] question:upvote error:", err);
      }
    });

    socket.on("question:answer", async ({ questionId, token }) => {
      const payload = verifyToken(token);
      if (!payload) return;
      try {
        const q = await prisma.question.findUnique({ where: { id: questionId } });
        if (!q) return;
        const stream = await prisma.stream.findUnique({ where: { id: q.streamId } });
        if (!stream || stream.hostId !== payload.userId) return;
        await prisma.question.update({
          where: { id: questionId },
          data: { answered: true },
        });
        const dto = await buildQuestionDTO(questionId);
        if (dto) io.to(q.streamId).emit("question:update", dto);
      } catch (err) {
        console.error("[socket] question:answer error:", err);
      }
    });

    // ---- REACTIONS (lightweight, fire-and-forget) ----
    socket.on("reaction:send", async ({ streamId, emoji, token }) => {
      const payload = verifyToken(token);
      if (!payload || !emoji) return;
      // broadcast immediately for snappy UX
      io.to(streamId).emit("reaction:burst", { streamId, emoji, userId: payload.userId });
      // persist async (best-effort)
      prisma.reaction
        .create({ data: { streamId, userId: payload.userId, emoji } })
        .catch(() => {});
    });

    // ---- STAGE (multi-speaker audio) ----
    socket.on("stage:raiseHand", async ({ streamId, token }) => {
      const payload = verifyToken(token);
      if (!payload) return;
      try {
        const user = await prisma.user.findUnique({ where: { id: payload.userId } });
        if (!user) return;
        await prisma.speaker.upsert({
          where: { streamId_userId: { streamId, userId: payload.userId } },
          update: { handRaised: true },
          create: { streamId, userId: payload.userId, role: "LISTENER", handRaised: true },
        });
        io.to(streamId).emit("stage:handRaised", {
          streamId,
          userId: payload.userId,
          username: user.displayName,
        });
        io.to(streamId).emit("stage:update", {
          streamId,
          speakers: await buildStageDTO(streamId),
        });
      } catch (err) {
        console.error("[socket] stage:raiseHand error:", err);
      }
    });

    socket.on("stage:invite", async ({ streamId, userId, token }) => {
      const payload = verifyToken(token);
      if (!payload) return;
      try {
        const stream = await prisma.stream.findUnique({ where: { id: streamId } });
        if (!stream || stream.hostId !== payload.userId) return;
        await prisma.speaker.upsert({
          where: { streamId_userId: { streamId, userId } },
          update: { role: "SPEAKER", handRaised: false, muted: false },
          create: { streamId, userId, role: "SPEAKER", handRaised: false, muted: false },
        });
        io.to(streamId).emit("stage:update", {
          streamId,
          speakers: await buildStageDTO(streamId),
        });
      } catch (err) {
        console.error("[socket] stage:invite error:", err);
      }
    });

    socket.on("stage:setMute", async ({ streamId, muted, token }) => {
      const payload = verifyToken(token);
      if (!payload) return;
      try {
        await prisma.speaker.updateMany({
          where: { streamId, userId: payload.userId },
          data: { muted },
        });
        io.to(streamId).emit("stage:update", {
          streamId,
          speakers: await buildStageDTO(streamId),
        });
      } catch (err) {
        console.error("[socket] stage:setMute error:", err);
      }
    });

    socket.on("stage:leave", async ({ streamId, token }) => {
      const payload = verifyToken(token);
      if (!payload) return;
      try {
        await prisma.speaker.deleteMany({
          where: { streamId, userId: payload.userId },
        });
        io.to(streamId).emit("stage:update", {
          streamId,
          speakers: await buildStageDTO(streamId),
        });
      } catch (err) {
        console.error("[socket] stage:leave error:", err);
      }
    });

    // ---- Tip goals (host) ----
    socket.on("tipGoal:create", async ({ streamId, title, targetMinor, token }) => {
      const payload = verifyToken(token);
      if (!payload) return;
      try {
        if (!(await isStreamModerator(streamId, payload.userId))) return;
        // Only one active goal per stream — deactivate previous ones.
        await prisma.tipGoal.updateMany({ where: { streamId, active: true }, data: { active: false } });
        const goal = await prisma.tipGoal.create({
          data: { streamId, title: title.slice(0, 120), targetMinor: Math.max(1, targetMinor) },
        });
        io.to(streamId).emit("tipGoal:update", {
          id: goal.id,
          streamId,
          title: goal.title,
          targetMinor: goal.targetMinor,
          currentMinor: goal.currentMinor,
          currency: goal.currency,
          reached: goal.reached,
          active: goal.active,
        });
      } catch (err) {
        console.error("[socket] tipGoal:create error:", err);
      }
    });

    // ---- Moderation (host / co-host) ----
    socket.on("mod:setSlowMode", async ({ streamId, seconds, token }) => {
      const payload = verifyToken(token);
      if (!payload) return;
      try {
        if (!(await isStreamModerator(streamId, payload.userId))) return;
        const s = Math.max(0, Math.min(300, Math.floor(seconds)));
        await prisma.stream.update({ where: { id: streamId }, data: { slowModeSec: s } });
        emitModState(io, streamId, s, undefined);
      } catch (err) {
        console.error("[socket] mod:setSlowMode error:", err);
      }
    });

    socket.on("mod:setBannedWords", async ({ streamId, words, token }) => {
      const payload = verifyToken(token);
      if (!payload) return;
      try {
        if (!(await isStreamModerator(streamId, payload.userId))) return;
        const cleaned = words.slice(0, 1000);
        await prisma.stream.update({ where: { id: streamId }, data: { bannedWords: cleaned } });
        emitModState(io, streamId, undefined, cleaned);
      } catch (err) {
        console.error("[socket] mod:setBannedWords error:", err);
      }
    });

    socket.on("mod:mute", async ({ streamId, userId, muted, token }) => {
      const payload = verifyToken(token);
      if (!payload) return;
      try {
        if (!(await isStreamModerator(streamId, payload.userId))) return;
        setUserFlag(mutedUsers, streamId, userId, muted);
        await prisma.moderationAction.create({
          data: { streamId, moderatorId: payload.userId, targetId: userId, type: muted ? "MUTE" : "UNMUTE" },
        });
        io.to(streamId).emit("mod:muted", { streamId, userId, muted });
      } catch (err) {
        console.error("[socket] mod:mute error:", err);
      }
    });

    socket.on("mod:kick", async ({ streamId, userId, token }) => {
      const payload = verifyToken(token);
      if (!payload) return;
      try {
        if (!(await isStreamModerator(streamId, payload.userId))) return;
        await prisma.moderationAction.create({
          data: { streamId, moderatorId: payload.userId, targetId: userId, type: "KICK" },
        });
        // Remove from stage if present
        await prisma.speaker.deleteMany({ where: { streamId, userId } });
        io.to(streamId).emit("mod:kicked", { streamId, userId });
      } catch (err) {
        console.error("[socket] mod:kick error:", err);
      }
    });

    socket.on("mod:ban", async ({ streamId, userId, banned, token }) => {
      const payload = verifyToken(token);
      if (!payload) return;
      try {
        if (!(await isStreamModerator(streamId, payload.userId))) return;
        setUserFlag(bannedUsers, streamId, userId, banned);
        await prisma.moderationAction.create({
          data: { streamId, moderatorId: payload.userId, targetId: userId, type: banned ? "BAN" : "UNBAN" },
        });
        if (banned) await prisma.speaker.deleteMany({ where: { streamId, userId } });
        io.to(streamId).emit("mod:banned", { streamId, userId, banned });
      } catch (err) {
        console.error("[socket] mod:ban error:", err);
      }
    });

    // Cleanup presence on disconnect
    socket.on("disconnect", async () => {
      console.log(`[socket] disconnected: ${socket.id}`);
      for (const [streamId, set] of presence.entries()) {
        if (set.delete(socket.id)) {
          const count = getListenerCount(streamId);
          io.to(streamId).emit("stream:listeners", { streamId, count });
          await persistListenerCount(streamId, count);
        }
      }
      await broadcastGlobalCount(io);
    });
  });

  return io;
}
