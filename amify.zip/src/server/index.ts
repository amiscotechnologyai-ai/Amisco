import { createServer } from "http";
import next from "next";
import { parse } from "url";
import { initSocketServer } from "./socket";

const dev = process.env.NODE_ENV !== "production";
const hostname = process.env.HOSTNAME || "0.0.0.0";
const port = parseInt(process.env.PORT || "3000", 10);

const app = next({ dev, hostname, port });
const handle = app.getRequestHandler();

app.prepare().then(() => {
  const server = createServer((req, res) => {
    try {
      const parsedUrl = parse(req.url || "", true);
      handle(req, res, parsedUrl);
    } catch (err) {
      console.error("Error handling request:", err);
      res.statusCode = 500;
      res.end("Internal Server Error");
    }
  });

  // Attach Socket.IO to the same HTTP server
  initSocketServer(server);

  server.listen(port, () => {
    console.log(`
  ╔══════════════════════════════════════════╗
  ║                                            ║
  ║     🎙️  AmiFy — Amplify your voice         ║
  ║     Amisco Technology (AmiTech)            ║
  ║                                            ║
  ║     ▶ http://${hostname}:${port}              ║
  ║     ▶ Socket.IO live on /api/socket        ║
  ║     ▶ Mode: ${dev ? "development" : "production "}                  ║
  ║                                            ║
  ╚══════════════════════════════════════════╝
    `);
  });
});
