// Shared application types

export type PlanType = "FREE" | "PREMIUM" | "CREATOR_PRO";
export type StreamStatus = "SCHEDULED" | "LIVE" | "ENDED";
export type AudioQuality = "LOW" | "STANDARD" | "HIGH" | "LOSSLESS";

export interface PublicUser {
  id: string;
  email: string;
  username: string;
  displayName: string;
  bio?: string | null;
  avatarColor: string;
  plan: PlanType;
  isCreator: boolean;
  followersCount?: number;
  followingCount?: number;
  savedCount?: number;
  playedCount?: number;
  theme: string;
}

export interface StreamDTO {
  id: string;
  title: string;
  category: string;
  status: StreamStatus;
  coverColor: string;
  emoji: string;
  hostId: string;
  hostName: string;
  listenerCount: number;
  peakListeners: number;
  startedAt?: string | null;
}

export interface ShowDTO {
  id: string;
  title: string;
  description?: string | null;
  category: string;
  coverColor: string;
  emoji: string;
  ownerName: string;
  episodeCount: number;
  subscriberCount: number;
}

export interface EpisodeDTO {
  id: string;
  title: string;
  description?: string | null;
  audioUrl: string;
  durationSec: number;
  showTitle: string;
  creatorName: string;
  playCount: number;
  publishedAt: string;
}

export interface ChatMessageDTO {
  id: string;
  content: string;
  streamId: string;
  userId: string;
  username: string;
  avatarColor: string;
  createdAt: string;
}

export interface NotificationDTO {
  id: string;
  type: string;
  message: string;
  read: boolean;
  createdAt: string;
}

// ---- Engagement DTOs ----
export interface PollOptionDTO {
  id: string;
  label: string;
  votes: number;
}
export interface PollDTO {
  id: string;
  streamId: string;
  question: string;
  closed: boolean;
  options: PollOptionDTO[];
  totalVotes: number;
}
export interface QuestionDTO {
  id: string;
  streamId: string;
  userId: string;
  username: string;
  content: string;
  answered: boolean;
  voteCount: number;
  createdAt: string;
}
export interface ReactionDTO {
  streamId: string;
  emoji: string;
  userId: string;
}
export interface TipDTO {
  id: string;
  amountMinor: number;
  currency: string;
  giftType?: string | null;
  message?: string | null;
  senderName: string;
  streamId?: string | null;
  createdAt: string;
}
export type SpeakerRole = "HOST" | "COHOST" | "SPEAKER" | "LISTENER";
export interface SpeakerDTO {
  userId: string;
  username: string;
  avatarColor: string;
  role: SpeakerRole;
  handRaised: boolean;
  muted: boolean;
}

export type Locale = "en" | "tw" | "ga" | "ee" | "ha";
export type ContentRating = "EVERYONE" | "TEEN" | "MATURE";
export type ModActionType = "MUTE" | "UNMUTE" | "KICK" | "BAN" | "UNBAN";

export interface CoStreamDTO {
  id: string;
  creator1Id: string;
  creator1Name: string;
  creator2Id: string;
  creator2Name: string;
  status: "SCHEDULED" | "LIVE" | "ENDED";
  startedAt?: Date;
  endedAt?: Date;
}

export interface VODDto {
  id: string;
  streamId: string;
  streamTitle: string;
  creatorName: string;
  isPremium: boolean;
  priceMinor: number;
  viewCount: number;
  purchaseCount: number;
  createdAt: Date;
}

export interface CreatorRecommendationDTO {
  id: string;
  displayName: string;
  avatarColor: string;
  verified: "VERIFIED" | "RISING" | "PRO" | "UNVERIFIED";
  categories: string[];
  reason: string;
}

export interface ListenerBadgeDTO {
  type: "member" | "tipper" | "friend" | "vip";
  awardedAt: Date;
}

export interface ListenerSessionDTO {
  userId: string;
  streamId: string;
  joinedAt: Date;
  durationSec: number;
  giftCount: number;
  messageCount: number;
}

export interface TipGoalDTO {
  id: string;
  streamId: string;
  title: string;
  targetMinor: number;
  currentMinor: number;
  currency: string;
  reached: boolean;
  active: boolean;
}

export interface ModerationStateDTO {
  streamId: string;
  slowModeSec: number;
  bannedWords: string;
  mutedUserIds: string[];
  bannedUserIds: string[];
}

export interface TicketDTO {
  id: string;
  streamId: string;
  status: "VALID" | "USED" | "REFUNDED";
  priceMinor: number;
  currency: string;
}

export interface ReferralStatsDTO {
  code: string;
  invited: number;
  rewardedMinor: number;
  currency: string;
}

// Socket.IO event contracts
export interface ServerToClientEvents {
  "stream:listeners": (payload: { streamId: string; count: number }) => void;
  "stream:status": (payload: { streamId: string; status: StreamStatus }) => void;
  "chat:message": (message: ChatMessageDTO) => void;
  "chat:pinned": (payload: { streamId: string; message: ChatMessageDTO | null }) => void;
  "global:liveCount": (payload: { totalListeners: number; liveStreams: number }) => void;
  "notification:new": (notification: NotificationDTO) => void;
  // engagement
  "poll:new": (poll: PollDTO) => void;
  "poll:update": (poll: PollDTO) => void;
  "question:new": (q: QuestionDTO) => void;
  "question:update": (q: QuestionDTO) => void;
  "reaction:burst": (r: ReactionDTO) => void;
  "tip:received": (tip: TipDTO) => void;
  // stage (multi-speaker audio)
  "stage:update": (payload: { streamId: string; speakers: SpeakerDTO[] }) => void;
  "stage:handRaised": (payload: { streamId: string; userId: string; username: string }) => void;
  // tip goals
  "tipGoal:update": (goal: TipGoalDTO) => void;
  // moderation
  "mod:state": (state: ModerationStateDTO) => void;
  "mod:muted": (payload: { streamId: string; userId: string; muted: boolean }) => void;
  "mod:kicked": (payload: { streamId: string; userId: string }) => void;
  "mod:banned": (payload: { streamId: string; userId: string; banned: boolean }) => void;
  "chat:rejected": (payload: { streamId: string; reason: string; cooldownSec?: number }) => void;
}

export interface ClientToServerEvents {
  "stream:join": (streamId: string) => void;
  "stream:leave": (streamId: string) => void;
  "chat:send": (payload: { streamId: string; content: string; token: string }) => void;
  "chat:pin": (payload: { streamId: string; messageId: string | null; token: string }) => void;
  "stream:goLive": (payload: { streamId: string; token: string }) => void;
  "stream:end": (payload: { streamId: string; token: string }) => void;
  // engagement
  "poll:create": (payload: { streamId: string; question: string; options: string[]; token: string }) => void;
  "poll:vote": (payload: { pollId: string; optionId: string; token: string }) => void;
  "poll:close": (payload: { pollId: string; token: string }) => void;
  "question:ask": (payload: { streamId: string; content: string; token: string }) => void;
  "question:upvote": (payload: { questionId: string; token: string }) => void;
  "question:answer": (payload: { questionId: string; token: string }) => void;
  "reaction:send": (payload: { streamId: string; emoji: string; token: string }) => void;
  // stage
  "stage:raiseHand": (payload: { streamId: string; token: string }) => void;
  "stage:invite": (payload: { streamId: string; userId: string; token: string }) => void;
  "stage:setMute": (payload: { streamId: string; muted: boolean; token: string }) => void;
  "stage:leave": (payload: { streamId: string; token: string }) => void;
  // tip goals (host)
  "tipGoal:create": (payload: { streamId: string; title: string; targetMinor: number; token: string }) => void;
  // moderation (host/co-host)
  "mod:setSlowMode": (payload: { streamId: string; seconds: number; token: string }) => void;
  "mod:setBannedWords": (payload: { streamId: string; words: string; token: string }) => void;
  "mod:mute": (payload: { streamId: string; userId: string; muted: boolean; token: string }) => void;
  "mod:kick": (payload: { streamId: string; userId: string; token: string }) => void;
  "mod:ban": (payload: { streamId: string; userId: string; banned: boolean; token: string }) => void;
}
