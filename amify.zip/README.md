# 🎙️ AmiFy — *Amplify your voice*

A premium, modern **audio live‑streaming platform** — real‑time live audio rooms, podcasts, live chat, and creator tools. Works on **Android, iPhone (PWA) and Web**.

**Company:** Amisco Technology (AmiTech)
**Developer:** Hon. Dr. Amisco
**Contact:** +233 54 654 2046 · hondramisco@gmail.com · amiscotechnology@gmail.com

---

## ⚙️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Framework | **Next.js 14** (App Router) |
| UI | **React 18** + **TypeScript** + Tailwind CSS |
| Database | **PostgreSQL** via **Prisma ORM** |
| Real‑time | **Socket.IO** (live listener presence + live chat) |
| Runtime | **Node.js 20** (custom server unifying Next + Socket.IO) |
| Deploy | **Docker** + Docker Compose |
| Auth | JWT + bcrypt |

---

## ✨ Features

### Core platform
- **Real‑time live streaming** — listener counts update live via WebSockets as people join/leave. No mock numbers; counts reflect actual connected clients and are persisted to Postgres.
- **Live chat** in every stream room, stored in the database and broadcast in real time.
- **Go Live** in seconds — pick a title, category, emoji and cover colour, and you're broadcasting.
- **Library** — subscriptions, saved episodes, and play history per user.
- **Discovery** — trending shows, browse categories, live search.
- **Dark / Light mode** with persisted preference.
- **PWA** — installable on iPhone and Android home screens, offline shell.
- **Secure auth** — JWT sessions, bcrypt‑hashed passwords.

### 🎙️ Live audio (multi‑speaker)
- **Speaker stage** — host plus invited co‑hosts/speakers, "raise hand to speak", invite-to-stage, mute toggle. All stage state is real‑time.
- **WebRTC transport via LiveKit** — token issuance with correct publish/subscribe rights (hosts & speakers publish, listeners subscribe). *Add LiveKit keys to enable in‑browser audio; everything else works without it.*

### 💸 Monetization
- **Live tipping & virtual gifts** (🌹 ☕ 🚀 👑) during streams, broadcast to the room instantly, with an 85/15 creator/platform split credited to the creator's wallet.
- **Mobile Money + cards** — provider‑agnostic gateway with a Paystack implementation supporting MTN MoMo, Vodafone Cash & AirtelTigo. Sandbox mode auto‑confirms until keys are added.
- **Membership tiers** — creators define monthly tiers with perks; listeners subscribe.
- **Premium episodes** — one‑time unlock pricing per episode.
- **Creator wallet & payouts** — withdraw to mobile money.

### 🤖 AI features
- **Auto‑transcription** (OpenAI Whisper) with searchable, timestamped segments.
- **AI show notes** — summary, key takeaways, auto **chapters**, and **clip suggestions** for the most shareable moments.
- **Translation** for global reach / dubbing prep.
- *All AI gated on a provider key; returns labelled placeholders so the pipeline is testable without one.*

### 📊 Engagement
- **Live polls** with real‑time results.
- **Q&A** with audience upvoting and host "mark answered".
- **Floating emoji reactions** that animate across the room.
- **Pinned messages** for hosts.

### 🎯 Moderation & Safety
- **Live moderation** — slow mode, per-user mute/kick/ban, configurable banned-word filter, optional AI toxicity check via OpenAI.
- **User reports** — listeners report inappropriate content; tracked with status workflow (open/reviewing/resolved/dismissed).
- **Age gating & content ratings** — shows/episodes marked EVERYONE, TEEN, or MATURE.
- **SMS live alerts** — SMS-opted-in followers get notified when a creator goes live (via Arkesel/Twilio or sandbox).

### 💰 Growth & Monetization Depth
- **Tip goals** — hosts set live fundraising targets during streams; progress bar updates in real time as tips come in.
- **Referral program** — creators share an invite code; referrers earn wallet credit per signup.
- **Pay-per-view tickets** — gate live events or recorded content behind a one-time price.
- **Sponsorship marketplace** — brands post campaigns with budgets; creators browse and feature sponsor slots.
- **Wallet top-up** — self top-up or agent/dealer cash-in for offline onboarding (mirrors Ghana mobile-money workflow).

### 🌍 Reach & Accessibility
- **Multi-language UI** — English + local languages (Twi, Ga, Ewe, Hausa). Gracefully falls back to English for missing keys.
- **Data-saver mode** — respects low-bandwidth users with quality downgrade and offline downloads.
- **Playback controls** — speed, skip-silence, sleep timer, cross-device resume on episode player.
- **AI clip generation & distribution** — auto-suggest shareable highlights; push to TikTok/Instagram/X with creator's OAuth (or queue in sandbox).

### 📊 Creator Intelligence
- **Weekly personalized digest** — "Your Mix" recommendations based on follows + play history + trending in user's categories.
- **Embeddable player widget** — creators drop an iframe on their own site to drive traffic back to AmiFy.

### Need keys (sandbox/placeholder fallbacks included)
**All external integrations optional & testable without keys:**
- **LiveKit** (live audio WebRTC) — sandbox shows a notice; all chat/polls/Q&A/reactions/tipping works.
- **Paystack** (payment settlement to Ghana MoMo/cards) — sandbox auto-confirms all charges; full payment flow testable.
- **OpenAI** (transcription, show notes, AI moderation) — sandbox returns labelled placeholders; pipeline fully testable.
- **Arkesel / Twilio** (SMS alerts) — sandbox logs to server console; full SMS notify flow testable end-to-end.
- **TikTok / Instagram / X APIs** (clip auto-posting) — sandbox queues posts as "shared"; clips stay shareable on AmiFy.

Drop API keys into `.env` anytime to upgrade from sandbox to real integrations. The codebase stays identical.

---

## 🚀 Quick Start (Docker — recommended)

The whole stack (Postgres + app + seed data) in one command:

```bash
cp .env.example .env        # adjust JWT_SECRET for production
docker compose up --build
```

Then open **http://localhost:3000**

Demo login → username `amitechuser`, password `password123`

---

## 🛠️ Local Development (without Docker)

**Prerequisites:** Node.js 20+, a running PostgreSQL instance.

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
#   → set DATABASE_URL to your Postgres instance

# 3. Set up the database
npm run db:push       # create tables
npm run db:seed       # load starter creators, shows & live streams

# 4. Run the dev server (Next.js + Socket.IO together)
npm run dev
```

App runs at **http://localhost:3000**.

> The app uses a **custom Node.js server** (`src/server/index.ts`) so Next.js and Socket.IO share one HTTP server on the same port.

---

## 📜 Scripts

| Command | What it does |
|---------|--------------|
| `npm run dev` | Start dev server (Next + Socket.IO) |
| `npm run build` | Generate Prisma client + build Next.js |
| `npm run start` | Production server |
| `npm run db:push` | Push schema to the database |
| `npm run db:migrate` | Create a migration |
| `npm run db:seed` | Seed demo data |
| `npm run db:studio` | Open Prisma Studio (DB GUI) |

---

## 🗂️ Project Structure

```
amify/
├── docker-compose.yml         # Postgres + app orchestration
├── Dockerfile                 # Multi-stage production image
├── prisma/
│   ├── schema.prisma          # Full data model (users, shows, streams, chat…)
│   └── seed.ts                # Starter data
├── src/
│   ├── server/
│   │   ├── index.ts           # Custom Node server (Next + Socket.IO)
│   │   └── socket.ts          # Real-time engine: presence, chat, go-live
│   ├── app/
│   │   ├── layout.tsx         # Root layout, fonts, providers
│   │   ├── page.tsx           # Main app (home / live / search / library / profile)
│   │   ├── globals.css
│   │   └── api/               # REST endpoints (auth, streams, shows, library)
│   ├── components/            # AppShell, LiveStreamCard, LiveRoom, AuthModal…
│   ├── context/               # ThemeContext (dark/light), AuthContext
│   ├── hooks/                 # useSocket (real-time hooks)
│   ├── lib/                   # prisma client, auth (JWT/bcrypt)
│   └── types/                 # Shared types + Socket.IO event contracts
└── public/                    # PWA manifest, service worker
```

---

## 🔌 How real‑time works

1. The browser opens a Socket.IO connection to `/api/socket`.
2. Joining a stream room emits `stream:join` → the server tracks the socket in an in‑memory presence map **and** persists the count to Postgres.
3. Every join/leave/disconnect re‑broadcasts `stream:listeners` to everyone in the room and a `global:liveCount` to all clients.
4. Chat messages are validated (JWT), saved to Postgres, then broadcast with `chat:message`.
5. Hosts emit `stream:goLive` / `stream:end` to flip stream status in real time.

---

## 📱 Installing as a mobile app (PWA)

- **iPhone:** open in Safari → Share → *Add to Home Screen*.
- **Android:** open in Chrome → menu → *Install app*.

For native store distribution, wrap the PWA with **Capacitor** or **React Native WebView** — the API + Socket.IO backend stays identical.

---

## 🔐 Production checklist

- Set a strong `JWT_SECRET`.
- Use managed Postgres (Neon, Supabase, RDS…) and set `DATABASE_URL`.
- Put the app behind HTTPS (WebSockets need `wss://`).
- Run `npm run db:migrate` instead of `db:push` for versioned schema changes.

---

© Amisco Technology (AmiTech). All rights reserved.
