import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Seeding AmiFy database…");

  const password = await bcrypt.hash("password123", 12);

  // Creators
  const creators = await Promise.all(
    [
      { username: "elarablue", displayName: "DJ Elara Blue", color: "#d97706" },
      { username: "techtalk", displayName: "Tech Talk Today", color: "#6d28d9" },
      { username: "calmharbor", displayName: "Calm Harbor", color: "#059669" },
      { username: "fieldreport", displayName: "Field Report", color: "#2563eb" },
    ].map((c, i) =>
      prisma.user.upsert({
        where: { username: c.username },
        update: {},
        create: {
          email: `${c.username}@amify.app`,
          username: c.username,
          displayName: c.displayName,
          passwordHash: password,
          avatarColor: c.color,
          isCreator: true,
          plan: i === 0 ? "CREATOR_PRO" : "PREMIUM",
        },
      })
    )
  );

  // Demo listener account
  const listener = await prisma.user.upsert({
    where: { username: "amitechuser" },
    update: {},
    create: {
      email: "amitechuser@amify.app",
      username: "amitechuser",
      displayName: "AmiTech User",
      passwordHash: password,
      avatarColor: "#7c3aed",
      plan: "PREMIUM",
    },
  });

  // Shows
  const showsData = [
    { title: "Friday Night Jazz", category: "Music", emoji: "🎷", color: "#d97706", owner: creators[0] },
    { title: "Tech Talk Today", category: "Technology", emoji: "💻", color: "#6d28d9", owner: creators[1] },
    { title: "Morning Meditation", category: "Wellness", emoji: "🧘", color: "#059669", owner: creators[2] },
    { title: "Sports Talk Live", category: "Sports", emoji: "🏆", color: "#2563eb", owner: creators[3] },
    { title: "True Crime Files", category: "News", emoji: "🔍", color: "#dc2626", owner: creators[1] },
  ];

  const shows = [];
  for (const s of showsData) {
    const show = await prisma.show.create({
      data: {
        title: s.title,
        category: s.category,
        emoji: s.emoji,
        coverColor: s.color,
        ownerId: s.owner.id,
        description: `${s.title} — premium audio on AmiFy.`,
      },
    });
    shows.push(show);

    // an episode per show
    await prisma.episode.create({
      data: {
        title: `${s.title} — Episode 1`,
        audioUrl: "https://example.com/audio.mp3",
        durationSec: 2400 + Math.floor(Math.random() * 1800),
        showId: show.id,
        creatorId: s.owner.id,
        playCount: Math.floor(Math.random() * 5000),
      },
    });
  }

  // Live streams
  const liveData = [
    { title: "Friday Night Jazz", category: "Music", emoji: "🎵", color: "#d97706", host: creators[0] },
    { title: "Breaking: AI Regulation", category: "Technology", emoji: "🤖", color: "#6d28d9", host: creators[1] },
    { title: "Morning Meditation Live", category: "Wellness", emoji: "🧘", color: "#059669", host: creators[2] },
    { title: "Sports Talk Live", category: "Sports", emoji: "🏆", color: "#2563eb", host: creators[3] },
  ];

  const streams = [];
  for (const l of liveData) {
    const stream = await prisma.stream.create({
      data: {
        title: l.title,
        category: l.category,
        emoji: l.emoji,
        coverColor: l.color,
        hostId: l.host.id,
        status: "LIVE",
        startedAt: new Date(),
        listenerCount: 0,
        peakListeners: 0,
      },
    });
    streams.push(stream);
  }

  // Trending searches
  for (const term of ["True Crime", "Morning Meditation", "Tech News", "Jazz Live", "Finance 2025"]) {
    await prisma.trendingSearch.upsert({
      where: { term },
      update: { count: { increment: 1 } },
      create: { term, count: Math.floor(Math.random() * 1000) },
    });
  }

  // Membership tiers for the first creator
  await prisma.membershipTier.create({
    data: {
      creatorId: creators[0].id,
      name: "Supporter",
      priceMinor: 1000, // GHS 10/mo
      perks: JSON.stringify(["Ad-free listening", "Supporter badge"]),
    },
  });
  await prisma.membershipTier.create({
    data: {
      creatorId: creators[0].id,
      name: "Superfan",
      priceMinor: 3000, // GHS 30/mo
      perks: JSON.stringify([
        "Everything in Supporter",
        "Exclusive episodes",
        "Monthly shout-out",
        "Priority Q&A",
      ]),
    },
  });

  // Tip goals for a live stream
  const tipGoal = await prisma.tipGoal.create({
    data: {
      streamId: streams[0].id,
      title: "Help us buy a new mic",
      targetMinor: 5000, // GHS 50
      currentMinor: 1200,
    },
  });

  // Referral codes
  const creator1 = creators[0];
  if (!creator1.referralCode) {
    await prisma.user.update({
      where: { id: creator1.id },
      data: { referralCode: "ELARA-A7B2" },
    });
  }

  // Sponsorships
  await prisma.sponsorship.create({
    data: {
      advertiser: "TechGear Pro",
      contactEmail: "sponsor@techgear.com",
      campaign: "Q2 2026 Podcast Series",
      category: "Tech Talk",
      budgetMinor: 50000, // GHS 500
      cpmMinor: 50, // GHS 0.50 per 1000 plays
      active: true,
    },
  });

  await prisma.sponsorship.create({
    data: {
      advertiser: "LocalCoffee Co",
      contactEmail: "ads@localcoffee.com",
      campaign: "Morning Brew Spots",
      category: "Wellness",
      budgetMinor: 20000,
      cpmMinor: 30,
      active: true,
    },
  });

  // Sample report
  await prisma.report.create({
    data: {
      reporterId: listener.id,
      targetType: "message",
      targetId: "sample-msg-id",
      reason: "Inappropriate language",
      details: "Message contained offensive terms",
      status: "OPEN",
    },
  });

  console.log("✅ Seed complete!");
  console.log("   Demo login: amitechuser / password123");

  // ============================================================
  // EXTENDED SEED: Co-streaming, VOD, Analytics, Verification
  // ============================================================

  // Add verification tiers to creators
  await prisma.user.updateMany({
    where: { isCreator: true },
    data: { verified: "VERIFIED" as any },
  });

  // Add primary currency diversity
  await prisma.user.update({
    where: { id: creators[0].id },
    data: { primaryCurrency: "GHS" as any },
  });
  await prisma.user.update({
    where: { id: creators[1].id },
    data: { primaryCurrency: "ZAR" as any },
  });
  await prisma.user.update({
    where: { id: creators[2].id },
    data: { primaryCurrency: "KES" as any },
  });

  // Create seasons for shows
  const season1 = await prisma.season.create({
    data: {
      showId: shows[0].id,
      title: "Season 1",
      description: "First season of deep tech discussions",
      seasonNum: 1,
      episodeCount: 3,
    },
  });

  const season2 = await prisma.season.create({
    data: {
      showId: shows[0].id,
      title: "Season 2",
      description: "Advanced topics",
      seasonNum: 2,
      episodeCount: 2,
    },
  });

  // Create VODs from ended streams
  const vod1 = await prisma.vod.create({
    data: {
      streamId: streams[0].id,
      status: "READY" as any,
      isPremium: true,
      priceMinor: 50000,
      viewCount: 245,
      purchaseCount: 18,
    },
  });

  const vod2 = await prisma.vod.create({
    data: {
      streamId: streams[1].id,
      status: "READY" as any,
      isPremium: false,
      viewCount: 892,
    },
  });

  // Create listener sessions (analytics)
  const now = new Date();
  await prisma.listenerSession.create({
    data: {
      userId: listener.id,
      streamId: streams[0].id,
      joinedAt: new Date(now.getTime() - 3600000),
      leftAt: now,
      durationSec: 3600,
      giftCount: 5,
      messageCount: 28,
    },
  });

  // Create creator recommendations
  await prisma.creatorRecommendation.create({
    data: {
      userId: listener.id,
      recommendedCreatorId: creators[1].id,
      score: 85,
      reason: "Trending in your favorite category",
    },
  });

  // Create listener badges
  await prisma.listenerBadge.create({
    data: {
      userId: listener.id,
      type: "tipper",
      creatorId: creators[0].id,
    },
  });

  await prisma.listenerBadge.create({
    data: {
      userId: listener.id,
      type: "member",
      creatorId: creators[0].id,
    },
  });

  // Create co-stream (collaboration)
  await prisma.coStream.create({
    data: {
      creator1Id: creators[0].id,
      creator2Id: creators[1].id,
      status: "SCHEDULED" as any,
    },
  });

  // Update listener streaks
  await prisma.user.update({
    where: { id: listener.id },
    data: {
      listenStreak: 7,
      streakStartedAt: new Date(now.getTime() - 7 * 86400000),
    },
  });

  console.log("✅ Extended seed: seasons, VODs, analytics, verification, co-streams, recommendations, badges, streaks");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
